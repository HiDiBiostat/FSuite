/*****************************************************************************/
/*   Name: tab3D_dyn.c                                                       */
/*   Author: AL Leutenegger                                                  */
/*   Description: fonction qui (des)alloue dynamiquement                     */
/*   un tableau 2D & 3D d'entiers et de reels                                */
/*   Date: 19 05 2002                                                        */
/*****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include "pg.h"

#ifdef DMALLOC
#include "dmalloc.h"
#endif

int ** Alloc2Dint(int h, int w)
/* Alloue memoire dynamiquement pour un tab2D (h x w) d'integers */
{
  int *tab, **ptab, i;

  ptab= (int **) calloc(h,sizeof(int *));
/* tab de pointeurs sur 1er case de chaque ligne */
  if (ptab==NULL) return NULL;
  tab= (int *) calloc(h*w,sizeof(int));
/*    tab des donnees (int) avec chaque ligne a la suite de l'autre */
/*    ou bien: ptab[0] = (int *) calloc(h*w,sizeof(int)); */
/*             et puis commencer boucle a k=1, et ptab[k]=ptab[k-1]+w; */
  if (tab==NULL)
  {
   free(ptab); /*  libere 1er tab qui avait marche  */
   return NULL;
  }
  for (i = 0; i < h; ++i) { /* initialisation de ptab pour qu'il pointe sur tab */
      ptab[i] = tab+i*w;
  }

  return ptab;
}

int *** Alloc3Dint(int h, int w, int d)
/*  Alloue memoire dynamiquement pour un tab3D (h x w x d) d'integers */
{
  int ***pptab, i;

  pptab= (int ***) calloc(h,sizeof(int **));
/*    tab de pointeurs sur 1er case de chaque ligne */
  if (pptab==NULL) return NULL;
  for (i = 0; i < h; ++i) { 
    pptab[i]=Alloc2Dint(w,d);
  }

  return pptab;
}

int ** Init2Dint(int h, int w, int n)
/* Remplit le tab. avec n */
{
  int **pt, i, j;

  pt = Alloc2Dint (h, w);
  for (i = 0; i < h; ++i) {
    for (j = 0; j < w; ++j) {
      pt[i][j] = n;
    }
  }
      
  return pt;
}

void Free2Dint(int **tab)
/*  Libere la memoire allouee par Alloc2Dint() */
{
  free(tab[0]); /* libere tab. de donnees */
  free(tab);    /* libere tab. de pointeurs */
}

void Free3Dint(int ***tab, int h)
/*  Libere la memoire allouee par Alloc3Dint() */
{
  int i;
  for (i = 0; i < h; ++i) { 
    Free2Dint(tab[i]); /* libere tab. de donnees 2D */
  }
  free(tab);   /*  libere tab. de pointeurs */
}

real ** Alloc2Ddouble(int h, int w)
/*  Alloue memoire dynamiquement pour un tab2D (h x w) de reals */
{
  real *tab, **ptab;
  int k;

  ptab= (real **) calloc(h,sizeof(real *));
/*    tab de pointeurs sur 1er case de chaque ligne */
  if (ptab==NULL) return NULL;
  tab= (real *) calloc(h*w,sizeof(real));
/*   tab des donnees (real) avec chaque ligne a la suite de l'autre */
/*   ou bien: ptab[0] = (real *) calloc(h*w,sizeof(real)); */
/*             et puis commencer boucle a k=1, et ptab[k]=ptab[k-1]+w; */
  if (tab==NULL)
  {
   free(ptab); /*  libere 1er tab qui avait marche */
   return NULL;
  }
  for(k=0;k<h;k++)  /*  initialisation de ptab pour qu'il pointe sur tab */
  {
   ptab[k]=tab+k*w;
  }

  return ptab;
}

real *** Alloc3Ddouble(int h, int w, int d)
/*  Alloue memoire dynamiquement pour un tab3D (h x w x d) de reals */
{
  real ***pptab;
  int i;

  pptab= (real ***) calloc(h,sizeof(real **));
/*    tab de pointeurs sur 1er case de chaque ligne */
  if (pptab==NULL) return NULL;
  for (i = 0; i < h; ++i) { 
    pptab[i]=Alloc2Ddouble(w,d);
  }

  return pptab;
}

real ** Init2Ddouble(int h, int w, real n)
/*  Remplit le tab. avec n  */
{
 real **pt;
 int i=0, j=0;
 pt=Alloc2Ddouble(h,w);
 if (pt==NULL) return NULL;
 for(j=0;j<h;j++) {
   for(i=0;i<w;i++) {
     pt[j][i]=n;
     /* Eprintf("pt=%f\n",pt[j][i]); */
   }
 }
 return pt;
}
 
real *** Init3Ddouble(int h, int w, int d, real n)
/*  Remplit le tab3D (h x w x d) avec n */
{
 real ***pt;
 int i, j, k;
 pt=Alloc3Ddouble(h,w,d);
 if (pt==NULL) return NULL;
 for(j=0;j<h;j++)
   for(i=0;i<w;i++)
     for(k=0;k<d;k++)
       pt[j][i][k]=n;
 return pt;
}

void Free2Ddouble(real **tab)
/*  Libere la memoire allouee par Alloc2Ddouble() */
{
  free(tab[0]); /*  libere tab. de donnees */
  free(tab);    /*  libere tab. de pointeurs */
}

void Free3Ddouble(real ***tab, int h)
/*  Libere la memoire allouee par Alloc3Ddouble(), h=1ere dimension */
{
  int i;
  for (i = 0; i < h; ++i) { 
    Free2Ddouble(tab[i]); /* libere tab. de donnees 2D */
  }
  free(tab);   /*  libere tab. de pointeurs */
}
