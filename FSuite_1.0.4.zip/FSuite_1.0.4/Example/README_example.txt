#Working example 

#1st step : not executed as reference allele frequencies are given.

#2nd step : create submaps
perl ../FSuite/fsuite.pl --create-submaps --map example.bim --n-submaps 5 --coverage > log_example.txt

#from now, we work on submaps in example/submaps
rm -rf submaps 

#3rd step : run FEstim and perform mating-type
perl ../FSuite/fsuite.pl --FEstim --bfile example --freq reference.frq --sub-folder submaps_example --mating-type  >> log_example.txt

#4th step : calculate FLOD on inbred cases
perl ../FSuite/fsuite.pl --FLOD --bfile example --freq reference.frq --sub-folder submaps_example --inbred example >> log_example.txt

#5th step : calculate HFLOD on inbred cases
perl ../FSuite/fsuite.pl --HFLOD >> log_example.txt
 
#6th step: plot HBD segments 
perl ../FSuite/fsuite.pl --plot-HBD --chr 20  >> log_example.txt
perl ../FSuite/fsuite.pl --plot-HBD --fid fam1 --iid ind1  >> log_example.txt
perl ../FSuite/fsuite.pl --plot-HBD --circos  >> log_example.txt


#example of others options
perl ../FSuite/fsuite.pl --estimate-frequencies --bfile example --freq-all
perl ../FSuite/fsuite.pl --create-submaps --map example.bim --hotspots hg18 --n-submaps 5 --coverage




