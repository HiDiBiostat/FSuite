/****************************************************************************/
/*** Name: FEstim_main.c                                                  ***/
/* Author: Anne-Louise Leutenegger -- ALL[JULY 2006][2010]                  */
/*                                                                          */
/****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "pg.h"

/* extern */ 
int TOT_NUM_LOCUS;
int TOT_NUM_INDIV;
int TOT_NUM_FAM;
int TOT_NUM_ISO;
int NUM_SCALE;
markmap *MAP;
indiv *DATA;
int nIndiv;
int *DATAisZERO;
vector xall; 
tmaxn itp;
FILE *outfile, *detfile;
int FIRST_PRINT_CPROBA;
real EPSILON;
real TOL_ALLELE_FREQ;
real tol ;
int NUM_ITER_MC;
int MAX_NAME_MARKER;
int MAX_LENGTH_ID;
int MAX_LENGTH_FAMID;
int MAX_NUM_SIB_FAM;
real fD ;
int REP ;
int MAX_LENGTH_LINE;
int cM;
int HET;
/* End extern */ 


int main(int argc, char **argv) {
/* Note that in function main : "return 2" means Error, while "return 0" means OK */
/* In the rest of the program (i.e. other functions), "return 0" means Error, while "return 1" means OK */
  int l, PRINT_OPTIONS;
  real *start_param[2];
  real INBREED, A, INBREED_INIT, A_INIT, info_matrix3[2][2], SE[2]={0};
  real *INBall, *Aall;
  real *MedF, *MedA;
  int *list_AffIndiv, *BI;
  real *lTkn, *lTk, *lodnucl_noinbreed;
  real ***QQ, **Q, **fam_lod_noinbreed;
  char *informat, *outformat, *datafile, *markerfile; /*input files*/
  char *std_error, *sample, *lodfile, *LODnoInbreeding, *fixedFnAfile; /*input files*/
  char *markerhetfile; /*input files*/
  time_t t;


/* default values  */  
  informat="NULL";
  outformat ="outnew";
  datafile = "thereisnodatafile";
  markerfile = "thereisnomarkerfile";
  markerhetfile="NULL";
  INBREED_INIT=0.05;
  A_INIT=0.05;
  std_error ="noSE";
  sample ="independent";
  lodfile ="NULL";
  LODnoInbreeding="NULL";
  fixedFnAfile ="thereisnoFnAfile";
  
  cM=1; /* by default the map is in cM */
  EPSILON = 0.001; /* genotype error rate from CEPH */
  TOL_ALLELE_FREQ= 0.001; /* tolerance for marker allele frequency rounding up */
  MAX_NAME_MARKER= 20;
  MAX_LENGTH_ID= 20;
  MAX_LENGTH_FAMID= 20;
  MAX_NUM_SIB_FAM= 10;
  fD= 0.00001; /* susceptibilty allele frequency */
  REP= 100000; /* num. repetitions for significance of FLOD */ 
  tol= 1.0E-5; /* for gemini.c */
  NUM_ITER_MC= 8000;
  MAX_LENGTH_LINE=10000;
  PRINT_OPTIONS=0;
  HET=0; /* by default, frequencies of each alleles are used (not just the marker heterozygosity as in Auton et al, 2009) */
  
/* input  */
  l=1;
  while(l<argc) {
      if      (strcmp(argv[l],"--ped") == 0) { datafile=argv[l+1] ; l++; }
      else if (strcmp(argv[l],"--mfest") == 0) {markerfile=argv[l+1] ; informat="festform"; l++; }
      else if (strcmp(argv[l],"--mplink") == 0) {markerfile=argv[l+1] ; informat="plinform"; l++; }
      else if (strcmp(argv[l],"-f") == 0) {INBREED_INIT=atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"-a") == 0) {A_INIT=atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"--out1") == 0) {outformat="outdefault";}
      else if (strcmp(argv[l],"--out2") == 0) {outformat="outnew";}
      else if (strcmp(argv[l],"--SE") == 0) {std_error="SE";}
      else if (strcmp(argv[l],"--noSE") == 0) {std_error="noSE";}
      else if (strcmp(argv[l],"--independent") == 0) {sample ="independent";}
      else if (strcmp(argv[l],"--samplewise") == 0) {
	       sample="nuclear"; lodfile="samplewise"; LODnoInbreeding=argv[l+1] ; l++;
	       }
      else if (strcmp(argv[l],"--familywise") == 0) {
	       sample="nuclear"; lodfile="familywise"; LODnoInbreeding=argv[l+1] ; l++;
           }
      else if (strcmp(argv[l],"--FnA") == 0) {fixedFnAfile=argv[l+1] ; l++;} /* noestim */
      else if (strcmp(argv[l],"--Morgan") == 0)     {cM=0; }
      else if (strcmp(argv[l],"--eps") == 0)     {EPSILON =atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"--tolfq") == 0) {TOL_ALLELE_FREQ=atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"--msmark") == 0)   {MAX_NAME_MARKER=atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"--msid") == 0)     {MAX_LENGTH_ID=atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"--msfam") == 0)    {MAX_LENGTH_FAMID=atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"--mnfsib") == 0)    {MAX_NUM_SIB_FAM=atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"--fD") == 0)      {fD=atof(argv[l+1]) ; l++; }
      /*else if (strcmp(argv[l],"--rep") == 0)     {REP=atof(argv[l+1]) ; l++; }*/
      else if (strcmp(argv[l],"--tolg") == 0)     {tol=atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"--iterMC") == 0)  {NUM_ITER_MC=atof(argv[l+1]) ; l++; }
      else if (strcmp(argv[l],"--help") == 0)  {PRINT_OPTIONS=1;}
      else if (strcmp(argv[l],"--hetO") == 0)  {
	       HET=1; if (strncmp(argv[l+1],"--",2) != 0) {markerhetfile=argv[l+1];} l++;
	       }
      else if (strcmp(argv[l],"--hetE") == 0)  {HET=1; markerhetfile=NULL; l++;}
      else    {Eprintf("\nERROR %s is not a valid option \n",argv[l]);return 2;}
      l++;
  }

  if (PRINT_OPTIONS==1) {
    if (argc>2) {
      Eprintf("\nusage:\n");
      Eprintf("--help option should be specified alone\n");
      return 2;
    } else {    
      Eprintf("\nFEstim options are:\n");	
      Eprintf("       Data file : --ped, --msid[20], --msfam[20], --mnfsib[10] \n");
      Eprintf("     Marker file : --mfest, --mplink, --Morgan, --msmark[20], --tolfq[0.001], --hetO, --hetE \n");
      Eprintf("    Output files : --out1, [--out2] \n");
      Eprintf("  Standard error : [--noSE], --SE, --iterMC[8000] \n");
      Eprintf("          Sample : [--independent], --samplewise, --familywise \n");         
      Eprintf("       Algorithm : -f[0.05], -a[0.05], --eps[0.001], --fD[0.00001], --tolg[0.00001]\n\n\n");
      return 2;
    }
  }
  
  if ( strcmp(datafile,"thereisnodatafile")==0 || strcmp(markerfile,"thereisnomarkerfile")==0 ) {
	  
    Eprintf("\nusage:\n");
    Eprintf("FEstim needs a data file and a markerfile\n");
    Eprintf("Use --help to see all options\n");
    return 2;    
  }

  t = time(NULL);
  printf(asctime(localtime(&t)));
  printf("*****************************************************\n");
  printf("** FEstim (version 1.3.2)                          **\n");
  printf("** Copyright (C) 2003-2012 Anne-Louise Leutenegger **\n");
  printf("*****************************************************\n");
  printf(" This program comes with ABSOLUTELY NO WARRANTY;\n");
  printf(" This is free software, and you are welcome to redistribute it\n");
  printf(" under certain conditions;");
  printf("\n");
  
/* initialization and input of the variables */
  COMPUT_CSOME=0;
  FIRST_PRINT_CPROBA=0;

  if (!Get_input_genome_plinkOK(informat, markerfile, datafile, sample)) {
    Eprintf("\nERROR when reading input files (markerfile and/or datafile)\n");
    return 2;
  }
  printf("\n");

  if (HET==1) {
    if (Get_input_HET(markerhetfile,MAP)) {
      printf("Computation using: observed marker heterozygosity (%s)\n\n",
	     markerhetfile);      
    } else {
      printf("Computation using: expected marker heterozygosity (%s)\n\n",
	     markerfile);
    }
  } else {
    printf("Computation using: marker allele frequencies (%s)\n\n",markerfile);
  }

  if ((lTk=(real *) calloc(TOT_NUM_LOCUS,sizeof(real)))==NULL) {    
    Eprintf("\nCould not allocate memory for lTk in main\n"); 
    return 2;
  }
  if ((INBall=(real *) calloc(TOT_NUM_INDIV,sizeof(real)))==NULL) {    
    Eprintf("\nCould not allocate memory for INBall in main\n"); 
    return 2;
  }
  if ((Aall=(real *) calloc(TOT_NUM_INDIV,sizeof(real)))==NULL) {    
    Eprintf("\nCould not allocate memory for Aall in main\n"); 
    return 2;
  }

  
/* analyses of the data */
  if (strcmp(fixedFnAfile,"thereisnoFnAfile")!=0) {/* noestim */
    if(!Get_FnA(fixedFnAfile, INBall, Aall)) { 
      Eprintf("Problem in Get_FnA in main\n"); 
      return 2;
    }
  } else {
    printf("Gemini tolerance: %.10f\n",tol);
  }

  for (nIndiv=0; nIndiv<TOT_NUM_INDIV; nIndiv++) {
    printf("\nEstimation for family %s individual %s:\n",
	   DATA[nIndiv].famid,DATA[nIndiv].id);
    INBREED=INBREED_INIT;
    A=A_INIT;
    if ((Q=Init2Ddouble(TOT_NUM_LOCUS,TOT_IBD_STATE,0))==NULL) { 
      Eprintf("Could not allocate/initialize memory for Q in main\n"); 
      return 2;
    }
    if ((QQ=Init3Ddouble(TOT_NUM_LOCUS,
			 TOT_IBD_STATE,TOT_IBD_STATE,0))==NULL) { 
      Eprintf("Could not allocate/initialize memory for QQ in main\n"); 
      return 2;
    }
    if ((lTkn=(real *) calloc(TOT_NUM_LOCUS,sizeof(real)))==NULL) {    
      Eprintf("\nCould not allocate memory for lTkn in main\n"); 
      return 2;
    }
    if ((BI=(int *) calloc(TOT_NUM_LOCUS,sizeof(int)))==NULL) {
      Eprintf("\nCould not allocate memory for BI in main\n"); 
      return 2;
    }
    if((outfile=fopen("gemini.out","w")) == NULL) { 
      Eprintf("File gemini.out could not be opened\n"); 
      return 2;
    }
    if((detfile=fopen("gemini.det","w")) == NULL) { 
      Eprintf("File gemini.det could not be opened\n"); 
      return 2;
    }

    start_param[0]=&INBREED; start_param[1]=&A;
    xall[0]=INBREED; xall[1]=A;

    if (DATAisZERO[nIndiv] < TOT_NUM_LOCUS) { /* Individual IS genotyped */
      printf("%5s\t%17s\t%17s\t%21s\n","iter","F","A","loglikY");
      printf("%5s\t%17.10f\t%17.10f\t%21.10f\n","0",
	     xall[0],xall[1],-fun(xall));
      
      if (strcmp(fixedFnAfile,"thereisnoFnAfile")!=0) {/* noestim */
	INBREED=INBall[nIndiv]; A=Aall[nIndiv]; 
	xall[0]=INBall[nIndiv]; xall[1]=Aall[nIndiv];
	printf("%5s\t%17.10f\t%17.10f\t%21.10f\n","1",
	       xall[0],xall[1],-fun(xall)); 
      } else {
	/* Initialisation Gemini */
	initgemini(outfile, detfile, 2, start_param);
	/* Estimation of INBREED & A */
	gemini();
	outgemini();
	start_param[0]=&xall[0];
	start_param[1]=&xall[1];      
	INBREED=xall[0]; A=xall[1];
	INBall[nIndiv]=xall[0]; Aall[nIndiv]=xall[1];    
      }
      
      /* Compute Q & QQ - Print out Posterior IBD proba at MLEs */
      /* Compute logTk,n & logTk - Print out logTk,n */
      for (l=0;l<TOT_NUM_LOCUS;l++) {
	lTkn[l]=0;      
      }
      
      if(!Conditional_proba(INBREED,A,MAP,DATA[nIndiv].markdat,
			    TOT_NUM_LOCUS,Q,QQ)) {
	Eprintf("Problem in Conditional_proba in main\n"); 
	return 2;
      }
      if(!GClogLikRatio(INBREED,Q,lTkn)) {
	Eprintf("\nProblem in GClogLikRatio in main\n");
	return 2;
      }

      if(!Viterbi(INBREED,A,MAP,DATA[nIndiv].markdat,BI)) {
	Eprintf("\nProblem in Viterbi in main\n"); 
	return 2;
      }  
      
      if (!SumNprint_family_lod_independent("family_lodscore.out",lTkn,
					      nIndiv,lTk)) {
	Eprintf("\nProblem in SumNprint_family_lod_independent in main\n");
	return 2;
      }
      if (strcmp(outformat,"outdefault")==0) {
	if(!Print_conditional_proba("conditional_proba.out",
				      FIRST_PRINT_CPROBA,
				      nIndiv,INBREED,A,Q,lTkn)) {
	  Eprintf("\nProblem in Print_conditional_proba in main\n");
	}
	if(!Print_bestibd("bestIBD.out",FIRST_PRINT_CPROBA,
			    nIndiv,INBREED,A,BI)) {
	  Eprintf("\nProblem in Print_bestibd in main\n");
	}
      } else {
	if(!Print_conditional_proba_v2("locusIBD.out",
					 FIRST_PRINT_CPROBA,
					 nIndiv,Q,lTkn,BI)) {
	  Eprintf("\nProblem in Print_conditional_proba_v2 in main\n");
	}
      }
      FIRST_PRINT_CPROBA++;
    } else { /* Individual is NOT genotyped */
      INBREED=-9; A=-9;
      INBall[nIndiv]=-9; Aall[nIndiv]=-9;      
      printf("No data for this individual\n");
    }

    if (strcmp(std_error,"SE")==0) { /*   Compute information matrix */
      if (DATAisZERO[nIndiv]==TOT_NUM_LOCUS) {/* Individual is NOT genotyped */
	printf("\nNo data, no standard deviation estimation.\n");
      } else if (INBREED <= 1.0E-8) { /* Individual IS genotyped but F=0 */
	printf("\nF is zero. No standard deviation estimation.\n");
      } else { /* Individual IS genotyped and F!=0*/
	if (!Information_matrix3(start_param,Q,QQ,info_matrix3)) {
	  Eprintf("Problem in Information_matrix3 in main\n");
	  return 2;
	}
	printf("Info observed:\n");
	printf("  Iy[0][0]=%8.3f\tIy[0][1]=%8.3f\n",
	       info_matrix3[0][0],info_matrix3[0][1]);
	printf("  Iy[1][0]=%8.3f\tIy[1][1]=%8.3f\n",
	       info_matrix3[1][0],info_matrix3[1][1]);
	SE[0]=pow(1./(info_matrix3[0][0]-info_matrix3[0][1]*info_matrix3[1][0]/info_matrix3[1][1]),0.5);
	SE[1]=pow(1./(info_matrix3[1][1]-info_matrix3[1][0]*info_matrix3[0][1]/info_matrix3[0][0]),0.5);
	printf("  Std errors: F=sqrt(%f)= %f , A=sqrt(%f)= %f\n",
	       (real)pow(SE[0],2.),SE[0],(real)pow(SE[1],2.),SE[1]);
	printf("\n");
      }
    } else if (strcmp(std_error,"noSE")!=0) {
      Eprintf("\nWrong argument for standard error computation: SE or noSE\n");
      return 2;
    }
    Free2Ddouble(Q);
    Free3Ddouble(QQ,TOT_NUM_LOCUS);
    free(lTkn);
    free(BI);
    
    /* Print out results in inbreedings.out */
    if(!Print_inbreeding("inbreedings.out", std_error, nIndiv,INBREED, A, SE)) {
      Eprintf("\nProblem in Print_inbreeding\n");
      return 2;
    }
    fclose(detfile);
    fclose(outfile);
  } /*End for (nIndiv=0; ...) */

  /* Take care of lodscore computation for "nuclear" option */
  if (strcmp(sample,"nuclear")==0) {
    /*Re-initialize lTk for nuclear FLOD*/
    free(lTk);
    if ((lTk=(real *) calloc(TOT_NUM_LOCUS,sizeof(real)))==NULL) {    
      Eprintf("\nCould not allocate memory for lTk in main\n"); 
      return 2;
    }
    if ((lodnucl_noinbreed=(real *) calloc(TOT_NUM_LOCUS,sizeof(real)))==NULL) {
      Eprintf("\nCould not allocate memory for lodnucl_noinbreed in main\n"); 
      return 2;
    }
    if ((fam_lod_noinbreed=Init2Ddouble(TOT_NUM_FAM,TOT_NUM_LOCUS,0))==NULL) {
      Eprintf("\nCould not allocate memory for fam_lod_noinbreed in main\n"); 
      return 2;
    }
    if ((MedF=(real *) calloc(TOT_NUM_FAM,sizeof(real)))==NULL) {    
      Eprintf("\nCould not allocate memory for MedF in main\n"); 
      return 2;
    }
    if ((MedA=(real *) calloc(TOT_NUM_FAM,sizeof(real)))==NULL) {    
      Eprintf("\nCould not allocate memory for MedA in main\n"); 
      return 2;
    }
    if ((list_AffIndiv=(int *) calloc(TOT_NUM_FAM,sizeof(int)))==NULL) {    
      Eprintf("\nCould not allocate memory for list_AffIndiv in main\n"); 
      return 2;
    }

    if (strcmp(lodfile,"samplewise")==0) {
      if(!Get_lodnuclear_noinbreed(TOT_NUM_LOCUS, MAP, LODnoInbreeding, 
				   lodnucl_noinbreed)) {
	Eprintf("\nProblem reading the sample input file (LODnoInbreeding)\n");
	return 2;
      }
      if(!GClogLikRatio_nuclear_sample(INBall, Aall, lodnucl_noinbreed, 
				       list_AffIndiv, MedF, MedA, lTk)) {
	Eprintf("\nProblem in GClogLikRatio_nuclear_sample in main\n");
	return 2;
      }
    } else if (strcmp(lodfile,"familywise")==0) {
      if(!Get_list_lodnuclear_noinbreed(TOT_NUM_LOCUS, MAP, LODnoInbreeding, 
					fam_lod_noinbreed)) {
	Eprintf("\nProblem reading the list of family input files (LODnoInbreeding)\n");
	return 2;
      }
      if(!GClogLikRatio_nuclear_family(INBall, Aall, fam_lod_noinbreed, 
				       list_AffIndiv, MedF, MedA, lTk)) {
	Eprintf("\nProblem in GClogLikRatio_nuclear_family in main\n");
	return 2;
      }
    } else {
      Eprintf("\nWrong argument for lod: samplewise or familywise\n");
      return 2;
    }
    /* Print Median F and A when "nuclear" lodscore is used*/
    if(!Print_inbreeding_nuclear("inbreedings.out", list_AffIndiv, 
				 MedF, MedA)) {
      Eprintf("\nProblem in Print_inbreeding_nuclear in main\n");
      return 2;
    }
    free(list_AffIndiv);
    free(MedF);
    free(MedA);
    free(lodnucl_noinbreed);
    Free2Ddouble(fam_lod_noinbreed);
  }
  /* End: "nuclear" lodscore computation */

  /* Print out lodscore logTk */
  if(!Print_lodscore("lodscore.out", lTk)) {
    Eprintf("\nProblem in Print_lodscore in main\n");
    return 2;
  }

  free(lTk);
  free(INBall);
  free(Aall);
  free(DATAisZERO);
  Free_marker(MAP,TOT_NUM_LOCUS);
  Free_data(DATA,TOT_NUM_LOCUS);
  return 0; /* OK */
}
