/********************************/
/*   29/12/95                   */
/*   Antoine Clerget            */
/*   --- gemini.c               */
/********************************/


/* Ce module, Gemini, est un module d'optimisation independant du reste du programme :

 initgemini :
  Cette procedure initialise les variables de gemini a partir de celles du programme
  Masc. Elle remplit le vecteur xall[], x[i], a partir de (*iterated[]), tableau de
  pointeurs vers les variables a iterer.
  En initialisant bnd, on contraint a faire varier les parametres entre 0 et 1.
 outgemini :
	Cette procedure enregistre dans le fichier gemini quelques informations sur le 
	deroulement de l'optimisation
 fun :
 	fonction appele par gemini pour evaluer la vraisemblance. Renvoie un reel.
*/


/* GEMINI :
 	Cette methode a ete literalement traduite depuis une version ecrite en Pascal.
	Pour plus d'informations, se referer a une documentation sur cette methode.
*/
/*@misc{ lalouel79gemini, */
/*author = "J. Lalouel", */
/*title = "GEMINI - a computer program for optimization of general nonlinear functions", */
/*text = "J. M. Lalouel. GEMINI - a computer program for optimization of general */
/*   nonlinear functions. Technical Report 14, University of Utah, Department */
/*   of Medical Biophysics and Computing, Salt Lake City, Utah, 1979.", */
/*year = "1979" } */


#include <stdlib.h> /* ALL */
#include <stdio.h>  /* ALL */
#include <string.h> /* ALL */
#include <math.h>   /* ALL */
#include "pg.h"     /* ALL */

/** ------------------------- GEMINI.C --------------------------------- **/
/** this version modified : some global variables become local
  FROM CHKBND      :  fun(clb,check,eh,teq : real;
  FROM STEP        :  sumt,twot,ft,f2t,ft2,scal : real;
                      xt : vector;
  USUALLY IN INIB  :  bmat: matrix;
  ARRAYS IN UPDATE :  wtil,ztil,w,z,wtjp1,ztjp1,s,dp : vector;
  UPDATE           :
  sb,sc,sd,fbcd,alpha,sa,thet1,thet2,aa,bb,cc,del2,alph1,alph2,rdiv,
  nu,muj,lambj,lambj2,eta,aj,thj,bj,gamlj,betlj,del : real;
  iswup : integer;
  GEMINI           :   active : boolean; 
                       continue : (go,quit,restart);
                       v, se : vector;
                       tbnd,fsmf,fsav2,t,hx,xsave,fxph,fxmh,xp,xpm,ytp : real;
  SUPPRESSED VARIABLE  : gtg, nsave
**/

/* ALL, taken from masc.h [14May2002] */
#define true 1
#define false 0

/** Valeurs Iterees **/
/*********************/
/* extern  */
/* int nbiterated; */
/* extern  */
/* real *iterated[MAXiterated]; */
/* #define Remove_Iterated(k) \ */
/* 		{ nbiterated--; iterated[k]=iterated[nbiterated]; \ */
/* 			bnd[k][0]=bnd[nbiterated][0]; bnd[k][1]=bnd[nbiterated][1]; \ */
/* 			} */

/** Gemini **/
/************/
typedef real tbound[MAXiterated][2];
/* end ALL [14May2002] */

/* extern */ 
int TOT_NUM_LOCUS;
int TOT_NUM_INDIV;
int NUM_SCALE;
markmap *MAP;
indiv *DATA;
vector xall; 
tmaxn itp;
FILE *outfile, *detfile;
/* End extern */ 

short  offlimit, zeroexpected, singmatrix, interrupt_;
int  nall,n,n0,maxit;
real  f,trupb,h_;
vector  x;
tbound  bnd;
char DetWFormat[] = "%17.10f\n";

/** VARIABLE FROM COMMON MIN1 **/
matrix tl;
vector  d,g,gsave,y,p_;

/** VARIABLE FROM COMMON MIN2 **/
int nit,nfe,idg,idif,isw,icall,ibnd,ihess,ivar,ihx,iret;
real tmin,ptg;

/** DIMENSIONED IN GEMINI **/
real tbnd,t;

/** FROM STEP **/
real  fsave;


/** 'Continue' constants **/
#define go 1
#define quit 2
#define restart 3
#define exit1 4
#define exit2 5
#define exit3 6

/* PROTOTYPES */
void initgemini(FILE *out, FILE *det, int nbiterated, real *iterated[]);
int precision();
void gemini();
void outgemini();

/**************************************************/
void outcontrol(vector z,int nn)
/**************************************************/
{ /** called by proc GEMINI **/
  
  int  i,j;
  
  j=0;
    
  for (i=0; i<nn; i++) 
  {
      fprintf(detfile,DetWFormat,z[i]); fprintf(detfile," ");
      j++;
      if (j==4)
      {
        fprintf(detfile,"\n");
        j=0;
      }
  }
    
  if (j!=0) fprintf(detfile,"\n");
}



/*******************/
void outgemini()
/*******************/
{  /** final output of GEMINI **/
  short i;
  
  for (i=1; i<=60; i++) fprintf(outfile,"-");
  fprintf(outfile,"\n NIT=%3d  NFE= %5d  FINAL F=",nit,nfe);
  fprintf(outfile,DetWFormat,f);
  fprintf(outfile,"\n");
  fprintf(outfile,"PTG=");
  fprintf(outfile,DetWFormat,ptg);
  fprintf(outfile,"\n");

  fprintf(detfile," FINAL XALL :");  /** on detfile **/
  outcontrol(xall,nall);
  fprintf(outfile,"\n");

  /** INDICATES REASON FOR TERMINATION **/
  fprintf(outfile,"ITERATIVE PROCESS TERMINATED BECAUSE:\n");
  printf("ITERATIVE PROCESS TERMINATED BECAUSE:\n");  /* ALL */
  
  switch(idg) {
  case(-1) : 
    fprintf(outfile," No parameter estimation required\n"); 
    printf(" No parameter estimation required\n");   /* ALL */
    break;
  case(0) : 
    fprintf(outfile," Maximum possible accuracy reached\n"); 
    printf(" Maximum possible accuracy reached\n");   /* ALL */
    break;
  case(1) : 
    fprintf(outfile," Search direction no longer downhill\n"); 
    printf(" Search direction no longer downhill\n");   /* ALL */
    break;
  case(2) : 
    fprintf(outfile," Accumulation of rounding error prevents further progress\n");
    printf(" Accumulation of rounding error prevents further progress\n");  /* ALL */
    break;
  case(3) : 
    fprintf(outfile," All significant differences lost through cancellation in conditioning\n");
    printf(" All significant differences lost through cancellation in conditioning\n");  /* ALL */
    break;
  case(4) : 
    fprintf(outfile," Specified tolerance on normalized gradient met\n");
    printf(" Specified tolerance on normalized gradient met\n");  /* ALL */
    break;
  case(5) : 
    fprintf(outfile," Specified tolerance on gradient met\n");
    printf(" Specified tolerance on gradient met\n");  /* ALL */
    break;
   case(6) : 
     fprintf(outfile," Maximum number of iterations reached\n");
     printf(" Maximum number of iterations reached\n");  /* ALL */
     break;
   case(7) : 
     fprintf(outfile," Excessive cancellation in gradient\n");
     printf(" Excessive cancellation in gradient\n");  /* ALL */
     break;
  case(8) : 
    fprintf(outfile," Sum of coupling frequencies exceeds 1\n");
    printf(" Sum of coupling frequencies exceeds 1\n");  /* ALL */
    break;
   case(9) : 
     fprintf(outfile," A probability is equal to 0\n");
     printf(" A probability is equal to 0\n");  /* ALL */
     break;
   case(10) : 
     fprintf(outfile," Singular matrix\n");
     printf(" Singular matrix\n");  /* ALL */
     break;
   case(11): 
     fprintf(outfile," Interruption\n");
     printf(" Interruption\n");  /* ALL */
     break;
  }
  
  fprintf(outfile,"\n");
}


/*-*-*-*-*-*-*-*-*/
void step();
/*-*-*-*-*-*-*-*-*/
/* Defini pour les sous procedures de step */
  int cont; 
  vector xt;                       /*MCB*/
  real sumt,ft;  		   /*MCB*/

 /******************/
 void firststep()
 /******************/
 { int i;
 
   sumt=0;
   idg=0;
      
   for (i=0; i<n; i++) xt[i]=x[i]+t*p_[i];
      
   ft=fun(xt);
   nfe++;
 }

 /*****************/
 void decreaset()
 /*****************/
 {  
  #define small 1.0E-10
    
  int i;
  real ft2,scal;
  
       /** Modified by M. Lathrop 29/04/86 to trap tmin=0 problem **/
  
  if (tmin<small) tmin=small;
  cont=go;
      
  while (cont==go) 
  {
    if (f-fsave==0 && idif==2) idg=2;
          
    if (t<tmin) cont=exit3;
    else /** 1 **/
    {
     t=0.5*t;
     
     for (i=0; i<n; i++) xt[i]=x[i]+t*p_[i];
              
     ft2=fun(xt);
     nfe++;
              
     if (ft2<f)
     {            sumt=sumt+t;
                  f=ft2;
                  idg=0;
                  for (i=0; i<n; i++) x[i]=xt[i];
                  if (sumt<tmin) cont=exit3;
                  			else cont=exit2;
     }
     else /** 2 **/
     {
                  if (ft+f-ft2-ft2<=0) scal=0.1;
                  else
                   {  scal=1+0.5*(f-ft)/(f+ft-ft2-ft2);
                      if (scal<0.1) scal=0.1;
                   }
                  
                  t=scal*t;
                  
                  for (i=0; i<n; i++) xt[i]=x[i]+t*p_[i];
                  ft=fun(xt);
                  nfe++;
                  
                  if (f>ft)
                  {   sumt=sumt+t;
                      idg=0;
                      f=ft;
                      for (i=0; i<n; i++) x[i]=xt[i];
                      if (t<tmin) cont=exit3;
                      		 else cont=exit2;
                  }
      } /** else 2 **/
    } /** else 1 **/
  } /** while **/
}  /** decreaset **/


 /***************/
 void increaset()
 /***************/
 {
     #define curv 0.75
    
      int i;
      real f2t,twot;   /*MCB*/
   
   
      sumt=sumt+t;
      cont=go;
      
      while (cont==go)
      {
          twot=t+t;
          
          if (ibnd>0 && tbnd>=0 && twot>tbnd)
          {   f=ft;
              for (i=0; i<n; i++) x[i]=xt[i];
              fprintf(detfile,"****** ACTIVE BOUNDARY CONSTRAINT *****\n");
/*               printf("****** ACTIVE BOUNDARY CONSTRAINT *****\n"); */
              cont=exit1;
          }
          else
          {
              for (i=0; i<n; i++) 
              { x[i]=xt[i]; xt[i]=x[i]+t*p_[i]; }
              f2t=fun(xt);
              nfe++;
              
              if (f2t>ft)
              {   f=ft;
                  cont=exit2;
              }
              else
                if (f2t+f-ft-ft<0 || (ft-f2t)-curv*(f-ft)>=0)
                {   sumt=sumt+t;
                    t=t+t;
                    ft=f2t;
                }
                else
                  { sumt=sumt+t;
                    f=f2t;
                    for (i=0; i<n; i++) x[i]=xt[i];
                    cont=exit2;
                  }
           }
      } /** while **/
   }   /** increaset **/


/*******************/
void step()
/*******************/
{ int i;

    firststep();
    if (f>ft) increaset(); else decreaset();
    
    if (cont==exit2) t=sumt;
    
    if (cont==exit3) iret=1;
    else
      { for (i=0; i<n; i++) gsave[i]=g[i];
        isw=0;
        iret=2;
      }
}  


/**--------------------------------------------------------------------**/

/*-*-*-*-*-*-*-*-*/
void update();
/*-*-*-*-*-*-*-*-*/
/** Definit pour les sous procedures de update **/   
   
    #define  small 1.0E-10
 
    vector wtil,ztil,w,z,s;                            /*MCB*/
    real sb,sc,sd,fbcd,alpha,sa,thet1,thet2,nu,eta;
    int iswup;

    /******************/
    void prep()
    /******************/
    { int i,k;
      
      iswup=1;
      wtil[0]=-gsave[0];
      ztil[0]=y[0];
      for (k=1; k<n; k++)
      {    
          wtil[k]=-gsave[k];
          ztil[k]=y[k];
          
          for (i=0; i<k; i++)
          {
              tl[i][k]=tl[k][i];
              wtil[k]=wtil[k]-tl[k][i]*wtil[i];
              ztil[k]=ztil[k]-tl[k][i]*ztil[i];
          }
            
      } 
      
      sb=0;
      sc=0;
      sd=0;
      
      for (i=0; i<n; i++)
      {
          sb=sb+t*ztil[i]*wtil[i]/d[i];
          sc=sc+t*t*wtil[i]*wtil[i]/d[i];
          sd=sd+ztil[i]*ztil[i]/d[i];
      }
        
   }  /** prep **/

    /*****************/
    void sr1update()
    /*****************/
    {
      alpha=-1.0;
      if (sc-sb==0 || sb-sd==0 || sd-2.0*sb+sc==0) idg=3;
      else
        { sa=1.0/(sqrt(fabs(sc-sb))*sqrt(fabs(sb-sd)));
          thet1=-((sd-sb)*sa+1.0)/(sd-2.0*sb+sc);
          thet2=sa+(sa*(sb-sc)+1.0)/(sd-2.0*sb+sc);
        }
    }  /** sr1update **/

    /****************/
    void sr2update()
    /****************/
    { 
      short dfp;  /*MCB*/
      real aa,bb,cc,del2,del,alph1,alph2,rdiv;    /*MCB*/
    
      aa=sb/sc-2.0*(sd/sb)+sd/sc;
      bb=sb/sc-1.0;
      cc=1.0-sb/sd;
      del2=bb*bb-aa*cc;
      dfp=true;
      
      if (del2>1e-8)
      {   dfp=false;
          del=sqrt(del2);
          alph1=(-bb+del)/aa;
          alph2=(-bb-del)/aa;
          if (fabs(alph1) < fabs(alph2)) alpha=alph1;
	  else alpha=alph2;
          
          if (fabs(alpha) < 1e-5) dfp=true;
          else
          { sa=(alpha+1.0)*(alpha+1.0)+sc/sb
              -alpha*alpha*(sc/sb)*(sd/sb)
              -1.0+alpha*alpha*sd/sb;
              
              if (sa<=0) sa=0;
              else
                { sa=sqrt(sa);
                  sa=1.0/(sa*sb);
                }
              
              rdiv=1.0/(alpha*alpha*sd+2.0*alpha*sb+sc);
              thet1=-(sa*alpha*(alpha*sd+sb)+1.0)*rdiv;
              thet2=sa+(alpha*sa*(sc+alpha*sb)-alpha)*rdiv;
          }
      }
      
      
      if (dfp)
      {   alpha=0;
          sa=1.0/(sqrt(sb)*sqrt(sc));
          thet1=-1.0/sc;
          thet2=sa;
      }
    }   /** sr2update **/

    /**************/
    void getwzs()
    /**************/
    { int i,j,k,jm1;  /*MCB*/
     
      for (i=0; i<n; i++)
      {   w[i]=t*wtil[i]+alpha*ztil[i];
          z[i]=t*thet1*wtil[i]+thet2*ztil[i];
      }
      
      s[n-1]=0.0;
      
      for (k=1; k<=n-1; k++)
      {   j=n-k;
          jm1=j-1;
          s[jm1]=s[j]+w[j]*w[j]/d[j];
      }
      
      nu=1;
      eta=0;
    }   /** getwzs **/

    /*************/
    void recur()
    /*************/
    { int i,j,k;
      short cont;     /*MCB*/
      real muj,lambj,lambj2,aj,thj,bj,gamlj,betlj;         /*MCB*/
      vector ztjp1,wtjp1,dp; /*MCB*/
    
      cont=true;
      
      while (cont)
      {          
        cont=false;
          
          if (iswup < 2)
          { for (i=0; i<n; i++) wtjp1[i]=-gsave[i];
            for (i=0; i<n; i++) ztjp1[i]=y[i];
          }
          else
          {
             for (i=0; i<n; i++)
             {    wtil[i]=-t*g[i]+alpha*y[i];
                  ztil[i]=-t*thet1*g[i]+thet2*y[i];
             }
          }
          
          j=0;
          lambj2=0;
          
          while (j<n-1)
          {
              if (iswup<2)
                for (k=j+1; k<n; k++)
                {
                    wtjp1[k]=wtjp1[k]-wtil[j]*tl[k][j];
                    ztjp1[k]=ztjp1[k]-ztil[j]*tl[k][j];
                }
              else
                for (k=j+1; k<n; k++)
                {   
                    wtjp1[k]=wtil[k]-w[j]*tl[k][j];
                    ztjp1[k]=ztil[k]-z[j]*tl[k][j];
                }
              
              aj=nu*z[j]-eta*w[j];
              thj=1.0+aj*w[j]/d[j];
              lambj2=thj*thj+aj*aj*s[j]/d[j];
              
              if (iswup<2)
              {
                if (lambj2>10)
                {     cont=true;
                      iswup=2;
                      for (k=1; k<n; k++)
                        for (i=0; i<k; i++)
                          tl[k][i]=tl[i][k];
                      j=n-1;
                }
              }
              
              if (!cont)
              {   
                  dp[j]=d[j]*lambj2;
                  lambj=sqrt(lambj2);
                  if (thj>0) lambj=-lambj;
                  muj=thj-lambj;
                  bj=thj*w[j]+aj*s[j];
                  gamlj=bj*nu/(lambj2*d[j]);
                  betlj=(aj-bj*eta)/(lambj2*d[j]);
                  nu=-nu/lambj;
                  eta=-(eta+aj*aj/(muj*d[j]))/lambj;
                  
                  if (iswup<2)
                    for (k=j+1; k<n; k++)
                      tl[k][j]=tl[k][j]+t*(betlj+thet1*gamlj)*wtjp1[k]+
                      (alpha*betlj+thet2*gamlj)*ztjp1[k];
                  else
                    for (k=j+1; k<n; k++)
                    {   tl[k][j]=tl[k][j]/lambj2+betlj*wtil[k]+gamlj*ztil[k];
                        wtil[k]=wtjp1[k];
                        ztil[k]=ztjp1[k];
                    }
               }
              
              j++;
            }
        }
      
      aj=nu*z[n-1]-eta*w[n-1];
      lambj=1.0+aj*w[n-1]/d[n-1];
      dp[n-1]=d[n-1]*lambj*lambj;
      for (i=0; i<n; i++) d[i]=dp[i];
  
    }  /*recur*/



  /************/
  void update()
  /************/
  {
    prep();
    
    if (sb<sc) fbcd=sb;
    	  else fbcd=sc;
    
    if (sd<fbcd) fbcd=sd;
    if (fbcd>small)
    {   
        fbcd=2.0*sc*(sd/sb)/(sc+sd);
        
        if (fbcd < 1) sr1update();
        		 else sr2update();
    }
    else sr1update();
    
    if (idg!=3)
    {
        getwzs();
        recur();
    }
  }   /** update **/
  
  
/*--------------------------------------------------------------------*/

/*START GEMINI*/
  
  
  /*-*-*-*-*-*-*-*/
  void gemini();
  /*-*-*-*-*-*-*-*/
   short active;               /*MCB*/
   short continu;   	       /*MCB*/
   vector v_,se;               /*MCB*/
   real fsmf,ytp;              /*MCB*/

    
    /***************************/
    void bldlt(matrix b)
    /***************************/
    { 
      int i,j,ic,k;      
      real su,tlic,ff,hh,temp,temp1;
      matrix s;
      vector tu,xvec;
    
    
      ff=f;  
      if (icall>0 || ihess<=0) {
	for (i=0; i<n; i++) xvec[i]=xall[i]; 
	hh=10*h_;
	for (i=0; i<n; i++)
          {
              temp=x[i];
              x[i]=x[i]+hh;
              f=fun(x);
              tu[i]=f;
              
              for (j=0; j<=i; j++)
              {
                  temp1=x[j];
                  x[j]=x[j]+hh;
                  f=fun(x);
                  b[i][j]=f;
                  b[j][i]=b[i][j];
                  x[j]=temp1;
              }
              
              x[i]=temp;
          }
          
          for (i=0; i<n; i++) xall[i]=xvec[i];
          for (i=0; i<n; i++)
            for (j=0; j<=i; j++)
              { 
                b[i][j]=(ff+b[i][j]-tu[i]-tu[j])/(hh*hh);
                b[j][i]=b[i][j];
              }
      }

      ic=0;
      
      while (b[ic][ic]>0.0 && ic<n)
      {
          temp=b[ic][ic];
          d[ic]=b[ic][ic];
          tl[ic][ic]=1;
          if (ic!=n-1)
          {
              for (k=ic+1; k<n; k++) tl[k][ic]=b[k][ic]/temp;
              for (i=ic+1; i<n; i++)
              {
                  tlic=tl[i][ic];
                  for (k=i; k<n; k++)
                    b[k][i]=b[k][i]-tlic*tl[k][ic]*temp;
              }
          }
          
          ic++;
      }
      
      if (ic>n-1)
      {   icall--;
          fprintf(detfile,"FACTORIZATION SUCCEEDED\n");
      }
      else
        {
          icall++;
          fprintf(detfile,"FACTORIZATION FAILED\n");
        }
      
      if (icall==0)
      {
          s[0][0]=1;
          
          for (i=1; i<n; i++)
          {
              for (k=0; k<=i-1; k++)
              {
                  su=0.0;
                  for (j=k; j<=i-1; j++) su+=tl[i][j]*s[j][k];
                  s[i][k]=-su;
              }
              
              s[i][i]=1.0;
          }
          
          for (i=0; i<n; i++)
            for (j=i; j<n; j++)
              {
                su=0.0;
                
                for (k=j; k<n; k++) su+=s[k][i]*s[k][j]/d[k];

                b[i][j]=su;
                b[j][i]=su;
              }
          
          fprintf(detfile,"B-MATRIX\n");
          
          for (i=0; i<n; i++)
          {
              for (j=0; j<=i; j++) 
              { fprintf(detfile,DetWFormat,b[i][j]);
                fprintf(detfile," ");
              }
              fprintf(detfile,"\n");
          }
          
          if (ivar==1)
          {   
              k=0;
              for (i=0; i<nall; i++)
              {
                  se[i]=0;
                  if (itp[i]==1)
                  {   se[i]=sqrt(b[k][k]);
                      k++;
                  }
              }
          }
       }
    }  /** bldlt **/

    /************/
    void inib()
    /************/
    { int i,j;
      FILE *in1;
      matrix bmat;  /*MCB*/
    
      if (icall!=1 && ihess>1)
      {
          in1=fopen("FileNotUsed","r");
          
          for (i=0; i<n; i++)
            for (j=0; j<=i; j++)
              fscanf(in1,DetWFormat,bmat[i][j]);
          
          for (i=0; i<n; i++)
            for (j=0; j<=i; j++)
              bmat[j][i]=bmat[i][j];
      }
      
      bldlt(bmat);
      
      if (icall==1)
      {
          for (i=0; i<n; i++)
          {
              for (j=0; j<=i; j++) tl[i][j]=0;
              tl[i][i]=1;
              d[i]=1;
          }
      }
      
    }  /** inib **/

    
    /******************/
    void initialize()
    /******************/
    {
      int i,j;
    
      fprintf(detfile,"DIFFER INTER =");
      fprintf(detfile,DetWFormat,h_);
      fprintf(detfile,"  TRUNC UPPER = ");
      fprintf(detfile,DetWFormat,trupb);
      fprintf(detfile,"\n");
      nit=0;
      idg=0;
      idif=1;
      t=0.1;
      tmin=0;
      fsmf=0;
      f=fun(x);
      nfe=1;
      
      for (i=0; i<n; i++)
      {
          for (j=0; j<=i; j++) tl[i][j]=0;
          
          tl[i][i]=1;
          d[i]=1;
      }
      
      if (ihess>0)
      {
          icall=0;
          inib();
          icall=1;
          t=1;
      }
    }  /** initialize **/

    
    /********************/
    void gforward()
    /********************/
    {  int i;
       real fxph, hx,xsave;    /*MCB*/
    
      for (i=0; i<n; i++)
      {
          hx=h_;
          
          if (ihx==1)
          {
            if (fabs(x[i])<0.1) hx=h_*0.1;
	    else hx=h_*fabs(x[i]);
          } /* added by ALL */
	  xsave=x[i];
	  x[i]=x[i]+hx;
	  fxph=fun(x);
	  g[i]=(fxph-f)/hx;
	  x[i]=xsave;
	  /* }  commented out by ALL */
 

      }

      nfe=nfe+n;
    }   /** gforward **/

    
    /*************************/
    void gcentral()
    /*************************/
    {
      int i;
      real fxph, fxmh, hx,xsave;  /*MCB*/
     
     
      for (i=0; i<n; i++)
      {
          hx=h_;
          
          if (ihx==1) {/* added by ALL */
            if (fabs(x[i])<0.1) hx=h_*0.1;
	    else hx=h_*fabs(x[i]);
          }/* added by ALL */
	  xsave=x[i];
	  x[i]+=hx;
	  fxph=fun(x);
          
	  x[i]=xsave-hx;
	  fxmh=fun(x);
	  g[i]=(fxph-fxmh)/(hx+hx);
	  x[i]=xsave;
	 
      }
      
      nfe+=n+n;
    }  /** gcentral **/

    
    /************/
    void getp()
    /************/
    {
     #define xpmcon 1.0E30
    
     int i,nmj,j;
     real fsav2,xp,xpm;
     char s[256];
     char s2[40];
	
      nit++;
      fsav2=fsave;
      fsave=f;
      
      sprintf(s,"ITERATION %d   T = ",nit); 
      sprintf(s2,DetWFormat,t); strcat(s,s2);
      sprintf(s2,"\n   NFE = %d   F = ",nfe); strcat(s,s2);
      sprintf(s2,DetWFormat,f); strcat(s,s2);
      
      fprintf(detfile,s);
      fprintf(detfile,"\n");
/*
      Message(s);
      MessageBar(nit*100/(maxit+1));
*/
      
      if (nit>maxit) idg=6;
        else
         {
          if (n<20) 
          			{
                       fprintf(detfile,"X= ");
                       outcontrol(x,n);
                       fprintf(detfile,"G= ");
                       outcontrol(g,n);
                    }

          if (n==1) p_[0]=-g[0]/d[0];
                 else
                    {
                      v_[0]=-g[0];
                      
                      for (i=1; i<n; i++)
                      {
                        v_[i]=-g[i];
                        for (j=0; j<i; j++) v_[i]-=tl[i][j]*v_[j];
                      }
                      
                      p_[n-1]=v_[n-1]/d[n-1];
                      
                      for (j=1; j<=n-1; j++)
                      {
                        nmj=n-j-1;
                        p_[nmj]=v_[nmj]/d[nmj];
                        
                        for (i=nmj+1; i<n; i++) p_[nmj]=p_[nmj]-tl[i][nmj]*p_[i];
                      }
                    }
          
          fprintf(detfile,"P= ");
          outcontrol(p_,n);
          
          if (ibnd==1)
            for (i=0; i<n; i++)
              if (p_[i]==0) idg=7;
          
          if (idg!=7)
          {
            ptg=0;
            
            for (i=0; i<n; i++)  ptg+=p_[i]*g[i];
            
            if (ptg>=0) idg=1;
              else
              {
                if (fabs(ptg)<tol)
                {
                  idg=4;
                  fsmf=fsav2-f;
                  fprintf(detfile,"FSMF =");
                  fprintf(detfile,DetWFormat,fsmf);
                  fprintf(detfile,"   PTG =");
                  fprintf(detfile,DetWFormat,ptg);
                  fprintf(detfile,"   TMIN =");
                  fprintf(detfile,DetWFormat,tmin);
                  fprintf(detfile,"\n");
                }
                else
                {
                  xpm=xpmcon;
                  
                  if (nit!=1)
                  {
                    for (i=0; i<n; i++)
                      if (ihx==1)
                       {
                         xp=fabs(x[i]);
                         if (xp<0.1) xp=0.1;
                         xp/=fabs(p_[i]);
                         if (xp<xpm) xpm=xp;
                       }
                       else
                       		if (xpm>fabs(1.0/p_[i])) xpm=fabs(1.0/p_[i]);
                       
                     tmin=0.5*xpm*h_/trupb;
                     
                     if (idif==2) t=1;
                     else
                     {
                         t=-2.0*fsmf/ptg;
                         if (t<=0.0) t=1.0;
                           else 
                               if (t>1) t=1;
                     }
                     
                    fprintf(detfile,"FSMF =");
                  	fprintf(detfile,DetWFormat,fsmf);
                  	fprintf(detfile,"   PTG =");
                  	fprintf(detfile,DetWFormat,ptg);
                  	fprintf(detfile,"   TMIN =");
                  	fprintf(detfile,DetWFormat,tmin);
                  	fprintf(detfile,"\n");
                  	fprintf(detfile,"INITIAL T =");
                  	fprintf(detfile,DetWFormat,t);
                  	fprintf(detfile,"\n");
                     
                     for (i=1; i<60; i++) fprintf(detfile,"-");
                     fprintf(detfile,"\n");
                   } /** if **/
                 } /** else **/
              } /** else **/
            } /** if **/
        } /** else **/
    }  /** getp **/

    
    
    /************/
    void getytp()
    /************/
    {   int i;
   
      ytp=0;
      fsmf=fsave-f;
      
      for (i=0; i<n; i++)
       {
         y[i]=g[i]-gsave[i];
         ytp+=y[i]*p_[i];
	   }
	   
    }     /** getytp **/

    
    /*****************/
    void chkbnd()
    /*****************/
    /** This procedure modified by M. Lathrop 29/04/86
     with the introduction of continue and repeat
     this procedure modified by M.C. Babron april 87
      for setting the variable to a bound  **/
    
    {
      #define clbcon 1.0e10
      #define tbndcon 1.0e5
    
      int i,j,k;
      int ik=0;
      int ii=0;
      int jk=0;
      short continu;

    /** FROM CHKBND *****/
      real clb,check,eh,teq;

     do
     {
        clb=clbcon;
        for (j=0; j<=1; j++)
        {
            k=0;
            for (i=0; i<nall; i++)
            { 
              if (itp[i]==1)
              {
                    check=fabs(x[k]-bnd[i][j]);
                    
                    if (check<=clb)
                    {
                        clb=check;
                        ik=k;
                        ii=i;
                        jk=j;
                    }
                    k++;
              }
            }
        }
        
        if (clb<0.1*h_)
        {
           ihess=0;
	   if (jk==1) { eh=-h_-h_; }/* upper bound reached */
	   else { eh=h_+h_;}        /* lower bound reached */
            
 /** MCB correction to have the same as the fortran version of GEMINI **/
/* 	   if (jk==1) eh=h_+h_;  */
/*             	  else eh=-h_-h_; */
            	  
            x[ik]=bnd[ii][jk]+eh;
            xall[ii]=x[ik];
            itp[ii]=0;
            k=0;
            
            for (i=0; i<nall; i++)
              if (itp[i]==1) { x[k]=xall[i]; k++; }
              
            n=k;
            continu=true;
            fprintf(detfile,"******* A VARIABLE WAS SET TO A BOUND ***********\n");
        }
        else
        {
            tbnd=tbndcon;
            for (j=0; j<=1; j++)
              {
                k=0;
                for (i=0; i<nall; i++)
                  if (itp[i]==1)
                  {
                      teq=(bnd[i][j]-x[k])/p_[k];
                      if (teq<tbnd && teq>0.0) tbnd=teq;
                      k++;
                  }
              }
            
            continu=false;
            if (t*(2.0+h_)>=tbnd) t=tbnd*(0.5-h_);
            
            fprintf(detfile,"TBND = ");
            fprintf(detfile,DetWFormat,tbnd);
            fprintf(detfile," RESET T = %f\n",t);
        }
      }
      while (continu);
    }  /** checkbound **/

    
    /******************/
    void iterate()
    /******************/
    {
      while (continu==go)
        {
          active=false;
          getp();
          
          
          /** MCB : test whether offlimit is true or not **/
          /** if true sets idg to 8 **/
          if (offlimit) idg=8;
          
          /** MCB : test whether zeroexpected is true or not **/
          /** if true sets idg to 9 **/
          if (zeroexpected) idg=9;
          
          /** MCB : test whether singmatrix is true or not **/
          /** if true sets idg to 10 **/
          if (singmatrix) idg=10;
          
          /** AC : test if job interrupted **/
          /** if true sets idg to 11 **/
          if (interrupt_) idg=11;
                   
          if (idg!=0) continu=quit;
          if (idg==0)
          {
              iret=2;
	      if (ibnd==1) chkbnd();
              if (n==0) continu=quit;
              if (!active) step();
          }
/*           printf("active=%hd\n",active); */

          /* THE NEXT IS NOT TRUE if ACTIVE */
          if (iret!=2)
          {
              if (idif==1)
              {
                  idif=2;
                  isw=1;
                  gcentral();
                  fprintf(detfile,"***** SWITCHING TO CENTRAL DifFERERENCE*****\n");
              }
              else
                continu=quit;
          }
          else
            if (!active)
            {
                if (idif==1) gforward();
                		else gcentral();
                if (isw==0)
                {
                    getytp();
                    if (ytp > 0.0)
                    {
                        if (n==1) d[0]=-y[0]*d[0]/(t*gsave[0]);
                        else update();
                        if (idg==3) continu=quit;
                    }
                }
            }
            else
              continu=restart;
	  printf("%5d\t%17.10f\t%17.10f\t%21.10f\n",nit,xall[0],xall[1],-fun(xall)); /*ALL*/

        }
    }   /** iterate **/


  /******************/
  void gemini()
  /******************/
 {  
    /** MCB : set continue to quit if no parameter to be estimated **/
    /** input of some gemini parameters **/
   int i;

  ihess=0;
  ibnd=1;  /* existence of boundary constraints */
  /*ALL [14May2002]: to set boundery values */
  for (i=0; i<nall; i++) {
    bnd[i][0]=0+h_+h_; bnd[i][1]=1-h_-h_;            /* 0< INBREED <1     */
    bnd[i+1][0]=0+h_+h_; bnd[i+1][1]=1.7E+308-h_-h_; /* 0< A < MAX DOUBLE */
    /* bnd[i+1][0]=0+h_+h_; bnd[i+1][1]=1; */ /* 0< A < MAX DOUBLE */
    i++;
  }  
  icall=1;
  ivar=1;
  ihx=1;
  if (n==0)
  {
      initialize();
      idg=-1;
      continu=quit;
  }
  else continu=go;
 
  while (continu!=quit)
  {
    initialize();
    isw=0;
    gforward(); 
    continu=go;
    iterate();
  }

  if (ivar==1) inib();
 }



/*****************/
int precision()
/*****************/
/* Determines number of bits of machine precision, ie, length of mantissa
   Program from BYTE, Feb. 1985, page 231 
*/
#define one 1.0
#define zero 0.0
#define minusone -1.0
{
   real radix,precision,width,wide;
   real xx,y,z;

   wide=one;

   do
   {
     wide=wide+wide;
     xx=wide+one;
     y=xx-wide;
     z=y-one;
   } while ((minusone+fabs(z))<zero);
    
    y=one;
    
    do
    {
     radix=wide+y;
     y=y+y;
     radix=radix-wide;
    } while (radix==zero);
    
    precision=zero;
    width=one;


    do
    {
     precision=precision+one;
     width=width*radix;
     y=width+one;
    } while ((y-width)==one);
    
     return precision-1;
 }  /** precision **/


/*******************************/
void initgemini(FILE *out, FILE *det, int nbiterated, real *iterated[])
/*******************************/
/* Added by A.Clerget to link the Gemini module to the rest of the program */
     /* Modified by AL leutenegger to link Gemini to E-M algo */
{ int i,nbit;
  outfile=out;
  detfile=det;
 
  nall=nbiterated;
  for (i=0; i<nall; i++) 
  { xall[i]=(*iterated[i]); 
  	x[i]=xall[i];
  	itp[i]=1;
  }
  
  n=nall;
  n0=nall;
  
  offlimit=false;
  zeroexpected=false;
  singmatrix=false;
  interrupt_=false;
  
  nbit=precision();
  h_=sqrt(exp(-nbit*log(2.0)));
  trupb=sqrt(h_);
  maxit=10*nall; /* ALL maxit=5*nall; */
}

