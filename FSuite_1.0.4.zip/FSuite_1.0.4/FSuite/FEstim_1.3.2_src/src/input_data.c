/***************************************************/
/*        Read marker & data from 2 files          */
/*                                      [May 2002] */
/* Added [Feb 2006]: read sample lodscore          */
/*                   computed ignoring inbreeding  */
/* Added [July 2006]: read family lodscores        */
/*                    computed ignoring inbreeding */
/* Added [Augu 2008]: allow inputs as PLINK format */
/* Name: input_data.c                              */
/* Anne-Louise Leutenegger                         */
/***************************************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "pg.h"

/* extern */
int cM;
int TOT_NUM_LOCUS;
int TOT_NUM_INDIV;
int TOT_NUM_FAM;
int TOT_NUM_ISO;
int NUM_SCALE;
markmap *MAP;
indiv *DATA;
int *DATAisZERO;
vector xall; 
tmaxn itp;
FILE *outfile, *detfile;
/* End extern */ 

char *my_strchr(char *string_ptr, char find) {
  while (*string_ptr != find) {
    if (*string_ptr=='\0') return NULL; /* not end of string yet */
    ++string_ptr;
  }
  return string_ptr;
}

int Init_marker(char *filename, int *tot_num_locus) {
  FILE *IN;
  char *line;
  char *last, *tokenPtr, *found_tab;
  int nmarker=0, content=0;

  
  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Init_Marker\n"); 
    return 0;
  }
  
  if (filename==NULL) { 
    Eprintf("No marker file name for Init_marker\n"); 
    return 0; 
  }
  if((IN=fopen(filename,"r")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Init_marker\n",filename); 
    return 0;
  }
  while (!feof(IN)) {
    content=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    /* if there is a line separator it would be at the end */
    last = strchr(line, '\0');
    /* look for LF & replace it */
    if (last - 1 >= line && *--last == '\n') {
      *last = '\0';
    }
    /* look for CR & replace it */
    if (last - 1 >= line && *--last == '\r') {
      *last = '\0';
    }
    /* now do something useful with newline-free string in line */ 
    found_tab=my_strchr(line,'\t'); 
    while (found_tab!=NULL) { 
      *found_tab=' ';  
      found_tab=my_strchr(line,'\t'); 
    } 
    tokenPtr=strtok(line," ");
    while (tokenPtr!=NULL) {
      if (!(strcmp(tokenPtr," ")==0 || strcmp(tokenPtr,"\t")==0 
	    || strcmp(tokenPtr,"")==0)) {
	content++;
      }
      tokenPtr=strtok(NULL," ");
    }
    if (content==0) continue;
    nmarker++;
  }
  fclose(IN);

  *tot_num_locus=nmarker;
  MAX_LENGTH_LINE=8+MAX_LENGTH_FAMID+3*MAX_LENGTH_ID+6*nmarker;
  if ((MAP=(markmap *) calloc(*tot_num_locus,sizeof(markmap)))==NULL) {
    Eprintf("\nCould not allocate memory for MAP in Init_marker\n"); 
    return 0;
  }
	free(line);
  return 1;
}

int Get_marker_information(char *filename, markmap *map) {
  FILE *IN;
  char *tokenPtr, *found_tab;
  char *line;
  int l=0,token=0,na=1,test_na=1;
  double test_freq=0.;
  
  
  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Get_marker_information\n"); 
    return 0;
  }
  
  if (filename==NULL) { 
    Eprintf("No marker file name for Get_marker_information\n"); 
    return 0; 
  }
  if((IN=fopen(filename,"r")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Get_marker_information\n",
	    filename); 
    return 0;
  }
  while (!feof(IN)) {
    if(l>=TOT_NUM_LOCUS)  break;
    token=0; test_na=1; test_freq=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    tokenPtr=strtok(line," ");

    while (tokenPtr!=NULL) {
      switch (token) {
      case 0:
	map[l].name=(char *) calloc(MAX_NAME_MARKER,sizeof(char));
	if (map[l].name==NULL) return 0;
	memcpy(map[l].name,tokenPtr,MAX_NAME_MARKER);
	token++; 
	break;
      case 1:
	map[l].chr=atoi(tokenPtr); 
	token++; 
	break;
      case 2:
	if (cM==1) {map[l].dist=atof(tokenPtr); } else {map[l].dist=atof(tokenPtr)/100; }
	if (l>0 && map[l].chr == map[l-1].chr && map[l].dist<map[l-1].dist) {
	  Eprintf("Problem with marker %s: wrong distance\n",map[l].name);
	  return 0;
	}
	token++; 
	break;
      case 3:
	map[l].num_allele=atoi(tokenPtr); 
	map[l].allele_name=(int *) calloc(map[l].num_allele+1,sizeof(int));
	if (map[l].allele_name==NULL) return 0;
	map[l].freq=(double *) calloc(map[l].num_allele+1,sizeof(double));
	if (map[l].freq==NULL) return 0;
	/*	map[l].freq[0]=map[l].num_allele;ALL April2009*/
	map[l].freq[0]=0; /* initialize to get Homozygosity */
	token++; 
	break;
      case 4:
	na=atoi(tokenPtr);
	if(na != test_na) {
	  if (strcmp(tokenPtr,"\n")==0 || strcmp(tokenPtr,"\r")==0
	      || strcmp(tokenPtr,"\r\n")==0) {
	    break;
	  } else {
	    Eprintf("Problem with marker %s: allele name should be from 1 to number of alleles,\n",
		   map[l].name);
	    Eprintf("in increasing order, without any gaps\n");
	    return 0;
	  }
	}
	map[l].allele_name[na]=atoi(tokenPtr);
	token++;
	break;
      case 5:
	map[l].freq[na]=(double)(atof(tokenPtr));
	/* Compute Expected Homozygosity */
	map[l].freq[0]+=(map[l].freq[na])*(map[l].freq[na]);
	/**/
	test_freq+=map[l].freq[na];
	token--; test_na++;
/* Doesn't seem to help catch mistakes */
/* 	if (test_na < map[l].num_allele) {token--; test_na++;} */
/* 	else {token++;} */
	break;
      default:
	Eprintf("Problem with marker %s: too many fields\n",
	       map[l].name);
	return 0;
	break;
      }
      tokenPtr=strtok(NULL," ");
    }
    if (map[l].num_allele != (test_na-1)) {
      Eprintf("Problem with marker %s: wrong number of fields\n",
	     map[l].name);
      return 0;
    }
    if (fabs(1-test_freq) >= TOL_ALLELE_FREQ) {
      Eprintf("Marker %s: sum of allele frequencies=%f, not 1 and difference>%f.\n",
	      map[l].name,test_freq,TOL_ALLELE_FREQ);
      test_freq=0;
      return 0;
    } else {
      if (test_freq!=1.) {
	for (na=1;na<=map[l].num_allele;na++) {
	  map[l].freq[na]/=(double)test_freq;
	}
      }
      test_freq=0;
    }
    l++;
    line[0]='\0';
  }
  if(l<TOT_NUM_LOCUS) {
    Eprintf("Less marker loci read (%d) than announced (%d)\n",
	   l,TOT_NUM_LOCUS);
    return 0;
  }
  free(line);
  fclose(IN);
  return 1;
}

int Init_marker_plinkformat(char *filename, int *tot_num_locus) {
  FILE *IN;
  char *line;
  char *last, *tokenPtr, *found_tab;
  int nmarker=0, content=0;
  char *filenameExt;
  int charlg;

  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Init_marker_plinkformat\n"); 
    return 0;
  }  
  
  if (filename==NULL) { 
    Eprintf("No marker file name for Init_marker\n"); 
    return 0; 
  }
  charlg=strlen(filename);
  if ((filenameExt=(char *) calloc(charlg+5,sizeof(char)))==NULL) {
    Eprintf("Init_marker_plinkformat: Could not allocate memory for %s.map", filename);
    return 0;  
  }
  sprintf(filenameExt,"%s.map",filename);
  if((IN=fopen(filenameExt,"r")) == NULL) { 
    Eprintf("File \"%s.map\" could not be opened in Init_marker_plinkformat\n",filename); 
    return 0;
  }
  while (!feof(IN)) {
    content=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    /* if there is a line separator it would be at the end */
    last = strchr(line, '\0');
    /* look for LF & replace it */
    if (last - 1 >= line && *--last == '\n') {
      *last = '\0';
    }
    /* look for CR & replace it */
    if (last - 1 >= line && *--last == '\r') {
      *last = '\0';
    }
    /* now do something useful with newline-free string in line */
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    tokenPtr=strtok(line," ");
    while (tokenPtr!=NULL) {
      if (!(strcmp(tokenPtr," ")==0 || strcmp(tokenPtr,"\t")==0 
	    || strcmp(tokenPtr,"")==0)) {
	content++;
      }
      tokenPtr=strtok(NULL," ");
    }
    if (content==0) continue;
    nmarker++;
  }
  fclose(IN);

  *tot_num_locus=nmarker;
  MAX_LENGTH_LINE=8+MAX_LENGTH_FAMID+3*MAX_LENGTH_ID+6*nmarker;
  if ((MAP=(markmap *) calloc(*tot_num_locus,sizeof(markmap)))==NULL) {
    Eprintf("\nCould not allocate memory for MAP in Init_marker_plinkformat\n"); 
    return 0;
  }
  free(line);
  free(filenameExt);
  return 1;
}

int Get_marker_information_plinkformat(char *filename, markmap *map) {
  FILE *IN;
  char *tokenPtr, *found_tab;
  char *line;
  int l=0,token=0,na=1,test_na=1, charlg;
  double test_freq=0.;
  char *filenameExt;
  
  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Get_marker_information_plinkformat\n"); 
    return 0;
  }
  
  if (filename==NULL) { 
    Eprintf("No marker file name for Get_marker_information_plinkformat\n"); 
    return 0; 
  }
  charlg=strlen(filename);

  if ((filenameExt=(char *) calloc(charlg+5,sizeof(char)))==NULL) {
    Eprintf("Get_marker_information_plinkformat: Could not allocate memory for %s.map", filename);
    return 0;  
  }
  sprintf(filenameExt,"%s.map",filename);
  if((IN=fopen(filenameExt,"r")) == NULL) { 
    Eprintf("File \"%s.map\" could not be opened in Get_marker_information_plinkformat\n", filename); 
    return 0;
  }
  while (!feof(IN)) {
    if(l>=TOT_NUM_LOCUS)  break;
    token=0; test_na=1; test_freq=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    tokenPtr=strtok(line," ");

    while (tokenPtr!=NULL) {
      switch (token) {
      case 0:
	map[l].chr=atoi(tokenPtr); 
	token++; 
	break;
      case 1:
	map[l].name=(char *) calloc(MAX_NAME_MARKER,sizeof(char));
	if (map[l].name==NULL) return 0;
	strcpy(map[l].name,tokenPtr);
	token++; 
	break;
      case 2:
	if (cM==1) {map[l].dist=atof(tokenPtr); } else {map[l].dist=atof(tokenPtr)/100; }
	if (l>0 && map[l].chr == map[l-1].chr && map[l].dist<map[l-1].dist) {
	  Eprintf("Problem with marker %s: wrong distance\n",map[l].name);
	  return 0;
	}
	token++; 
	break;
      default:
/* 	Eprintf("Plink-format: Problem with marker %s: too many fields\n", */
/* 	       map[l].name); */
/* 	return 0; */
	break;
      }
      tokenPtr=strtok(NULL," ");
    }
    l++; /* Eprintf("%s:l=%d\n",map[l].name,l); */
    line[0]='\0';
  }
  if(l<TOT_NUM_LOCUS) {
    Eprintf("Less marker loci read (%d) than announced (%d)\n",
	   l,TOT_NUM_LOCUS);
    return 0;
  }
  fclose(IN);

  sprintf(filenameExt,"%s.frq",filename);
  if((IN=fopen(filenameExt,"r")) == NULL) { 
    Eprintf("File \"%s.frq\" could not be opened in Get_marker_information_plinkformat\n", filename); 
    return 0;
  }
  l=0;
  while (!feof(IN)) {
    if(l>=TOT_NUM_LOCUS)  break;
    token=0; test_na=1; test_freq=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    tokenPtr=strtok(line," ");

    while (tokenPtr!=NULL) {
      switch (token) {
      case 0:
	token++; 
	break;
      case 1:
	token++; 
	break;
      case 2:/* Minor Allele (MA), see PLINK(v1.02; March 27, 2008) doc p59 */
	map[l].num_allele=2; 
	map[l].allele_name=(int *) calloc(map[l].num_allele+1,sizeof(int));
	if (map[l].allele_name==NULL) return 0;
	map[l].freq=(double *) calloc(map[l].num_allele+1,sizeof(double));
	if (map[l].freq==NULL) return 0;
	map[l].freq[0]=map[l].num_allele;
	na=atoi(tokenPtr);
	map[l].allele_name[na]=atoi(tokenPtr);
	token++; 
	break;
      case 3:/* Major Allele, see PLINK(v1.02; March 27, 2008) doc p59 */
	na=atoi(tokenPtr);
	map[l].allele_name[na]=atoi(tokenPtr);
	token++;
	break;
      case 4:
	if (na == 1) {
	  map[l].freq[2]=(double)(atof(tokenPtr));/* MAF, MA=2 */
	  map[l].freq[1]=1-(double)(atof(tokenPtr));
	} else if (na == 2) {
	  map[l].freq[1]=(double)(atof(tokenPtr));/* MAF, MA=1 */
	  map[l].freq[2]=1-(double)(atof(tokenPtr));
	} else {
	  Eprintf("Error:marker %s: more than 2 alleles (1, 2 only)\n",
		  map[l].name);
	  return 0;
	}
	token++;
	break;
      default:
/* 	Eprintf("Problem with marker %s: too many fields\n", */
/* 	       map[l].name); */
/* 	return 0; */
	break;
      }
      tokenPtr=strtok(NULL," ");
    }
   /*  Eprintf("%s:%d\n",map[l].name,map[l].num_allele); */
    l++;
    line[0]='\0';
  }
  if(l<TOT_NUM_LOCUS) {
    Eprintf("Less marker loci read (%d) than announced (%d)\n",
	   l,TOT_NUM_LOCUS);
    return 0;
  }
  free(line);
  free(filenameExt);
  fclose(IN);
  return 1;
}

int Print_marker_information(char *filename, markmap *map) {
  int l,n;
  FILE *OUT;

  if((OUT=fopen(filename,"w")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Print_marker_information\n",
	    filename); 
    return 0;
  }
  for (l=0;l<TOT_NUM_LOCUS;l++) {
    fprintf(OUT,"Locus %d: %8s*%2d*%6.3f*%3d*",
	    l,map[l].name,map[l].chr,map[l].dist,map[l].num_allele);
    for (n=0;n<map[l].num_allele+1;n++) {
      fprintf(OUT,"%3d*%5.3f*",map[l].allele_name[n],map[l].freq[n]);
    } fprintf(OUT,"\n");
  }

  fclose(OUT);
  fflush(OUT);
  return 1;
}

int Free_marker(markmap *map, int nmarker) {
  int l;

  for (l=0;l<nmarker;l++) {
    free(map[l].name); map[l].name=NULL;
    free(map[l].freq); map[l].freq=NULL;
    free(map[l].allele_name); map[l].allele_name=NULL;
  }
  free(map);

  return 1;
}

int Init_data(char *filename, int *tot_num_indiv) {
  FILE *IN;
  char *line;
  char *last, *found_tab, *tokenPtr;
  int nindiv=0, content=0;
  
  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Init_data\n"); 
    return 0;
  }  
  
  if (filename==NULL) { 
    Eprintf("No data file name for Init_data\n"); 
    return 0; 
  }
  if((IN=fopen(filename,"r")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Init_data\n",filename); 
    return 0;
  }
  while (!feof(IN)) {
    content=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    /* if there is a line separator it would be at the end */
    last = strchr(line, '\0');
    /* look for LF & replace it */
    if (last - 1 >= line && *--last == '\n') {
      *last = '\0';
    }
    /* look for CR & replace it */
    if (last - 1 >= line && *--last == '\r') {
      *last = '\0';
    }
    /* now do something useful with newline-free string in line */
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    tokenPtr=strtok(line," ");
    while (tokenPtr!=NULL) {
      if (!(strcmp(tokenPtr," ")==0 || strcmp(tokenPtr,"\t")==0 
	    || strcmp(tokenPtr,"")==0)) {
	content++;
      }
      tokenPtr=strtok(NULL," ");
    }
    if (content==0) continue;
    nindiv++;
  }
  fclose(IN);

  *tot_num_indiv=nindiv;
  if ((DATA=(indiv *) calloc(*tot_num_indiv,sizeof(indiv)))==NULL) {
    Eprintf("\nCould not allocate memory for DATA in Init_data\n"); 
    return 0;
  }
  free(line);
  return 1;
}

int Get_data_information(markmap *map, char *filename, 
			 int *data0, char *sample, indiv *data) {
  FILE *IN;
  char *tokenPtr, *found_tab;
  char *line;
  int indiv=0,token=0,allele;
  int l=0;
  int parentexist=0, nind_fam=0, count_fam=0, count_iso=0;
  char *family;
  
  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Get_data_information\n"); 
    return 0;
  }  
  
  if (filename==NULL) { 
    Eprintf("No data file name for Get_data_information\n"); 
    return 0; 
  }
  if((IN=fopen(filename,"r")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Get_data_information\n",
	    filename); 
    return 0;
  }
  family=(char *) calloc(MAX_LENGTH_FAMID,sizeof(char));
  if (family==NULL) return 0;
  while (!feof(IN)) {
    if(indiv>=TOT_NUM_INDIV) {
      break;
    }
    token=0; l=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    tokenPtr=strtok(line," ");
    while (tokenPtr!=NULL) {
      switch (token) {
      case 0:
	data[indiv].famid=(char *) calloc(MAX_LENGTH_FAMID,sizeof(char));
	if (data[indiv].famid==NULL) return 0;
	memcpy(data[indiv].famid,tokenPtr,MAX_LENGTH_FAMID);
	if(indiv==0) {
	  strcpy(family,tokenPtr);
	  nind_fam++;
	} else if (strcmp(family,tokenPtr)==0) { /* Same Family */
	  nind_fam++;
	} else { /* New Family */
	  if (nind_fam>1) {
	    count_fam++;
	  } else {
	    if (strcmp(sample,"nuclear")==0 
		&& (strcmp(data[indiv-1].dadid,"0")!=0 
		    || strcmp(data[indiv-1].momid,"0")!=0)) {
		  Eprintf("Isolated individual of family %s does not have \"0\" for parents'id\n",
			  family ); 
		  return 0;
	    }
	    count_iso++;
	  }
	  strcpy(family,tokenPtr);
	  nind_fam=1;
	}
	token++; 
	break;
      case 1:
	data[indiv].id=(char *) calloc(MAX_LENGTH_ID,sizeof(char));
	if (data[indiv].id==NULL) return 0;
	memcpy(data[indiv].id,tokenPtr,MAX_LENGTH_ID);
	token++; 
	break;
      case 2:
	data[indiv].dadid=(char *) calloc(MAX_LENGTH_ID,sizeof(char));
	if (data[indiv].dadid==NULL) return 0;
	memcpy(data[indiv].dadid,tokenPtr,MAX_LENGTH_ID);
	if (strcmp(tokenPtr,"0")==0) {
	  parentexist++;
	}
	token++; 
	break;
      case 3:
	data[indiv].momid=(char *) calloc(MAX_LENGTH_ID,sizeof(char));
	if (data[indiv].momid==NULL) return 0;
	memcpy(data[indiv].momid,tokenPtr,MAX_LENGTH_ID);
	if (strcmp(tokenPtr,"0")==0) {
	  parentexist++;
	}
	token++; 
	break;
      case 4:
	data[indiv].sex=atoi(tokenPtr); 
	token++; 
	break;
      case 5:
	data[indiv].trait=atoi(tokenPtr); 
	token++; 
	data[indiv].markdat=(int **) calloc(TOT_NUM_LOCUS,sizeof(int *)); 
	/* initialization of markdat for indiv */
	if (data[indiv].markdat==NULL) return 0;
	break;
      case 6:
	if (l>=TOT_NUM_LOCUS) {
	  if (strcmp(tokenPtr,"\n")==0 || strcmp(tokenPtr,"\r")==0
	    || strcmp(tokenPtr,"\r\n")==0) {
/* 	    Eprintf("Space(s) found at the end of line for indiv %s_%s\n", */
/* 		   data[indiv].famid,data[indiv].id); */
	    break;
	  } else {
	    Eprintf("Problem with indiv %s_%s: too many genotypes\n",
		   data[indiv].famid,data[indiv].id);
	    free(data[indiv].markdat); 
	    return 0;	  
	  }
	}
	allele=atoi(tokenPtr);
	if (allele > map[l].num_allele) {
	  Eprintf("Problem with indiv %s_%s on marker %s: allele %d does not exist in Markerfile\n",
		 data[indiv].famid,data[indiv].id,map[l].name,allele);
	  free(data[indiv].markdat); 
	  return 0;	  
	}
	if (map[l].freq[allele] == 0.) {
	  Eprintf("Problem with indiv %s_%s on marker %s: allele %d has freq 0\n",
		 data[indiv].famid,data[indiv].id,map[l].name,allele);
	  free(data[indiv].markdat); 
	  return 0;	  
	}
	data[indiv].markdat[l]=(int *) calloc(2,sizeof(int));
	if (data[indiv].markdat[l]==NULL) { 
	  free(data[indiv].markdat); 
	  return 0;
	}
	if (allele == 0) {
	  data0[indiv]++;
	}
	data[indiv].markdat[l][0]=allele;
	token++; 
	break;
      case 7:
	if (strcmp(tokenPtr,"\n")==0 || strcmp(tokenPtr,"\r")==0
	    || strcmp(tokenPtr,"\r\n")==0) {
	  break;
	}
	allele=atoi(tokenPtr);
	if (allele > map[l].num_allele) {
	  Eprintf("Problem with indiv %s_%s on marker %s: allele %d does not exist in Markerfile\n",
		 data[indiv].famid,data[indiv].id,map[l].name,allele);
	  free(data[indiv].markdat); 
	  return 0;	  
	}
	if (map[l].freq[allele] == 0.) {
	  Eprintf("Problem with indiv %s_%s on marker %s: allele %d has freq 0\n",
		 data[indiv].famid,data[indiv].id,map[l].name,allele);
	  free(data[indiv].markdat[l]);
	  free(data[indiv].markdat); 
	  return 0;	  
	}
	data[indiv].markdat[l][1]=allele;
	token--; 
	l++;
	break;
      default:
	Eprintf("Problem with declaration of individual %s in fam %s\n",
	       data[indiv].id,data[indiv].famid);
	return 0;
	break;
      }
      tokenPtr=strtok(NULL," ");
    }
    if (l != TOT_NUM_LOCUS) {
      Eprintf("Problem with the number of fields for individual %s in fam %s:\n",
	     data[indiv].id,data[indiv].famid);
      Eprintf("%d genotypes found but %d expected\n",l,TOT_NUM_LOCUS);
      return 0;
    }
    if (token != 6) {
      Eprintf("Problem with the number of fields for individual %s in fam %s:\n",
	     data[indiv].id,data[indiv].famid);
      if(token>6) {Eprintf("Blanks found at the end of line\n");}
      if(token<6) {Eprintf("Some family information missing or an allele\n");}
      return 0;
    }
    indiv++;
    line[0]='\0';
  }
  if (indiv != TOT_NUM_INDIV) {
    Eprintf("Total individuals is %d but %d individuals read.\n",
	    TOT_NUM_INDIV,indiv);
    return 0;
  }

  if (nind_fam>1) {
    count_fam++;
  } else {
    if (strcmp(sample,"nuclear")==0 
	&& (strcmp(data[indiv-1].dadid,"0")!=0 
	    || strcmp(data[indiv-1].momid,"0")!=0)) {
      Eprintf("Isolated individual of family %s does not have \"0\" for parents'id\n",
	      family ); 
      return 0;
    }
    count_iso++;
  }
  TOT_NUM_FAM=count_fam;
  TOT_NUM_ISO=count_iso;
  free(line);
  free(family);
  fclose(IN);
  return 1;
}

int Print_data_information(char *filename, indiv *data) {
  int indiv,l;
  FILE *OUT;

  if((OUT=fopen(filename,"w")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Print_data_information\n",
	    filename); 
    return 0;
  }
  for (indiv=0;indiv<TOT_NUM_INDIV;indiv++) {
    fprintf(OUT,"Indiv %d: %5s*%5s*%5s*%5s*%3d*%3d#",
	    indiv,data[indiv].famid,data[indiv].id,data[indiv].dadid,
	    data[indiv].momid,data[indiv].sex,data[indiv].trait);
    for (l=0;l<TOT_NUM_LOCUS;l++) {
      fprintf(OUT,"%3d*%3d*",data[indiv].markdat[l][0],
	      data[indiv].markdat[l][1]);
    } 
    fprintf(OUT,"\n");
  }

  fclose(OUT);
  fflush(OUT);
  return 1;
}

int Free_data(indiv *data, int nmarker) {
  int indiv,l;

  for (indiv=0;indiv<TOT_NUM_INDIV;indiv++) {
    free(data[indiv].famid); data[indiv].famid=NULL;
    free(data[indiv].id); data[indiv].id=NULL;
    free(data[indiv].dadid); data[indiv].dadid=NULL;
    free(data[indiv].momid); data[indiv].momid=NULL;
    for (l=0;l<nmarker;l++) {
      free(data[indiv].markdat[l]); data[indiv].markdat[l]=NULL;
    }
    free(data[indiv].markdat); data[indiv].markdat=NULL;
  }
  free(data);

  return 1;
}

int Get_input_genome(char *mapfile, char *datafile, char *sample) {
	
  printf("\n");
  if (!Init_marker(mapfile, &TOT_NUM_LOCUS)) {
    Eprintf("\nERROR when initializing marker data information\n");
    return 0;
  }
  printf("Marker file: %s\n",mapfile);
  if (!Get_marker_information(mapfile, MAP)) {
    Eprintf("\nERROR when reading marker data information\n");
    return 0;
  }
  printf(" Map information read for %d markers\n",TOT_NUM_LOCUS);
/*   Print_marker_information("test_input_map.out", MAP); */
  printf("\n");
  if (!Init_data(datafile, &TOT_NUM_INDIV)) {
    Eprintf("\nERROR when initializing marker data information\n");
    return 0;
  }
  printf("Data file: %s\n",datafile);
  if ((DATAisZERO=(int *) calloc(TOT_NUM_INDIV,sizeof(int)))==NULL) {    
    Eprintf("\nCould not allocate memory for DATAisZERO in Get_input_genome\n"); 
    return 0;
  }  
  if (!Get_data_information(MAP, datafile, DATAisZERO, sample, DATA)) {
    Eprintf("\nERROR when reading individual data information\n");
    return 0;
  }
  printf(" Data information read for %d individuals\n",TOT_NUM_INDIV);
  if (strcmp(sample,"independent")==0) {
    printf(" All individuals will be analysed independently\n");
  } else if (strcmp(sample,"nuclear")==0) {
    printf(" Sample composition: %d isolated individuals (no parents or sibs)\n",
	 TOT_NUM_ISO);
    printf("                     %d nuclear families (parents and/or sibs)\n",
	   TOT_NUM_FAM);
  } else {
    Eprintf("\nWrong argument for lodscore computation: independent or nuclear\n");
    return 0;
  }
/*   Print_data_information("test_input_data.out", DATA); */

  return 1;
}

int Get_input_genome_plinkOK(char *inputopt, char *mapfile, char *datafile, 
			     char *sample) {

  printf("\n");
  if (strcmp(inputopt,"festform")==0) {
    if (!Init_marker(mapfile, &TOT_NUM_LOCUS)) {
      Eprintf("\nERROR when initializing marker data information\n");
      return 0;
    }
    printf("Marker file: %s\n",mapfile);
    if (!Get_marker_information(mapfile, MAP)) {
      Eprintf("\nERROR when reading marker data information\n");
      return 0;
    }
  } else if (strcmp(inputopt,"plinform")==0) {
    if (!Init_marker_plinkformat(mapfile, &TOT_NUM_LOCUS)) {
      Eprintf("\nERROR when initializing marker data information\n");
      return 0;
    }
    printf("Marker file: %s.map, %s.frq\n",mapfile,mapfile);
    if (!Get_marker_information_plinkformat(mapfile, MAP)) {
      Eprintf("\nERROR when reading marker data information (plink format)\n");
      return 0;
    }
  } else {
    Eprintf("\nERROR in input format: festform or plinform only\n");
    return 0;
  }
  printf(" Map information read for %d markers\n",TOT_NUM_LOCUS);
/*   Print_marker_information("test_input_map.out", MAP); */
  printf("\n");
  if (!Init_data(datafile, &TOT_NUM_INDIV)) {
    Eprintf("\nERROR when initializing marker data information\n");
    return 0;
  }
  printf("Data file: %s\n",datafile);
  if ((DATAisZERO=(int *) calloc(TOT_NUM_INDIV,sizeof(int)))==NULL) {    
    Eprintf("\nCould not allocate memory for DATAisZERO in Get_input_genome\n"); 
    return 0;
  }  
  if (!Get_data_information(MAP, datafile, DATAisZERO, sample, DATA)) {
    Eprintf("\nERROR when reading individual data information\n");
    return 0;
  }
  printf(" Data information read for %d individuals\n",TOT_NUM_INDIV);
  if (strcmp(sample,"independent")==0) {
    printf(" All individuals will be analysed independently\n");
  } else if (strcmp(sample,"nuclear")==0) {
    printf(" Sample composition: %d isolated individuals (no parents or sibs)\n",
	 TOT_NUM_ISO);
    printf("                     %d nuclear families (parents and/or sibs)\n",
	   TOT_NUM_FAM);
  } else {
    Eprintf("\nWrong argument for lodscore computation: independent or nuclear\n");
    return 0;
  }
/*   Print_data_information("test_input_data.out", DATA); */

  return 1;
}

int Get_lodnuclear_noinbreed(int nmarker, markmap *map, char *filename, 
			     real *lod_noinbreed) {
  FILE *IN;
  char *tokenPtr, *found_tab;
  char *line;
  int l=0,token=0;
  
  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Get_lodnuclear_noinbreed\n"); 
    return 0;
  }  
  
  if (filename==NULL) { 
    Eprintf("No lodscore file name for Get_lodnuclear_noinbreed\n"); 
    return 0; 
  }
  if((IN=fopen(filename,"r")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Get_lodnuclear_noinbreed\n",
	    filename); 
    return 0;
  }
  while (!feof(IN)) {
    if(l>nmarker) {
      Eprintf("More marker loci to be read than announced by %d\n",nmarker);
      return 0;
    }
    token=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    tokenPtr=strtok(line," ");
    while (tokenPtr!=NULL) {
      switch (token) {
      case 0:
	if(strcmp(tokenPtr,map[l].name)!=0) {
	  Eprintf("Problem with marker %s in LODnoInbreeding: \n",tokenPtr);
	  Eprintf("name does not match marker file information (%s)\n",
		  map[l].name);
	  return 0;
	}
	token++; 
	break;
      case 1:
	if (atoi(tokenPtr)!=map[l].chr) {
	  Eprintf("Problem with marker %s in LODnoInbreeding: \n",map[l].name);
	  Eprintf("chromosome allocation different from marker file information\n");
	  return 0;
	}
	token++; 
	break;
      case 2:
	if(atof(tokenPtr)!=map[l].dist) {
	  Eprintf("Marker %s in LODnoInbreeding: \n",map[l].name);
	  Eprintf("marker position different from marker file information\n");
	  Eprintf("marker position from marker file will be used\n");
	  /*  return 0; */
	}
	token++; 
	break;
      case 3:
	if (strncmp(tokenPtr,"-inf",4)==0 || strncmp(tokenPtr,"-INF",4)==0
	    || strncmp(tokenPtr,"-Inf",4)==0) {
	  /* "-inf" for Allegro, "-INFINITY" for Merlin */
	  lod_noinbreed[l]=mINF;
	} else {
	  lod_noinbreed[l]=atof(tokenPtr);
	}
	token++; 
	break;
      default:
	Eprintf("Problem with marker %s: too many fields\n",map[l].name);
	return 0;
	break;
      }
      tokenPtr=strtok(NULL," ");
    }
    l++;
    line[0]='\0';
  }
  if(l<nmarker) {
    Eprintf("Less marker loci read (%d) than announced (%d)\n",l,nmarker);
    return 0;
  }
  free(line);
  fclose(IN);
  return 1;
}

int Get_list_lodnuclear_noinbreed(int nmarker, markmap *map, char *filename, 
	
			  real **fam_lod_noinbreed) {
  FILE *IN;
  char *last=NULL, *tokenLPtr=NULL;
  char *line;
  char *family=NULL, *found_tab=NULL;
  int fam=0, iso=0, token=0;
  
  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Get_list_lodnuclear_noinbreed\n"); 
    return 0;
  }  
  
  if (filename==NULL) { 
    Eprintf("No lodscore filename for Get_list_lodnuclear_noinbreed\n"); 
    return 0; 
  }
  if((IN=fopen(filename,"r")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Get_list_lodnuclear_noinbreed\n",
	    filename); 
    return 0;
  }
  clearerr(IN);
  while (!feof(IN)) {
    if (fam>=TOT_NUM_FAM && iso>=TOT_NUM_ISO) break;
    token=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    /* if there is a return it would be at the end */
    last = strchr(line, '\0');
    /* look for LF & replace it */
    if (last - 1 >= line && *--last == '\n') {
      *last = '\0';
    }
    /* look for CR & replace it */
    if (last - 1 >= line && *--last == '\r') {
      *last = '\0';
    }
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    family=(char *) calloc(MAX_LENGTH_FAMID,sizeof(char));
    if (family==NULL) return 0;
    tokenLPtr=strtok(line," ");
    while (tokenLPtr!=NULL) {
      switch (token) {
      case 0:
	strcpy(family,tokenLPtr);
	token++;
	break;
      case 1:
	if (strncmp(tokenLPtr,"ISO",3)==0) {
	  iso++;
	} else if (strncmp(tokenLPtr,"SINGLE_OFFSPRING",6)==0) {
	  fam++;
	  /*ALL2010*/
	  /*fam_lod_noinbreed[fam] is Init2Ddouble*/ 
	  /*=> zero valued initialized in FEstim_Main*/
	} else {
	  if (fam>=TOT_NUM_FAM) {
	    Eprintf("\nProblem in reading LODnoInbreeding: more nuclear families (%d) than expected (%d)\n",
		    fam+1,TOT_NUM_FAM);
	    return 0;
	  }
	  if(!Get_lodnuclear_noinbreed(nmarker, map, tokenLPtr, 
				       fam_lod_noinbreed[fam])) {
	    Eprintf("\nProblem in reading input file (LODnoInbreeding) in Get_list_lodnuclear_noinbreed\n");
	    return 0;
	  }
	  fam++;
	}
	token++;
	break;
      default:
	Eprintf("Problem with family %s: too many fields\n",family);
	return 0;
	break;
      }
      tokenLPtr=strtok(NULL," ");
    }
    free(family);
  }
  fclose(IN);
  if (fam<TOT_NUM_FAM) {
    Eprintf("\nProblem in reading LODnoInbreeding: less nuclear families (%d) than expected from datafile (%d)\n",fam,TOT_NUM_FAM);
    return 0;
  } else if (fam>TOT_NUM_FAM) {
    Eprintf("\nProblem in reading LODnoInbreeding: more nuclear families (%d) than expected from datafile (%d)\n",fam,TOT_NUM_FAM);
    return 0;
  }
  if (iso<TOT_NUM_ISO) {
    Eprintf("\nProblem in reading LODnoInbreeding: less isolated individuals (%d) than expected from datafile (%d)\n",iso,TOT_NUM_ISO);
    return 0;
  } else if (iso>TOT_NUM_ISO) {
    Eprintf("\nProblem in reading LODnoInbreeding: more isolated individuals (%d) than expected from datafile (%d)\n",iso,TOT_NUM_ISO);
    return 0;
  }
  free(line);
  return 1;
}

int Get_FnA(char *filename, real *inball, real *aall) {
  FILE *IN;
  char *last=NULL, *tokenPtr=NULL;
  char *line;
  char *found_tab=NULL;
  int indiv=0, token=0;

  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Get_FnA\n"); 
    return 0;
  }  
  
  if (filename==NULL) { 
    Eprintf("No data file name for Get_FnA\n"); 
    return 0; 
  }
  if((IN=fopen(filename,"r")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Get_FnA\n",
	    filename); 
    return 0;
  }
  clearerr(IN);
  while (!feof(IN)) {
    token=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    /* if there is a return it would be at the end */
    last = strchr(line, '\0');
    /* look for LF & replace it */
    if (last - 1 >= line && *--last == '\n') {
      *last = '\0';
    }
    /* look for CR & replace it */
    if (last - 1 >= line && *--last == '\r') {
      *last = '\0';
    }
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    tokenPtr=strtok(line," ");
    while (tokenPtr!=NULL) {
      switch (token) {
      case 0:
	token++;
	break;
      case 1:
	token++;
	break;
      case 2:
	inball[indiv]=atof(tokenPtr);
	token++;
	break;
      case 3:
	aall[indiv]=atof(tokenPtr);
	token++;
	break;
      default:
	Eprintf("Problem with indiv %d: too many fields (Get_FnA)\n",indiv);
	return 0;
	break;
      }
      tokenPtr=strtok(NULL," ");
    }
    indiv++;
  }

  printf("User provided (F,A) values: %s\n",filename);

  fclose(IN);
  free(line);
  return 1;
}

int Get_input_HET(char *filename, markmap *map) {
  FILE *IN;
  char *line;
  char *last, *tokenPtr, *found_tab;
  int l=0, token=0;

  if ((line=(char*) calloc(MAX_LENGTH_LINE,sizeof(char)))==NULL) {
    Eprintf("\nCould not allocate memory for line in Get_input_HET\n"); 
    return 0;
  }
  if (filename==NULL) { 
    Eprintf("No data file name for Get_input_HET\n"); 
    return 0; 
  }
  if((IN=fopen(filename,"r")) == NULL) { 
    Eprintf("File \"%s\" could not be opened in Get_input_HET\n",
	    filename); 
   return 0;
  }
  clearerr(IN);
  while (!feof(IN)) {
    token=0;
    if (fgets(line,MAX_LENGTH_LINE,IN)==NULL) break;
    /* if there is a return it would be at the end */
    last = strchr(line, '\0');
    /* look for LF & replace it */
    if (last - 1 >= line && *--last == '\n') {
      *last = '\0';
    }
    /* look for CR & replace it */
    if (last - 1 >= line && *--last == '\r') {
      *last = '\0';
    }
    found_tab=my_strchr(line,'\t');
    while (found_tab!=NULL) {
      *found_tab=' '; 
      found_tab=my_strchr(line,'\t');
    }
    tokenPtr=strtok(line," ");
    while (tokenPtr!=NULL) {
      switch (token) {
      case 0:
	token++;
	break;
      case 1:
	map[l].freq[0]=1.-atof(tokenPtr);
	token++;
	break;
      default:
	Eprintf("Problem with marker %s: too many fields (Get_input_HET)\n",map[l].name);
	return 0;
	break;
      }
      tokenPtr=strtok(NULL," ");
    }
    l++;
  }

  return 1;
}
