/*****************************************************************/
/*    Function "fun" (likelihood) to be maximized with Gemini    */
/* Name: funk.c                                                  */
/* Author: AL Leutenegger                                        */
/*                       [Apr 2003]                              */
/*****************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "pg.h"

/* extern */ 
int TOT_NUM_LOCUS;
int TOT_NUM_INDIV;
/* int NUM_SCALE; */
markmap *MAP;
indiv *DATA;
markmap *CMAP;
indiv *CDATA;
int CSOME_NUM_LOCUS;
int nIndiv;
vector xall; 
tmaxn itp;
/* FILE *outfile, *detfile; */
int COMPUT_CSOME;
/* End extern */ 

/**************************************************/
real fun(vector vect)
/* -log likelihood based on Y to be minimized     */
/**************************************************/
{
  real inb, aa, funk=0;

  if (itp[0]==1) { 
    xall[0]=vect[0];
  }
  if (itp[1]==1) { 
    xall[1]=vect[1];
  }

  inb=xall[0]; 
  aa=xall[1];
  if (COMPUT_CSOME==0) {
    if (!Likfast(inb,aa,MAP,DATA[nIndiv].markdat,TOT_NUM_LOCUS,&funk)) {
      Eprintf("Problem with Likfast in fun()\n");
      return mINF;
    }
  } else {
    if (!Likfast(inb,aa,CMAP,CDATA[nIndiv].markdat,CSOME_NUM_LOCUS,&funk)) {
      Eprintf("Problem with Likfast in fun()\n");
      return mINF;
    }
  }

  return(-funk);
}

int D_fun_i(vector vect, int *ibd, real dfun[2])
{ /* 1st derivative of funX() taken for ibd[0]..ibd[L] */
  real inb, aa, clocus;
  int locus;

  inb=vect[0]; aa=vect[1];
  if (ibd[0]==1) {
    dfun[0]=1./inb;
  } else {
    dfun[0]=-1./(1.-inb);
  }
  dfun[1]=0.;
  for (locus=1;locus<TOT_NUM_LOCUS;locus++) {
    if (MAP[locus].chr != MAP[locus-1].chr) {
/*     if (MAP[locus].dist==0.0 && MAP[locus-1].dist!=0.0) { */
      if (ibd[locus]==1) {
	dfun[0]+=1./inb;
      } else {
	dfun[0]+=-1./(1.-inb);
      }
      dfun[1]+=0.;
    } else {
      clocus=MAP[locus].dist-MAP[locus-1].dist;
      if (ibd[locus-1]==1 && ibd[locus]==1) {
	dfun[0]+=(1.-exp(-aa*clocus))/(inb+(1.-inb)*exp(-aa*clocus));
	dfun[1]+=-(1.-inb)*clocus*exp(-aa*clocus)/(inb+(1.-inb)*exp(-aa*clocus));
      } else if (ibd[locus-1]==1 && ibd[locus]==0) {
	dfun[0]+=-1./(1.-inb);
	dfun[1]+=clocus*exp(-aa*clocus)/(1.-exp(-aa*clocus));
      } else if (ibd[locus-1]==0 && ibd[locus]==1) {
	dfun[0]+=1./inb;
	dfun[1]+=clocus*exp(-aa*clocus)/(1.-exp(-aa*clocus));
      } else {
	dfun[0]+=(-1.+exp(-aa*clocus))/(1.-(1.-exp(-aa*clocus))*inb);
	dfun[1]+=-inb*clocus*exp(-aa*clocus)/(1.-(1.-exp(-aa*clocus))*inb);
      }
    }
  }

  return 1;
}

int D2_fun_i(vector vect, int *ibd, real d2fun[2][2])
{ /* 2nd derivative of funX() taken for ibd[0]..ibd[L] */
  real inb, aa, clocus;
  int locus;

  inb=vect[0]; aa=vect[1];
  if (ibd[0]==1) {
    d2fun[0][0]=-1./inb/inb;
  } else {
    d2fun[0][0]=-1./(1.-inb)/(1.-inb);
  }
  d2fun[0][1]=d2fun[1][0]=0.;
  d2fun[1][1]=0.;
  for (locus=1;locus<TOT_NUM_LOCUS;locus++) {
    if (MAP[locus].chr != MAP[locus-1].chr) {
/*     if (MAP[locus].dist==0.0 && MAP[locus-1].dist!=0.0) { */
      if (ibd[locus]==1) {
	d2fun[0][0]+=-1./inb/inb;
      } else {
	d2fun[0][0]+=-1./(1.-inb)/(1.-inb);
      }
      d2fun[0][1]+=0.;
      d2fun[1][0]=d2fun[0][1];
      d2fun[1][1]+=0.;
    } else {
      clocus=MAP[locus].dist-MAP[locus-1].dist;
      if (ibd[locus-1]==1 && ibd[locus]==1) {
	d2fun[0][0]+=-pow((1.-exp(-aa*clocus)),2.)/pow((inb+(1.-inb)*exp(-aa*clocus)),2.);
	d2fun[0][1]+=clocus*exp(-aa*clocus)/pow((inb+(1.-inb)*exp(-aa*clocus)),2.);
	d2fun[1][0]=d2fun[0][1];
	d2fun[1][1]+=inb*(1.-inb)*clocus*clocus*exp(-aa*clocus)/pow((inb+(1.-inb)*exp(-aa*clocus)),2.);
      } else if (ibd[locus-1]==1 && ibd[locus]==0) {
	d2fun[0][0]+=-1./pow((1.-inb),2.);
	d2fun[1][1]+=-clocus*clocus*exp(-aa*clocus)/pow((1.-exp(-aa*clocus)),2.);
      } else if (ibd[locus-1]==0 && ibd[locus]==1) {
	d2fun[0][0]+=-1./pow(inb,2.);
	d2fun[1][1]+=-clocus*clocus*exp(-aa*clocus)/pow((1.-exp(-aa*clocus)),2.);
      } else {
	d2fun[0][0]+=-pow((-1.+exp(-aa*clocus)),2.)/pow((1.-(1.-exp(-aa*clocus))*inb),2.);
	d2fun[0][1]+=-clocus*exp(-aa*clocus)/pow((1.-(1.-exp(-aa*clocus))*inb),2.);
	d2fun[1][0]=d2fun[0][1];
	d2fun[1][1]+=inb*(1.-inb)*clocus*clocus*exp(-aa*clocus)/pow((1.-(1.-exp(-aa*clocus))*inb),2.);
      }
    }
  }

  return 1;
}

int Information_matrix3(real *iterated[], real **q, real ***qq, real matrix[2][2]) {
/*   Using Monte Carlo estimation from Guo & Thompson (1994)  */
  int iter, *ibd_samp1;
  vector  phi_star;
  real ssq_comp[2][2]={{0}}, d2[2][2]={{0}}, info_comp[2][2]={{0}}, loss_info[2][2]={{0}};
  real ssq_d[2]={0}, d[2]={0}, check_mc[2]={0};
  real inb, aa;

  if ((ibd_samp1=(int *) calloc(TOT_NUM_LOCUS,sizeof(int *)))==NULL) {    
    Eprintf("Could not allocate memory for ibd_samp1 in Information_matrix3\n"); 
    return 0;
  }
  printf("Getting Monte Carlo Information Matrix");
  inb=*(iterated[0]); aa=*(iterated[1]);
  printf(" (F= %7.5f , A= %7.5f ):\n",inb,aa);
  printf("MC iterations=%d\n",NUM_ITER_MC);
  phi_star[0]=*(iterated[0]); phi_star[1]=*(iterated[1]);
  for (iter=0;iter<NUM_ITER_MC;iter++) {
    /* Get the sample of IBD states from posterior */
    Sample_from_posterior1(q, qq, TOT_NUM_LOCUS, ibd_samp1);
    /* Get Conditional expected full data obs info matrix */
    D2_fun_i(phi_star, ibd_samp1, d2);
    info_comp[0][0]+=d2[0][0]; info_comp[0][1]+=d2[0][1]; 
    info_comp[1][0]+=d2[1][0]; info_comp[1][1]+=d2[1][1];
    ssq_comp[0][0]+=d2[0][0]*d2[0][0]; ssq_comp[0][1]+=d2[0][1]*d2[0][1];
    ssq_comp[1][0]+=d2[1][0]*d2[1][0]; ssq_comp[1][1]+=d2[1][1]*d2[1][1];
    /* Get conditional variance of the data obs score */ 
    D_fun_i(phi_star, ibd_samp1, d);
    loss_info[0][0]+=d[0]*d[0]; loss_info[0][1]+=d[0]*d[1]; 
    loss_info[1][0]+=d[1]*d[0]; loss_info[1][1]+=d[1]*d[1];
    check_mc[0]+=d[0]; check_mc[1]+=d[1]; 
    ssq_d[0]+=d[0]*d[0]; ssq_d[1]+=d[1]*d[1]; 
  }
  info_comp[0][0]/=-(real)NUM_ITER_MC; info_comp[0][1]/=-(real)NUM_ITER_MC; 
  info_comp[1][0]/=-(real)NUM_ITER_MC; info_comp[1][1]/=-(real)NUM_ITER_MC;
  ssq_comp[0][0]= pow((ssq_comp[0][0]/(real)NUM_ITER_MC-info_comp[0][0]*info_comp[0][0])/(real)(NUM_ITER_MC-1.),0.5);
  ssq_comp[0][1]=pow((ssq_comp[0][1]/(real)NUM_ITER_MC-info_comp[0][1]*info_comp[0][1])/(real)(NUM_ITER_MC-1.),0.5);
  ssq_comp[1][0]=pow((ssq_comp[1][0]/(real)NUM_ITER_MC-info_comp[1][0]*info_comp[1][0])/(real)(NUM_ITER_MC-1.),0.5);
  ssq_comp[1][1]=pow((ssq_comp[1][1]/(real)NUM_ITER_MC-info_comp[1][1]*info_comp[1][1])/(real)(NUM_ITER_MC-1.),0.5);
  printf("Info comp:\n");
  printf("  Ix[0][0]=%8.3f\tIx[0][1]=%8.3f\n",info_comp[0][0],info_comp[0][1]);
  printf("  Ix[1][0]=%8.3f\tIx[1][1]=%8.3f\n",info_comp[1][0],info_comp[1][1]);
  printf("  MC StdE(Ix): [0][0]=%f\t[0][1]=%f\n",ssq_comp[0][0],ssq_comp[0][1]);
  printf("%15s[1][0]=%f\t[1][1]=%f\n","",ssq_comp[1][0],ssq_comp[1][1]);
  printf("  Std errors (from Ix): F= %f , A= %f\n", pow(1./(info_comp[0][0]-info_comp[0][1]*info_comp[1][0]/info_comp[1][1]),0.5),pow(1./(info_comp[1][1]-info_comp[1][0]*info_comp[0][1]/info_comp[0][0]),0.5));
  loss_info[0][0]/=(real)NUM_ITER_MC; loss_info[0][1]/=(real)NUM_ITER_MC; 
  loss_info[1][0]/=(real)NUM_ITER_MC; loss_info[1][1]/=(real)NUM_ITER_MC;
  check_mc[0]/=(real)NUM_ITER_MC; check_mc[1]/=(real)NUM_ITER_MC;
  ssq_d[0]=pow((ssq_d[0]/(real)NUM_ITER_MC-check_mc[0]*check_mc[0])/(real)(NUM_ITER_MC-1.),0.5); 
  ssq_d[1]=pow((ssq_d[1]/(real)NUM_ITER_MC-check_mc[1]*check_mc[1])/(real)(NUM_ITER_MC-1.),0.5);
  printf("Cond exp score: d[0]= %f , d[1]= %f\n",check_mc[0],check_mc[1]);
  printf("  MC StdE(d): [0]=%f, [1]=%f\n",ssq_d[0],ssq_d[1]);
  matrix[0][0]=info_comp[0][0]-loss_info[0][0]+check_mc[0]*check_mc[0];
  matrix[0][1]=info_comp[0][1]-loss_info[0][1]+check_mc[0]*check_mc[1];
  matrix[1][0]=info_comp[1][0]-loss_info[1][0]+check_mc[0]*check_mc[1];
  matrix[1][1]=info_comp[1][1]-loss_info[1][1]+check_mc[1]*check_mc[1];

  free(ibd_samp1);
  return 1;
}
