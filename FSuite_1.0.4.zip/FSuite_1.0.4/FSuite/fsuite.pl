#!/usr/bin/perl

use strict;
use warnings;
use FindBin qw($RealBin);
use lib "$RealBin/lib";
use Getopt::Long; 
use Statistics::Descriptive::Discrete; # $RealBin/lib/Statistics/Descriptive/Discrete.pm has been modified by S. GAZAL
use Statistics::Distributions qw(chisqrprob); 
use File::Basename;
use List::Util qw[min max]; # $RealBin/lib/List/Util.pm has been modified by S. GAZAL
Getopt::Long::Configure("pass_through");

my($myFEstim)="FEstim32"; #line 14
my($myplink) ="plink2";    #line 15 / use "plink --noweb" if plink2 is not installed
my($myMerlin)="merlin";   #line 16
my($mycircos)="circos";   #line 17
#my($mycircos)="perl C:/circos-0.67-5/bin/circos";   #line 18 - for Windows users

my($nbchr)=22;

sub print_header
{
print "\n";
print "\@--------------------------------------------------------------@\n";
print "|                  FSuite v1.0.4 - 09/29/2016                  |\n";
print "|       (C) 2013 S. GAZAL, M. SAHBATOU, A.L. LEUTENEGGER       |\n";
print "|                GNU General Public License, v3                |\n";
print "|                  fsuite.software\@gmail.com                   |\n";
print "\@--------------------------------------------------------------@\n";
print " This program comes with ABSOLUTELY NO WARRANTY.\n";
print " This is free software, and you are welcome to redistribute it\n";
print " under certain conditions.\n";
print "\n";
}

sub myfolder 
{
	my($file) = @_;
	if(!(-e $file)){$file="../$file"} else {$file="$file"}
}

sub freq
{
	my($map_file)=""; my($ped_file)=""; my($file)=""; my($bfile)=""; my($typefile); my($freq_file)=""; my(@headmap); my(@line);
	my($freq_controls); my($freq_all); my($plinkoptions1)=""; my($plinkoptions2)=""; my($listid);

	#0-read and check options
	GetOptions ("estimate-frequencies", "freq-controls" => \$freq_controls, "freq-all" => \$freq_all,"list-id=s" => \$listid,
		"map=s" => \$map_file, "ped=s" => \$ped_file, "bfile=s" => \$bfile, "file=s" => \$file , "out=s" => \$freq_file);
	if (defined ($ARGV[0])) {die "ERROR with option $ARGV[0]!\n";}
	#check uncompatible options
	if (($file ne "")  && (($map_file ne "") || ($ped_file ne ""))) {die "\nERROR! --map and --ped cannot be used when using --file option.\n"}
	if (($bfile ne "") && (($map_file ne "") || ($ped_file ne ""))) {die "\nERROR! --map and --ped cannot be used when using --bfile option.\n"}
	if (($bfile ne "") && ($file ne "")) {die "\nERROR! --file cannot be used when using --bfile option.\n"}
	if ((($map_file eq "") && ($ped_file ne "")) || (($map_file ne "") && ($ped_file eq ""))) {die "\nERROR! --map and --ped options should be used together.\n"}
	if (($bfile eq "") && ($file eq "") && ($map_file eq "") && ($ped_file eq "")) {die "\nERROR! --file, or --bfile, or --ped and --map options are mandatory.\n"}
	if ($bfile ne "") {$typefile="bfile"} else {$typefile="file"}
	
	if ($typefile eq "file") {
		#check ped and map files
		if ($file ne "") { 
			$map_file="$file.map"; $ped_file="$file.ped"; 
			if ($freq_file eq "") {$freq_file=$file;}
		} else {
			if (substr($map_file,-4) ne ".map") {die "\nERROR! The map file should end by .map.\n"} 
			elsif ($freq_file eq "") {@headmap=split('.map',$map_file); $freq_file=$headmap[0]} 
		}
		if(!(-e $map_file)){die "\nERROR! Cannot open $map_file.\n";}
		if(!(-e $ped_file)){die "\nERROR! Cannot open $ped_file.\n";}
		print "Running Fsuite, with --estimate-frequencies option.\nOther parameters are:\n";
		print "         Input ped file = $ped_file\n";
		print "         Input map file = $map_file\n";
	} else {
		#check binary files
		if(!(-e "$bfile.bed")){die "\nERROR! Cannot open $bfile.bed.\n";}
		if(!(-e "$bfile.bim")){die "\nERROR! Cannot open $bfile.bim.\n";}
		if(!(-e "$bfile.fam")){die "\nERROR! Cannot open $bfile.fam.\n";}
		print "Running Fsuite, with --estimate-frequencies option.\nOther parameters are:\n";
		print "         Input bed file = $bfile.bed\n";
		print "         Input bim file = $bfile.bim\n";	
		print "         Input fam file = $bfile.fam\n";
		if ($freq_file eq "") {$freq_file="$bfile";}		
	}	
	if (defined($listid)){ 
		if(!(-e "$listid")) {die "\nERROR! Cannot open $listid.\n";} 
		print "  Input individual file = $listid\n";
	}
	print "        Output frq file = $freq_file.frq\n\n";
	#create plink options
	if (defined($freq_controls) && defined($freq_all)) {die "\nERROR! --freq-controls and --freq-all cannot be used together.\n"}
	elsif (defined($freq_all))                         {$plinkoptions1=""; print "Allele frequencies are estimated with PLINK on cases and controls.\n";}
	else                                               {$plinkoptions1="--filter-controls"; print "Allele frequencies are estimated with PLINK on controls only.\n";}
	if (defined($listid)){ $plinkoptions2="--keep $listid"}
		
	#1-estimate allelic frequencies with PLINK
	if ($typefile eq "file") {
		system "$myplink --ped $ped_file --map $map_file --freq $plinkoptions1 $plinkoptions2 --out $freq_file > temp.log";
	} else {
		system "$myplink --bfile $bfile --freq $plinkoptions1 $plinkoptions2 --out $freq_file > temp.log";	
	}
	print "\nFile $freq_file.frq created. ";
	
	#2-get number of individuals used to estimate allele frequencies - does not work with plink2
	open(IN,"temp.log") or die "\nERROR! Cannot open PLINK log file temp.log.\n";
	while (<IN>) {
		chomp $_; @line=split;
		if ($#line>=5) {
			if( ($line[1] eq "founders") && ($line[2] eq "and") && ($line[4] eq "non-founders") && ($line[5] eq "found")) {
				print "Frequencies were estimated on $line[0] individuals.";
			}	
		}
	}
	close IN; 
	system"rm temp.log"; system"rm $freq_file.log";
	#3-get allelic frequencies information 
	my($nb0)=0; my($nb1)=0; my($nb2)=0; my($nb3)=0; my($nb4)=0; my($nb5)=0; my($nbNA)=0; my($nbrare)=0; 
	open(IN,"$freq_file.frq") or die "\nERROR! Cannot open freq file $freq_file.frq.\n";
	while (<IN>) {
		chomp $_; @line=split;
		if    ($line[4] eq "MAF") {print "\n\nFrequencies information:\n";}
		elsif ($line[4] eq "NA")  {$nbNA++}
		elsif ($line[4] eq "0")   {$nb0++}
		elsif (($line[4] >=0.01) && ($line[4] <=0.10))  {$nb1++}
		elsif (($line[4] > 0.10) && ($line[4] <=0.20))  {$nb2++}
		elsif (($line[4] > 0.20) && ($line[4] <=0.30))  {$nb3++}
		elsif (($line[4] > 0.30) && ($line[4] <=0.40))  {$nb4++}
		elsif (($line[4] > 0.40) && ($line[4] <=0.50))  {$nb5++}
		elsif ($line[4] <0.1)  {$nbrare++}
	}
	close IN; 
	print "* $nb5 SNPs with MAF in ]0.40-0.50]\n";
	print "* $nb4 SNPs with MAF in ]0.30-0.40]\n";
	print "* $nb3 SNPs with MAF in ]0.20-0.30]\n";
	print "* $nb2 SNPs with MAF in ]0.10-0.20]\n";
	print "* $nb1 SNPs with MAF in [0.01-0.10]\n";
	print "* $nbrare SNPs with MAF < 0.01\n";
	print "* $nb0 monomorphic SNPs\n";
	print "* $nbNA SNPs with no allele frequency (100% missing genotypes)\n";
	if ($nbNA>0) {print "  WARNING! Remove these SNPs if you want to use --FEstim or --FLOD options.\n";}
	print "\n";
	
}

sub create_submaps
{
	my($n_subs)=100; my($cM)=""; my($map_file)=""; my($kb)=""; my($dist)=""; my(@line); my($nb); my($folder)="submaps";
	my($summary_cpt_mark); my(%summary_cpt); my(%summary_rep); my($nball)=-1; my($nbin)=0;
	my($total_markers)=0; my($total_used_markers)=0;
	my($build_hot); my($int_hot)=""; my ($coverage);
	
	#0-read and check options
	GetOptions ("create-submaps", "map=s" => \$map_file, "n-submaps=i" => \$n_subs, 
		"cM=f" => \$cM, "kb=f" => \$kb, "sub-folder=s" => \$folder, 
		"--hotspots=s" => \$build_hot, "--hotspots-intensity=f" => \$int_hot, "coverage" => \$coverage);
	if (defined ($ARGV[0])) {die "ERROR with option $ARGV[0]!\n";}
	if    ($cM ne "" && $kb ne "")        {die "\nERROR! Options --cM and --kb cannot be used together.\n"; }
	elsif ($cM ne "" && defined($build_hot)) {die "\nERROR! Options --cM and --hotspots cannot be used together.\n"; }
	elsif (defined($build_hot) ne "" && $kb ne "") {die "\nERROR! Options --kb and --hotspots cannot be used together.\n"; }	
	elsif ($kb ne "") {$dist="kb"}
	elsif ($cM ne "") {$dist="cM"}
	elsif (defined($build_hot)) {
		if (($build_hot ne "hg17") && ($build_hot ne "hg18") && ($build_hot ne "hg19")){ die "\nERROR! Only hg version accepted with --hotspots are hg17, hg18 and hg19.\n" }
	}
	else  {$dist="cM"; $cM=0.5}
	if ($int_hot ne "") {
		if (!defined($build_hot)) {die "\nERROR! --hotspots-intensity option should be used wih --hotspots option.\n"; }
	} else {$int_hot=10}
	if ($map_file eq "") {die "\nERROR! You must specified a map file through --map option.\n"; } 
	else { if(!(-e $map_file)){die "\nERROR! Cannot open $map_file.\n";} }
	if(-d "$folder") { die "\nERROR! There is already an existing $folder folder. \nPlease rename it or use --sub-folder option.\n" } else {system "mkdir $folder";}	
	print "Running Fsuite, with --create-submaps option.\nOther parameters are:\n";
	print "         Input map file = $map_file\n";
	print "  Output submaps folder = $folder\n";
	print "        Created submaps = $n_subs\n";
	
	#Check cM positions in map_file
	my($cMdiff0)=0;
	open(IN,$map_file) or die "\nERROR! Cannot open $map_file.\n";
	while (<IN>) {
		chomp $_; @line=split;
		if ($line[2]!=0) {$cMdiff0++}
	}
	close IN;
	if ($cMdiff0==0){
		die "\nERROR! File $map_file does not have genetic positions (thrid column equals 0).\nThe best way to add the genetic position in your PLINK files \nis to use --cm-map option of plink2. \nSee https://www.cog-genomics.org/plink2/input#cm_map\n\n";
	}
	
	if (!defined($build_hot)) {	
		print "                          one marker every $kb$cM $dist\n\n"; 
		#1-create temporary map files
		open(IN,$map_file) or die "\nERROR! Cannot open $map_file.\n";
		my($chr)=1; open(OUT,">$folder/temp.map.$chr") or die "\nERROR! Cannot create temporary files. \n";
		while (<IN>) {
			chomp $_; @line=split;
			if ($line[0]!=$chr) {close OUT; $chr=$line[0]; open(OUT,">$folder/temp.map.$chr") or die "\nERROR! Cannot create temporary files \n";}
			printf OUT "$line[0]	$line[1]	$line[2]	$line[3]\n";
			$summary_cpt{$line[1]}=0;
		}
		close IN; close OUT;
		#2-create submaps
		print "Creating submap:\n";
		for ($nb=1; $nb<=$n_subs ; $nb++) {
			if (($nb == 1) || ($nb % 5 == 0)) { print "$nb"} else {print "."} 
			for ( my $chr = 1; $chr <= $nbchr; $chr++ ) { system "perl $RealBin/bin/select_subMap.pipeline.pl $folder/temp.map.$chr ${dist}_pos $kb$cM y >> $folder/submap"; }
			#system "perl -ane \'print \"\$F[1]\n\" \' $folder/submap > $folder/submap.$nb ";
			open(IN,"$folder/submap"); open(OUT,">$folder/submap.$nb"); while (<IN>) { chomp $_; @line=split; printf OUT "$line[1]\n";}; close IN; close OUT;
			system "rm $folder/submap";
		}
		print "\n";
		system "rm $folder/temp*";			
	} else {
		print "                          one marker between 2 hotspots\n";
		open(IN,"$RealBin/hotspots/hotspots_${build_hot}.list") or die "\nERROR! Cannot open $RealBin/hotspots/hotspots_${build_hot}.list.\n";
		while (<IN>) {
			chomp $_; @line=split;
			if (($nball>=0) && ($line[5]>$int_hot)) { $nbin++ }
			$nball++;
		}
		close IN;
		print "                          $nball hotspots in ${build_hot}\n";
		print "                          $nbin with intensity > $int_hot cM/Mb\n\n";
		#0-initialize temporary value
		open(IN,$map_file) or die "\nERROR! Cannot open $map_file.\n";
		while (<IN>) { chomp $_; @line=split; $summary_cpt{$line[1]}=0;}
		close IN;
		#1 - create submaps
		print "Creating submap:\n";
		for ($nb=1; $nb<=$n_subs ; $nb++) {
			if (($nb == 1) || ($nb % 5 == 0)) { print "$nb"} else {print "."} 
			system "perl $RealBin/bin/select_snpBYhotspots-v4.pl $map_file $RealBin/hotspots/hotspots_${build_hot}.list $int_hot $folder/summary.hotspot > $folder/submap"; 
			#system "perl -ane \'print \"\$F[1]\n\" \' $folder/submap > $folder/submap.$nb ";
			open(IN,"$folder/submap"); open(OUT,">$folder/submap.$nb"); while (<IN>) { chomp $_; @line=split; printf OUT "$line[1]\n";}; close IN; close OUT;
			system "rm $folder/submap";
		}
		print "\n";
		system "rm hotspot.tmp";
	}
	
	#3-create summary statistic files
	print "\nCreation of summary statistic files.\n";
	open(OUT1,">$folder/summary.log") or die "\nERROR! Cannot create summary statistic files \n";
	if (!defined($build_hot)) {	
		printf OUT1 "Creation of $n_subs random submaps (one marker every $kb$cM $dist) in new folder $folder.\n"; 
	} else {
		printf OUT1 "Creation of $n_subs random submaps from $nbin recombination hotspots ($build_hot) with intensity > $int_hot cM/Mb in new folder $folder.\n"; 
	}	
	close OUT1;
	open(OUT2,">$folder/summary.submaps") or die "\nERROR! Cannot create summary statistic files \n";
	for ($nb=1; $nb<=$n_subs ; $nb++) {
		$summary_cpt_mark=0;
		open(IN,"$folder/submap.$nb") or die "ERROR when creating summary statistic files!\n";
		while (<IN>) { chomp $_; @line=split; $summary_cpt{$line[0]}++; $summary_cpt_mark++; }
		close IN; printf OUT2 "$nb	$summary_cpt_mark\n"
	}
	close OUT2;
	open(OUT3,">$folder/summary.map")     or die "\nERROR! Cannot create summary statistic files. \n";
	for ($nb=0; $nb<=$n_subs ; $nb++) {$summary_rep{$nb}=0}
	open(IN,$map_file) or die "ERROR when creating summary statistic files!\n";
	while (<IN>) {
		chomp $_; @line=split;
		printf OUT3 "$line[1]	$summary_cpt{$line[1]}\n";
		$summary_rep{$summary_cpt{$line[1]}}++;
	}
	close IN; close OUT3;
	open(OUT4,">$folder/summary.markers") or die "\nERROR! Cannot create summary statistic files. \n";
	$total_markers=0; $total_used_markers=0;
	for ($nb=0; $nb<=$n_subs ; $nb++) { 
		if ($summary_rep{$nb}!=0) {printf OUT4 "$nb	$summary_rep{$nb}\n"}
		$total_markers=$total_markers+$summary_rep{$nb};
		if ($nb>0) {$total_used_markers=$total_used_markers+$summary_rep{$nb};}
	}
	close OUT4;
	print "$total_used_markers SNPs have been used from the $total_markers SNPs of the map file.\n\n";
	
	#4-coverage
	if (defined($coverage)) {
		print "Plotting coverage of the map file.\n\n";
		system "R --vanilla --slave --args $map_file $folder/coverage < $RealBin/bin/coverage.r  > temp.R.txt ";
		system "rm temp.R.txt";
	}

}

sub FEstim
{
	my($n_subs); my($folder); my($tempfolder); my($subfile);
	my($nb); my(@line); my($log); my($fam); my($name); my(%freq); my(%major_ref); my(%minor_ref); my(%major_data); my(%minor_data); my(%pos_cM);
	my($map_file)=""; my($ped_file)=""; my($file)=""; my($bfile)=""; my($typefile); my($freq_file)=""; my($out_file)=""; my(@headped);
	my($noLRT); my($keepIBD); my($f_out)=0.001; my($a_out)=0.001; my($mattype); my($version); my($flag_error)=0;
	my(@list_id); my(%status); my(%fidiid); my($nbid)=0; my($id); my(%f); my(%a); my(%L); my(%p_ind);
	my($thisid); my($all_test); my($all_f); my($all_a); my($nb_test); my($sub); my($flag); my($stat); my($quality); my($pval); my($e);
	my($plinkoption)=""; my($listid);
	
	#0-read and check options
	GetOptions ("FEstim", "n-submaps=i" => \$n_subs, "sub-folder=s" => \$folder, "--sub-file=s" => \$subfile,"list-id=s" => \$listid,
		"noLRT" => \$noLRT, "f-outbred=f" => \$f_out, "a-outbred=f" => \$a_out,
		"keep-locusIBD" => \$keepIBD, "mating-type" => \$mattype, 
		"map=s" => \$map_file, "ped=s" => \$ped_file, "freq=s" => \$freq_file, "bfile=s" => \$bfile, "file=s" => \$file, "out=s" => \$out_file);
	if (defined ($ARGV[0])) {die "ERROR with option $ARGV[0]!\n";}
	#check uncompatible options
	if (($file eq "") && ($bfile eq "") && ($map_file eq "") && ($ped_file eq "")  && ($freq_file eq "")) {die "\nERROR! --file, or --bfile, or --map, --ped and --freq options are mandatory.\n"}
	if (($file ne "")  && (($map_file ne "") || ($ped_file ne "")  || ($freq_file ne ""))) {die "\nERROR! --map, --ped and --freq cannot be used when using --file option.\n"}
	if (($bfile ne "") && (($map_file ne "") || ($ped_file ne "")  )) {die "\nERROR! --map and --ped cannot be used when using --bfile option.\n"}
	if (($bfile ne "") && ($file ne "")) {die "\nERROR! --file cannot be used when using --bfile option.\n"}
	if (($bfile ne "") && ($freq_file eq "")) {die "\nERROR! --bfile and --freq options should be used together.\n"}
	if ((($map_file eq "") && ($ped_file ne "")) || (($map_file ne "") && ($ped_file eq ""))) {die "\nERROR! --map and --ped options should be used together.\n"}
	#if (($thread!=1) && ($thread!=2) && ($thread!=4) && ($thread!=8)) {die "\nERROR! Only accepted values for --thread option are 1, 2, 4 and 8.\n"}
	if ($bfile ne "") {$typefile="bfile"} else {$typefile="file"}
	
	if ($typefile eq "file") {
		#check ped and map files
		if ($file ne "") { $map_file="$file.map"; $ped_file="$file.ped"; $freq_file="$file.frq";}
		else {
			if (($map_file eq "") || ($ped_file eq "") || ($freq_file eq "")) {die "\nERROR! --map, --ped and --freq options should be used together.\n"}
		}
		if(!(-e $map_file)) {die "\nERROR! Cannot open $map_file.\n";}
		if(!(-e $ped_file)) {die "\nERROR! Cannot open $ped_file.\n";}
		if(!(-e $freq_file)){die "\nERROR! Cannot open $freq_file.\n";}
		if ($out_file eq "") {  
			if (substr($ped_file,-4) ne ".ped") {die "\nERROR! The ped file should end by .ped.\n"} 
				else {@headped=split('.ped',$ped_file); $out_file=$headped[0]} 
		}
		print "Running Fsuite, with --FEstim option.\nOther parameters are:\n";
		print "         Input ped file = $ped_file\n";
		print "         Input map file = $map_file\n";
		print "        Input freq file = $freq_file\n";
	} else {
		#check binary files
		if(!(-e "$bfile.bed")){die "\nERROR! Cannot open $bfile.bed.\n";}
		if(!(-e "$bfile.bim")){die "\nERROR! Cannot open $bfile.bim.\n";}
		if(!(-e "$bfile.fam")){die "\nERROR! Cannot open $bfile.fam.\n";}
		if(!(-e $freq_file  )){die "\nERROR! Cannot open $freq_file.\n";}
		print "Running Fsuite, with --FEstim option.\nOther parameters are:\n";
		print "         Input bed file = $bfile.bed\n";
		print "         Input bim file = $bfile.bim\n";	
		print "         Input fam file = $bfile.fam\n";
		print "        Input freq file = $freq_file\n";
		if ($out_file eq "") {$out_file="$bfile";}
	}
	#check submap file/folder
	if (defined($folder) && defined($subfile)) { 
		die "\nERROR! Options --sub-folder and --subfile cannot be used together.\n"; 
	} elsif (defined($subfile)) {
		if(!(-e $subfile)) {die "\nERROR! Cannot open $subfile.\n";}
		print "      Input submap file = $subfile\n";
		if (defined($n_subs)) {print"WARNING. Option --n-submaps have been ignored.\n"}
		$n_subs=1;
	} else {
		if (!defined($folder)) {$folder="submaps"}
		print "   Input submaps folder = $folder\n";
		#check submaps
		if (defined($n_subs)){
			for ($nb=1; $nb<=$n_subs ; $nb++) { if(!(-e "$folder/submap.$nb")){die "\nERROR! Submap $folder/submap.$nb does not exist.\n";} }
			print "                          $n_subs selected submaps\n";
		} else {
			$n_subs=1; if(!(-e "$folder/submap.$n_subs")){die "\nERROR! Submap $folder/submap.$n_subs does not exist.\n";} 
			while (-e "$folder/submap.$n_subs") {$n_subs++}
			$n_subs--;
			print "                          $n_subs consecutive submaps\n";
		}
	}
	#listid
	if (defined($listid)){ 
		if(!(-e "$listid")) {die "\nERROR! Cannot open $listid.\n";} 
		print "  Input individual file = $listid\n";
		$plinkoption="--keep $listid";
	}
	# LRT test
	if (defined($mattype) && defined($noLRT)) {die "\nERROR! --noLRT and --mating-type cannot be used together.\n";}
	if (!defined($noLRT)) {
		print "  Likelihood ratio test = yes \n";
		if (($f_out<=0) || ($f_out>=1)) {die "\nERROR! Value for --f-outbred option should be between 0 and 1.\n"}
		if (($a_out<=0) || ($a_out>=1)) {die "\nERROR! Value for --a-outbred option should be between 0 and 1.\n"}
		print "                          f-outbred=$f_out, a-outbred=$a_out\n";
	} else { 
		if (($f_out!=0.001) || ($a_out!=0.001)) {die "\nERROR! --f-outbred or --a-outbred options should no be used with --noLRT option.\n";}
		print "  Likelihood ratio test = no \n";
	}
	# pop mating test
	print "            Mating type = ";
	if (defined($mattype)) { print "yes\n" } else { print "no\n" }
	print "          Output header = $out_file \n";
	#create folders
	if (defined($keepIBD)){if(-d "locusIBD_ALL") { die "\nERROR! There is already an existing locusIBD_ALL folder. Please rename it.\n" } else {system "mkdir locusIBD_ALL";}}		
	
	#0- create temporary binary files
	$tempfolder=sprintf("%0.0f",(rand()*(10**20))); #name of the temporary folder
	$tempfolder = "temp_$tempfolder";
	print "       Temporary folder = $tempfolder \n\n";
	print "Creating temporary binary files.\n";
	if(-d "$tempfolder") { die "\nERROR! Cannot create temporary folder.\n" } else {system "mkdir $tempfolder";}	
	if ($typefile eq "file") {
		system "$myplink --ped $ped_file --map $map_file $plinkoption --nonfounders --make-bed --output-missing-phenotype 0 --out $tempfolder/temp > $tempfolder/temp.logPLINK";	
	} else {
		system "$myplink --bfile $bfile $plinkoption --nonfounders --make-bed --output-missing-phenotype 0 --out $tempfolder/temp > $tempfolder/temp.logPLINK";	
	}
	#1- Checking allelic concordance
	if ($typefile eq "file") {
		print "Checking allelic concordance between $ped_file and $freq_file.\n";
	} else {
		print "Checking allelic concordance between binary inputs and $freq_file.\n";
	}
	#1-a stock allele frequencies
	open(IN,$freq_file) or die "\nERROR! Cannot open $freq_file.\n";
	while (<IN>) {
		chomp $_; @line=split;
		if ($line[1] ne "SNP") {
			$freq{$line[1]}=$line[4]; 
			if    ($freq{$line[1]} eq "NA") {
				system "rm -rf $tempfolder";
				die "\nERROR! $freq_file contains some NA. Remove these markers of the data.\n";
				#$freq{$line[1]}=0.5;    
				#print "WARNING! SNP $line[1] has a frequency equals to NA (missing for all the individuals). Its frequency will be replace by 0.5.\n"; 
			} elsif ($freq{$line[1]}==0)      {
				$freq{$line[1]}=0.0001; 
				#print "WARNING! SNP $line[1] has a frequency equals to 0 (monomorph). Its frequency will be replace by 0.0001.\n"; 
			} elsif ($freq{$line[1]}==1)      {
				$freq{$line[1]}=0.9999; 
				#print "WARNING! SNP $line[1] has a frequency equals to 1 (monomorph). Its frequency will be replace by 0.9999.\n"; 
			} 
			$major_ref{$line[1]}=$line[3]; #stocking the major allele
			$minor_ref{$line[1]}=$line[2]; #stocking the minor allele
		}
	}
	close IN;
	open(IN,"$tempfolder/temp.bim") or die "\nERROR! Cannot open $tempfolder/temp.bim.\n";
	while (<IN>) {
		chomp $_; @line=split;
		$major_data{$line[1]}=$line[5]; #stocking the major allele
		$minor_data{$line[1]}=$line[4]; #stocking the minor allele
		if    (!defined($major_ref{$line[1]}))   {print "  ERROR.   $line[1] has no frequency in $freq_file.\n"; $flag_error=1;}	
		elsif ($major_data{$line[1]} eq "0")     {print "  WARNING. $line[1] has 100% of missing genotypes.\n";}	
		elsif ($major_ref{$line[1]}  eq "0")     {print "  WARNING. $line[1] has no reference allele in $freq_file.\n";}
		elsif (($major_data{$line[1]} ne $major_ref{$line[1]}) && ($major_data{$line[1]} ne $minor_ref{$line[1]})) 
			{print "  ERROR.   $line[1] major allele ($major_data{$line[1]}) is not present in $freq_file.\n";$flag_error=1;}
		elsif ($minor_data{$line[1]} eq "0")     {}	
		elsif ($minor_ref{$line[1]}  eq "0")     {}
		elsif (($minor_data{$line[1]} ne $major_ref{$line[1]}) && ($minor_data{$line[1]} ne $minor_ref{$line[1]})) 
			{print "  ERROR.   $line[1] minor allele ($minor_data{$line[1]}) is not present in $freq_file.\n";$flag_error=1;}
	}
	close IN;
	if ($flag_error==1) {system "rm -rf $tempfolder"; die "\n";}
	#1-b stock cM positions
	if ($typefile eq "file") {
		open(IN,$map_file) or die "\nERROR! Cannot open $map_file.\n";
	} else {
		open(IN,"$bfile.bim") or die "\nERROR! Cannot open $bfile.bim.\n";
	}
	while (<IN>) {
		chomp $_; @line=split;
		$pos_cM{$line[1]}=$line[2];
	}
	close IN;
	
	#2- create output files
	#FEstim version 
	print "Estimating inbreeding with FEstim on submap:\n";
	open(OUT_FA,">$out_file.estim") or die "\nERROR! Cannot create $out_file.estim.\n"; printf OUT_FA "SUB	FID	IID	F	A\n"; 
	if (!defined($noLRT) || defined($mattype)) {
		open(OUT_L,">$out_file.likelihood") or die "\nERROR! Cannot create $out_file.likelihood.\n";
		printf OUT_L "SUB	FID	IID	H	LIKELIHOOD\n";
	}
	
	#3- run FEstim in a temporary file
	chdir $tempfolder;
	for ($nb=1; $nb<=$n_subs ; $nb++) {
		if (($nb == 1) || ($nb % 5 == 0)) { print "$nb"} else {print "."} 
		#extract data
		if (defined($subfile)) {
			$e=myfolder("$subfile");
		} else {
			$e=myfolder("$folder/submap.$nb");
		}
		system "$myplink --bfile temp --extract $e --recode12 --output-missing-phenotype 0 --nonfounders --out temp > temp.logPLINK";	
		#stock status
		if ($nb==1) {
			open(IN,"temp.fam") or die "\nERROR! Cannot open $tempfolder/temp.fam.\n";
			while (<IN>) {
				chomp $_; @line=split;
				$status{"$line[0]_$line[1]"}=$line[5];
				$fidiid{"$line[0]_$line[1]"}="$line[0]	$line[1]";
			}
			close IN;
		}
		#create temp2.frq file and temp2.map
		open(IN,"temp.map") or die "\nERROR! Cannot open temp.map.\n";
		open(OUTMAP,">temp2.map") or die "\nERROR! Cannot create temp2.map. \n";
		open(OUTFRQ,">temp2.frq") or die "\nERROR! Cannot create temp2.frq. \n";
		while (<IN>) {
			chomp $_; @line=split;
			printf OUTMAP "$line[0]	$line[1]	$pos_cM{$line[1]}	$line[3]\n"; 
			if ($major_data{$line[1]} eq $major_ref{$line[1]}) { printf OUTFRQ "$line[0]	$line[1]	1	2	$freq{$line[1]}	9999\n";}
			else                                               { printf OUTFRQ "$line[0]	$line[1]	2	1	$freq{$line[1]}	9999\n";}
		}
		close IN; close OUTMAP;	close OUTFRQ;	 
		
		#run FEstim
		system "$RealBin/bin/$myFEstim --mplink temp2 --ped temp.ped --msmark 50 > temp.logFEstim";

		#stock FEstim version
		if ($nb==1) {
			open(IN,"temp.logFEstim") or die "\nERROR! Cannot open $tempfolder/temp.logFEstim.\n";
			while (<IN>) {
				if (!defined($version)) {
					chomp $_; @line=split;
					if ($line[0] eq "**"){
						if ($line[1] eq "FEstim"){ $version= substr($line[3],0,length($line[3])-1); }
					}
				}
			}
			close IN;
		}
		
		#write the results
		open(IN,"inbreedings.out"); 
		while (<IN>) { 
			chomp $_; @line=split; 
			if ($line[0] ne "Individual") { 
				if ($nb==1) {push(@list_id,$line[0]) ; $nbid++;}
				printf OUT_FA "$nb	$fidiid{$line[0]}	$line[1]	$line[3]\n"; 
				$f{$nb}{$line[0]}=$line[1]; $a{$nb}{$line[0]}=$line[3];
			}
		} 
		close IN; 
		#keeping files
		if (defined($keepIBD)){system "cp locusIBD.out ../locusIBD_ALL/locusIBD.$nb.out";}		
		#LRT
		if (!defined($noLRT)) {
			#a/ read maximum likelihood
			open(IN,"temp.logFEstim") or die "\nERROR! Cannot open temp.logFEstim.\n";
			while (<IN>) {
				chomp $_; @line=split;
				if ((defined($line[0])) && ($line[0] eq "Estimation")) {$fam=$line[3]; $name=(split(':',$line[5]))[0]; $thisid="${fam}_$name"; printf OUT_L "$nb	$fidiid{$thisid}	H1";}
				if ((defined($line[0])) && ($line[0] eq "ITERATIVE"))  {printf OUT_L "	$log\n"; $L{$nb}{"${fam}_$name"}{"H1"}=$log;}
				if ((defined($line[0])) && ($line[0] eq "No") && ($line[1] eq "data") && ($line[2] eq "for"))  {printf OUT_L "	NA\n"; $L{$nb}{"${fam}_$name"}{"H1"}="NA";}
				$log=$line[3];
			}
			close IN;
			#b/ run FEstim under H0
			if ($nb==1) {
				open(OUT_ID,">temp.FnA.txt") or die "\nERROR! Cannot create temp.FnA.txt.\n";
				for ($id=0; $id<$nbid ; $id++) {
					my($thisid)=$list_id[$id];
					printf OUT_ID "$fidiid{$thisid}	$f_out	$a_out\n";
				}
				close OUT_ID;
			}
			system "$RealBin/bin/$myFEstim --mplink temp2 --ped temp.ped --msmark 50 --FnA temp.FnA.txt> temp.logFEstim";		
			#c/ read likelihood under H0
			open(IN,"temp.logFEstim") or die "\nERROR! Cannot open temp.logFEstim.\n";
			while (<IN>) {
				chomp $_; @line=split;
				if ((defined($line[0])) && ($line[0] eq "Estimation")) {$fam=$line[3]; $name=(split(':',$line[5]))[0]; $thisid="${fam}_$name"; printf OUT_L "$nb	$fidiid{$thisid}	H0";}
				if ((defined($line[0])) && ($line[0] eq "1"))  {printf OUT_L "	$line[3]\n"; $L{$nb}{"${fam}_$name"}{"H0"}=$line[3];}
				if ((defined($line[0])) && ($line[0] eq "No") && ($line[1] eq "data") && ($line[2] eq "for"))  {printf OUT_L "	NA\n"; $L{$nb}{"${fam}_$name"}{"H0"}="NA";}
			}
			close IN;
		}
		if (defined($mattype)) {
			#1-a/ run FEstim under 1C
			if ($nb==1) {
				open(OUT_ID,">temp.FnA1C.txt") or die "\nERROR! Cannot create temp.FnA1C.txt.\n";
				for ($id=0; $id<$nbid ; $id++) {
					my($thisid)=$list_id[$id];
					printf OUT_ID "$fidiid{$thisid}	0.0625	0.063\n";
				}
				close OUT_ID;
			}
			system "$RealBin/bin/$myFEstim --mplink temp2 --ped temp.ped --msmark 50 --FnA temp.FnA1C.txt> temp.logFEstim";		
			#1-b/ read likelihood under 1C
			open(IN,"temp.logFEstim") or die "\nERROR! Cannot open temp.logFEstim.\n";
			while (<IN>) {
				chomp $_; @line=split;
				if ((defined($line[0])) && ($line[0] eq "Estimation")) {$fam=$line[3]; $name=(split(':',$line[5]))[0]; $thisid="${fam}_$name"; printf OUT_L "$nb	$fidiid{$thisid}	1C";}
				if ((defined($line[0])) && ($line[0] eq "1"))  {printf OUT_L "	$line[3]\n"; }
				if ((defined($line[0])) && ($line[0] eq "No") && ($line[1] eq "data") && ($line[2] eq "for"))  {printf OUT_L "	NA\n";}
			}
			close IN;
			#2-a/ run FEstim under 2C
			if ($nb==1) {
				open(OUT_ID,">temp.FnA2C.txt") or die "\nERROR! Cannot create temp.FnA2C.txt.\n";
				for ($id=0; $id<$nbid ; $id++) {
					my($thisid)=$list_id[$id];
					printf OUT_ID "$fidiid{$thisid}	0.015625	0.080\n";
				}
				close OUT_ID;
			}
			system "$RealBin/bin/$myFEstim --mplink temp2 --ped temp.ped --msmark 50 --FnA temp.FnA2C.txt> temp.logFEstim";		
			#2-b/ read likelihood under 2C
			open(IN,"temp.logFEstim") or die "\nERROR! Cannot open temp.logFEstim.\n";
			while (<IN>) {
				chomp $_; @line=split;
				if ((defined($line[0])) && ($line[0] eq "Estimation")) {$fam=$line[3]; $name=(split(':',$line[5]))[0]; $thisid="${fam}_$name"; printf OUT_L "$nb	$fidiid{$thisid}	2C";}
				if ((defined($line[0])) && ($line[0] eq "1"))  {printf OUT_L "	$line[3]\n"; }
				if ((defined($line[0])) && ($line[0] eq "No") && ($line[1] eq "data") && ($line[2] eq "for"))  {printf OUT_L "	NA\n";}
			}
			close IN;
			#3-a/ run FEstim under 2x1C
			if ($nb==1) {
				open(OUT_ID,">temp.FnA2x1C.txt") or die "\nERROR! Cannot create temp.FnA2x1C.txt.\n";
				for ($id=0; $id<$nbid ; $id++) {
					my($thisid)=$list_id[$id];
					printf OUT_ID "$fidiid{$thisid}	0.125	0.068\n";
				}
				close OUT_ID;
			}
			system "$RealBin/bin/$myFEstim --mplink temp2 --ped temp.ped --msmark 50 --FnA temp.FnA2x1C.txt> temp.logFEstim";		
			#3-b/ read likelihood under 2x1C
			open(IN,"temp.logFEstim") or die "\nERROR! Cannot open temp.logFEstim.\n";
			while (<IN>) {
				chomp $_; @line=split;
				if ((defined($line[0])) && ($line[0] eq "Estimation")) {$fam=$line[3]; $name=(split(':',$line[5]))[0]; $thisid="${fam}_$name"; printf OUT_L "$nb	$fidiid{$thisid}	2x1C";}
				if ((defined($line[0])) && ($line[0] eq "1"))  {printf OUT_L "	$line[3]\n"; }
				if ((defined($line[0])) && ($line[0] eq "No") && ($line[1] eq "data") && ($line[2] eq "for"))  {printf OUT_L "	NA\n";}
			}
			close IN;
			#4-a/ run FEstim under AV
			if ($nb==1) {
				open(OUT_ID,">temp.FnAAV.txt") or die "\nERROR! Cannot create temp.FnAAV.txt.\n";
				for ($id=0; $id<$nbid ; $id++) {
					my($thisid)=$list_id[$id];
					printf OUT_ID "$fidiid{$thisid}	0.125	0.057\n";
				}
				close OUT_ID;
			}
			system "$RealBin/bin/$myFEstim --mplink temp2 --ped temp.ped --msmark 50 --FnA temp.FnAAV.txt> temp.logFEstim";		
			#4-b/ read likelihood under AV
			open(IN,"temp.logFEstim") or die "\nERROR! Cannot open temp.logFEstim.\n";
			while (<IN>) {
				chomp $_; @line=split;
				if ((defined($line[0])) && ($line[0] eq "Estimation")) {$fam=$line[3]; $name=(split(':',$line[5]))[0]; $thisid="${fam}_$name"; printf OUT_L "$nb	$fidiid{$thisid}	AV";}
				if ((defined($line[0])) && ($line[0] eq "1"))  {printf OUT_L "	$line[3]\n";}
				if ((defined($line[0])) && ($line[0] eq "No") && ($line[1] eq "data") && ($line[2] eq "for"))  {printf OUT_L "	NA\n";}
			}
			close IN;
		}
	}
	print "\nCalculation were performed with FEstim version $version.\n";
	system "rm temp*"; 
	system " rm locusIBD.out ";	system " rm family_lodscore.out ";system " rm gemini.* "; system " rm inbreedings.out "; system " rm lodscore.out ";
	chdir ".."; 
	close OUT_FA; close OUT_L; 
	
	#4- mating type
	if (defined($mattype)) {
		print "Performing mating type.\n";
		system "R --vanilla --slave --args $out_file.likelihood $out_file.popmating $tempfolder/temp.ind.txt < $RealBin/bin/matingtype.r   > temp.R.txt ";
		system "rm temp.R.txt";		
		open(IN,"$tempfolder/temp.ind.txt") or die "\nERROR! Cannot open $tempfolder/temp.ind.txt.\n";
		while (<IN>) {
			chomp $_; @line=split;
			if ($line[0] ne "1C") {$p_ind{$line[0]} = "	$line[1]	$line[2]	$line[3]	$line[4]	$line[5]";}
		}
		close IN;
	}
	system "rm -rf $tempfolder";
	
	#4- create summary file
	print "\nCreation of summary statistic files.\n\n";
	open(OUT,">$out_file.summary") or die "\nERROR! Cannot create $out_file.summary.\n";
	printf OUT "FID	IID	STATUS	SUBMAPS	QUALITY	F_MIN	F_MAX	F_MEAN	F_MEDIAN	A_MEDIAN";
	if (!defined($noLRT))  {printf OUT "	pLRT_MEDIAN	INBRED	pLRT_<0.05";}
	if (defined($mattype)) {printf OUT "	1C	2C	2x1C	AV	OUT";}
	printf OUT "\n";
	for ($id=0; $id<$nbid ; $id++) {
		my($thisid)=$list_id[$id];
		if ($f{1}{$thisid} ne "NA") {
			$all_f = Statistics::Descriptive::Discrete->new(); $all_a = Statistics::Descriptive::Discrete->new(); $sub=0;
			if (!defined($noLRT)) {$all_test= Statistics::Descriptive::Discrete->new(); $nb_test=0;}
			for ($nb=1; $nb<=$n_subs ; $nb++) {
				if ($a{$nb}{$thisid}<=1) { 
					$all_f->add_data($f{$nb}{$thisid}); $all_a->add_data($a{$nb}{$thisid}); $sub++;
					if (!defined($noLRT)) {
						$pval=chisqrprob(2,2*($L{$nb}{$thisid}{"H1"}-$L{$nb}{$thisid}{"H0"}));
						$all_test->add_data($pval); 
						if($pval<0.05) {$nb_test++};
					}
				}
			}
			$quality=sprintf ("%0.2f",100*$sub/$n_subs);
			printf OUT "$fidiid{$thisid}	$status{$thisid}	$sub/$n_subs	$quality";
			#write f statistics
			if ($sub==0) {
				 printf OUT "	NA	NA	NA	NA	NA";
			} else {
				$stat=($all_f->min()); printf OUT "	$stat";	
				$stat=($all_f->max()); printf OUT "	$stat";	
				$stat=($all_f->mean());	printf OUT "	$stat";
				$stat=($all_f->median()); printf OUT "	$stat";
				$stat=($all_a->median()); printf OUT "	$stat";
			}
			#write LRT results
			if (!defined($noLRT)) {
				if ($sub==0) {
					printf OUT "	NA	NA	NA";
				} else {
					$stat=($all_test->median());
					if($stat<0.05) {$flag=1;} else {$flag=0;}
					printf OUT "	$stat	$flag	$nb_test";
				}
			}
			#write mating type results
			if (defined($mattype)) {
				if (defined($p_ind{$thisid})) {printf OUT "$p_ind{$thisid}";}
				else {printf OUT "	NA	NA	NA	NA	NA";}
			}
			printf OUT "\n";
		}
	}
	close OUT;
	
}

sub FLOD
{
	my($n_subs); my($folder); my($tempfolder); my($Ffolder)="FLOD"; my($inbredfile); my($listid); my($quality)=95; my($subfile);
	my($val)=0.5; my($maxi)=0.5; my($consec)=5; my($keepIBD); my($allfreq)=0.0001; my($version);
	my($nb); my($nb2); my($nb3); my(@line); my(%freq); my(%major_ref); my(%minor_ref); my(%major_data); my(%minor_data); my(%chr); my(%pos_cM); my(%pos_bp); my(%f); my(%a);
	my($map_file)=""; my($ped_file)=""; my($file)=""; my($freq_file)=""; my($bfile)=""; my($typefile);
	my(@list_iid); my(@list_fid); my(@list_iid_geno); my(@list_fid_geno); my($nbinbred)=0; my($nbinbred_geno)=0; my($flag_error)=0;
	my($e); my($i); my(%status);
	my($familywise); my(%fam); my(%idin); my(%famin); my(@listfam); my(@listfam_in); my($nbfam)=0; my($nbiso)=0; my($nbsing)=0; my(%id);
	my(%FLOD); my(%HBD); my(%nbmap); my($key); 
	
	#read and check options
	GetOptions ("FLOD", "n-submaps=i" => \$n_subs, "sub-folder=s" => \$folder, "FLOD-folder=s" => \$Ffolder, "--sub-file=s" => \$subfile,
		"map=s" => \$map_file, "ped=s" => \$ped_file, "freq=s" => \$freq_file, "bfile=s" => \$bfile, "file=s" => \$file, "familywise" => \$familywise,
		"inbred=s" => \$inbredfile, "list-id=s" => \$listid, "quality=f" => \$quality,  "q=f" => \$allfreq,
		"keep-locusIBD" => \$keepIBD,"seg-n=i" => \$consec, "seg-min=f" => \$val, "seg-max=f" => \$maxi);
	if (defined ($ARGV[0])) {die "ERROR with option $ARGV[0]!\n";}
	#check uncompatible options
	if (($file eq "") && ($bfile eq "") && ($map_file eq "") && ($ped_file eq "")  && ($freq_file eq "")) {die "\nERROR! --file, or --bfile, or --map, --ped and --freq options are mandatory.\n"}
	if (($file ne "")  && (($map_file ne "") || ($ped_file ne "")  || ($freq_file ne ""))) {die "\nERROR! --map, --ped and --freq cannot be used when using --file option.\n"}
	if (($bfile ne "") && (($map_file ne "") || ($ped_file ne "")  )) {die "\nERROR! --map and --ped cannot be used when using --bfile option.\n"}
	if (($bfile ne "") && ($file ne "")) {die "\nERROR! --file cannot be used when using --bfile option.\n"}
	if (($bfile ne "") && ($freq_file eq "")) {die "\nERROR! --bfile and --freq options should be used together.\n"}
	if ((($map_file eq "") && ($ped_file ne "")) || (($map_file ne "") && ($ped_file eq ""))) {die "\nERROR! --map and --ped options should be used together.\n"}
	#if (($thread!=1) && ($thread!=2) && ($thread!=4) && ($thread!=8)) {die "\nERROR! Only accepted values for --thread option are 1, 2, 4 and 8.\n"}
	if ($bfile ne "") {$typefile="bfile"} else {$typefile="file"}
	
	if ($typefile eq "file") {
		#check ped and map files
		if ($file ne "") { $map_file="$file.map"; $ped_file="$file.ped"; $freq_file="$file.frq";}
		else {
			if (($map_file eq "") || ($ped_file eq "") || ($freq_file eq "")) {die "\nERROR! --map, --ped and --freq options should be used together.\n"}
		}
		if(!(-e $map_file)) {die "\nERROR! Cannot open $map_file.\n";}
		if(!(-e $ped_file)) {die "\nERROR! Cannot open $ped_file.\n";}
		if(!(-e $freq_file)){die "\nERROR! Cannot open $freq_file.\n";}
		print "Running Fsuite, with --FLOD option.\nOther parameters are:\n";
		print "         Input ped file = $ped_file\n";
		print "         Input map file = $map_file\n";
		print "        Input freq file = $freq_file\n";
	} else {
		#check binary files
		if(!(-e "$bfile.bed")){die "\nERROR! Cannot open $bfile.bed.\n";}
		if(!(-e "$bfile.bim")){die "\nERROR! Cannot open $bfile.bim.\n";}
		if(!(-e "$bfile.fam")){die "\nERROR! Cannot open $bfile.fam.\n";}
		if(!(-e $freq_file  )){die "\nERROR! Cannot open $freq_file.\n";}
		print "Running Fsuite, with --FLOD option.\nOther parameters are:\n";
		print "         Input bed file = $bfile.bed\n";
		print "         Input bim file = $bfile.bim\n";	
		print "         Input fam file = $bfile.fam\n";
		print "        Input freq file = $freq_file\n";
	}
	#check inbred file
	if ( (!defined($inbredfile)) & (!defined($listid)) ){die "\nERROR! --inbred or --list-id options are mandatory.\n"}
	if ( (defined($inbredfile)) & (defined($listid)) )  {die "\nERROR! Options --inbred and --list-id cannot be used together.\n"}
	#check individuals in $listid.list, from --list-id option
	if (!defined($inbredfile)){ 
		if(!(-e "$listid.list")) {die "\nERROR! Cannot open $listid.list.\n";} 
		print "        Individual file = $listid.list\n";
		open(IN,"$listid.list") or die "\nERROR! Cannot open $listid.list.\n";
		while (<IN>) {
			chomp $_; @line=split;
			push(@list_fid,$line[0]); push(@list_iid,$line[1]); $nbinbred++; $idin{"$line[0]_$line[1]"}=1;
		}
		close IN;
		print "                          $nbinbred selected indivuals\n";
		#stock f and a results from $listid.estim
		open(IN,"$listid.estim") or die "\nERROR! Cannot open $listid.estim.\n";
		while (<IN>) {
			chomp $_; @line=split;
			if($line[3] ne "F") {
				if($line[3] eq "0.000") {$f{$line[0]}{"$line[1]_$line[2]"}=0.0001; } else { $f{$line[0]}{"$line[1]_$line[2]"}=$line[3]; }
				if($line[4] eq "0.000") {$a{$line[0]}{"$line[1]_$line[2]"}=0.0001; } else { $a{$line[0]}{"$line[1]_$line[2]"}=$line[4]; }	
			}
		}
		close IN;
	}
	#if --familywise
	#check family structure of individuals in $listid.list 
	#check .ped otherwise 
	if (!defined($familywise)){ 
		print "            Sample type = independant\n";
	} else {
		print "            Sample type = familywise\n";
		if ($typefile eq "file") {
			system "gawk '{ print \$1,\$2,\$3,\$4,\$5,\$6 }' $ped_file > pedinfo.temp" ;
		} else {
			system "gawk '{ print \$1,\$2,\$3,\$4,\$5,\$6 }' $bfile.fam > pedinfo.temp" ;
		}
		open(IN,"pedinfo.temp") or die "\nERROR! Cannot open pedinfo.temp.\n";
		#open(IN,"$ped_file") or die "\nERROR! Cannot open $ped_file.\n";
		while (<IN>) {
			chomp $_; @line=split; 
			if((defined($inbredfile)) || ((!defined($inbredfile)) && (defined($idin{"$line[0]_$line[1]"})))) {
				$id{$line[0]}{$line[1]}=1;
				if(!defined($fam{$line[0]}{"nb"})){
					$fam{$line[0]}{"nb"}=1;
					$fam{$line[0]}{"nbiso"}=0;
					push(@listfam,$line[0]);
				} else {
					$fam{$line[0]}{"nb"}=$fam{$line[0]}{"nb"}+1;
				}
				$fam{$line[0]}{$fam{$line[0]}{"nb"}}=$line[1];
				if ($line[2] ne "0") {
					if ((defined($fam{$line[0]}{"dad"})) && ($fam{$line[0]}{"dad"} ne $line[2])) {
						system "rm pedinfo.temp"; 
						die "\nERROR! There are 2 different fathers in family $line[0]: $fam{$line[0]}{\"dad\"} and $line[2].\n--familywise option only accepts nuclear family.\n";
					} else {
						$fam{$line[0]}{"dad"}=$line[2];
					}
				}
				if ($line[3] ne "0") {
					if ((defined($fam{$line[0]}{"mom"})) && ($fam{$line[0]}{"mom"} ne $line[3])) {
						system "rm pedinfo.temp"; 
						die "\nERROR! There are 2 different mothers in familiy $line[0]: $fam{$line[0]}{\"mom\"} and $line[3].\n--familywise option only accepts nuclear family.\n";
					} else {
						$fam{$line[0]}{"mom"}=$line[3];
					}
				}
				if (($line[2] eq "0") && ($line[3] eq "0")) { $fam{$line[0]}{"nbiso"}=$fam{$line[0]}{"nbiso"}+1 }
			}
		}
		close IN;
		#check format for familywise
		for ($nb=0; $nb<=$#listfam ; $nb++) { 
			if ( $fam{$listfam[$nb]}{"nb"}==1) { 
				if ((defined($fam{$listfam[$nb]}{"dad"})) && (defined($fam{$listfam[$nb]}{"mom"}))) {
					print "ERROR! Isolated individual of family $listfam[$nb] does not have \"0\" for parents' id.\n"; $flag_error=1; 
				} else {
					$nbiso++ ;
					if (!defined($inbredfile)){ push(@listfam_in,$listfam[$nb]); $famin{$listfam[$nb]}=1; }
				}
			} else {
				if ((!defined($fam{$listfam[$nb]}{"dad"})) && (!defined($fam{$listfam[$nb]}{"mom"}))) {
					print "ERROR! Family $listfam[$nb] needs two parents for option --familywise\n"; $flag_error=1;
				} elsif (!defined($id{$listfam[$nb]}{$fam{$listfam[$nb]}{"dad"}})) {
					print "ERROR! Father of family $listfam[$nb] ($fam{$listfam[$nb]}{\"dad\"}) is missing.\n"; $flag_error=1; 
				} elsif (!defined($id{$listfam[$nb]}{$fam{$listfam[$nb]}{"mom"}})) {
					print "ERROR! Mother of family $listfam[$nb] ($fam{$listfam[$nb]}{\"mom\"}) is missing.\n"; $flag_error=1; 
				} elsif ($fam{$listfam[$nb]}{"nbiso"}>2) {
					print "ERROR! Family $listfam[$nb] has more than two founders.\n--familywise option only accepts two founders in one family (the parents).\n"; $flag_error=1; 
				} else {
					if ($fam{$listfam[$nb]}{"nb"}==3) {
						$nbsing++;
						if (!defined($inbredfile)){ push(@listfam_in,$listfam[$nb]); $famin{$listfam[$nb]}=1; }
					} else {
						$nbfam++;
						push(@listfam_in,$listfam[$nb]); $famin{$listfam[$nb]}=1; #keep all nuclear families, whatever the f
					}
				}				
			}
		}
		if ($flag_error==1) {system "rm pedinfo.temp"; die "\n"}
		#if ($flag_error==1) {die "\n"}
		else { 
			if (defined($inbredfile)){ print "   Families in ped file = $nbiso isolated individuals\n";} 
			else { print "      Selected families = $nbiso isolated individuals\n"; }
			print "                          $nbsing single offspring\n";
			print "                          $nbfam nuclear families\n";
		}
		system "rm pedinfo.temp"; 
	}	
	
	#if --inbred, read results from .summary
	if (defined($inbredfile)){ 	
		if(!(-e "$inbredfile.estim")) {die "\nERROR! Cannot open $inbredfile.estim.\n";} 
		if(!(-e "$inbredfile.summary")) {die "\nERROR! Cannot open $inbredfile.summary.\n";} 
		print "     Input inbred files = $inbredfile.estim\n";
		print "                          $inbredfile.summary\n";
		if (($quality<=0) || ($quality>100)) {die "\nERROR! Value for --quality option should be between 0 and 100.\n"}
		open(IN,"$inbredfile.summary") or die "\nERROR! Cannot open $inbredfile.summary.\n";
		while (<IN>) {
			chomp $_; @line=split;
			if ($#line == 9) { die "\nERROR! File $inbredfile.summary has only 10 columns. Repeat step 3 (--FEstim) without --noLRT option.\n" }
			if(($line[2] eq 2) && ($line[4]>=$quality) && ($line[10]<0.05)) { 
				if (!defined($familywise)){ 
					push(@list_fid,$line[0]); push(@list_iid,$line[1]); $nbinbred++;
				} else {
					if (!defined($famin{$line[0]})){
						push(@listfam_in,$line[0]); $famin{$line[0]}=1;
					}
				}
			}
		}
		close IN;
		if (!defined($familywise)){ 
			print "                          $nbinbred inbred cases (quality>=$quality%)\n";
		} else {
			for ($nb=0; $nb<=$#listfam_in ; $nb++) { 
				for ($nb2=1; $nb2<=$fam{$listfam_in[$nb]}{"nb"} ; $nb2++) {
					push(@list_fid,$listfam_in[$nb]); push(@list_iid,$fam{$listfam_in[$nb]}{$nb2}); $nbinbred++;
				}
			}
			$nbfam=0; $nbiso=0; $nbsing=0;
			for ($nb=0; $nb<=$#listfam_in ; $nb++) { 
				if ( $fam{$listfam_in[$nb]}{"nb"}==1)   {$nbiso++ } 
				elsif ($fam{$listfam_in[$nb]}{"nb"}==3) {$nbsing++}
				else {$nbfam++}
			}
			$nb=$#listfam_in+1;
			print "                          $nb selected families (quality>=$quality%)\n";
			print "      Selected families = $nbiso isolated inbred individuals\n"; 
			print "                          $nbsing single inbred offspring\n";
			print "                          $nbfam nuclear families\n";
		}
		#stock f and a results from $inbredfile.estim
		open(IN,"$inbredfile.estim") or die "\nERROR! Cannot open $inbredfile.estim.\n";
		while (<IN>) {
			chomp $_; @line=split;
			if($line[3] ne "F") {
				if($line[3] eq "0.000") {$f{$line[0]}{"$line[1]_$line[2]"}=0.0001; } else { $f{$line[0]}{"$line[1]_$line[2]"}=$line[3]; }
				if($line[4] eq "0.000") {$a{$line[0]}{"$line[1]_$line[2]"}=0.0001; } else { $a{$line[0]}{"$line[1]_$line[2]"}=$line[4]; }	
			}
		}
		close IN;
	}

	if($nbinbred==0) {die "STOP! There is no inbred cases for the analysis.\n";}
	
	#check submap file/folder
	if (defined($folder) && defined($subfile)) { 
		die "\nERROR! Options --sub-folder and --subfile cannot be used together.\n"; 
	} elsif (defined($subfile)) {
		if(!(-e $subfile)) {die "\nERROR! Cannot open $subfile.\n";}
		print "      Input submap file = $subfile\n";
		if (defined($n_subs)) {print "WARNING. Option --n-submaps have been ignored.\n"}
		$n_subs=1;
	} else {
		if (!defined($folder)) {$folder="submaps"}
		print "   Input submaps folder = $folder\n";
		#check submaps
		if (defined($n_subs)){
			for ($nb=1; $nb<=$n_subs ; $nb++) { if(!(-e "$folder/submap.$nb")){die "\nERROR! Submap $folder/submap.$nb does not exist.\n";} }
			print "                          $n_subs selected submaps\n";
		} else {
			$n_subs=1; if(!(-e "$folder/submap.$n_subs")){die "\nERROR! Submap $folder/submap.$n_subs does not exist.\n";} 
			while (-e "$folder/submap.$n_subs") {$n_subs++}
			$n_subs--;
			print "                          $n_subs consecutive submaps\n";
		}
	}
	#create folder
	print "     Output FLOD folder = $Ffolder\n";
	if(-d $Ffolder) { die "\nERROR! There is already an existing $Ffolder folder. \nPlease rename it or use --FLOD-folder option.\n" } else {system "mkdir $Ffolder";}		
	#mutation frequency
	if (($allfreq<=0) || ($allfreq>=1)) {die "\nERROR! Value for -q option should be between 0 and 1.\n"}
	print "   Mutation frequency q = $allfreq\n";
	#segment options
	if ($maxi<$val) {die "\nERROR! Value of --seg-max should be higher than --seg-min.\n";} 
	if (($maxi<=0) || ($maxi>=1)) {die "\nERROR! Value for --seg-max option should be between 0 and 1.\n"}
	if (($val<=0) || ($val>=1)) {die "\nERROR! Value for --seg-min option should be between 0 and 1.\n"}
	print "           HBD segments = n=$consec, min=$val, max=$maxi\n";
	
	
	#0- create temporary binary files
	$tempfolder=sprintf("%0.0f",(rand()*(10**20))); #name of the temporary folder
	$tempfolder = "temp_$tempfolder";	
	print "       Temporary folder = $tempfolder \n\n";
	print "Creating temporary binary files.\n";
	if(-d "$tempfolder") { die "\nERROR! Cannot create temporary folder.\n" } else {system "mkdir $tempfolder";}	
	open(OUT,">$tempfolder/temp.id") or die "\nERROR! Cannot create $tempfolder/temp.id.\n";
	for ($nb=0; $nb<$nbinbred ; $nb++) { printf OUT "$list_fid[$nb]	$list_iid[$nb]\n"; }
	close OUT;
	if ($typefile eq "file") {
		system "$myplink --ped $ped_file --map $map_file --keep $tempfolder/temp.id --output-missing-phenotype 0 --make-bed --nonfounders --out $tempfolder/temp > $tempfolder/temp.logPLINK";	
	} else {
		system "$myplink --bfile $bfile --keep $tempfolder/temp.id --output-missing-phenotype 0 --make-bed --nonfounders --out $tempfolder/temp > $tempfolder/temp.logPLINK";	
	}
	
	
	#1- Checking allelic concordance
	if ($typefile eq "file") {
		print "Checking allelic concordance between $ped_file and $freq_file.\n";
	} else {
		print "Checking allelic concordance between binary inputs and $freq_file.\n";
	}
	#1-a stock allele frequencies
	open(IN,$freq_file) or die "\nERROR! Cannot open $freq_file.\n";
	while (<IN>) {
		chomp $_; @line=split;
		if ($line[1] ne "SNP") {
			$freq{$line[1]}=$line[4]; 
			if    ($freq{$line[1]} eq "NA") {
				system "rm -rf $tempfolder";
				die "\nERROR! $freq_file contains some NA. Remove these markers of the data.\n";
				#$freq{$line[1]}=0.5;   
				#print "WARNING! SNP $line[1] has a frequency equals to NA (missing for all the individuals). Its frequency will be replace by 0.5.\n"; 
			} elsif ($freq{$line[1]}==0)      {
				$freq{$line[1]}=0.0001; 
				#print "WARNING! SNP $line[1] has a frequency equals to 0 (monomorph). Its frequency will be replace by 0.0001.\n"; 
			} elsif ($freq{$line[1]}==1)      {
				$freq{$line[1]}=0.9999; 
				#print "WARNING! SNP $line[1] has a frequency equals to 1 (monomorph). Its frequency will be replace by 0.9999.\n"; 
			} 
			$major_ref{$line[1]}=$line[3]; #stocking the major allele
			$minor_ref{$line[1]}=$line[2]; #stocking the minor allele
		}
	}
	close IN;
	open(IN,"$tempfolder/temp.bim") or die "\nERROR! Cannot open $freq_file.\n";
	while (<IN>) {
		chomp $_; @line=split;
		$major_data{$line[1]}=$line[5]; #stocking the major allele
		$minor_data{$line[1]}=$line[4]; #stocking the minor allele
		if    (!defined($major_ref{$line[1]}))   {print "  ERROR.   $line[1] is not present in $freq_file.\n"; $flag_error=1;}	
		elsif ($major_data{$line[1]} eq "0")     {print "  WARNING. $line[1] has 100% of missing genotypes.\n";}	
		elsif ($major_ref{$line[1]}  eq "0")     {print "  WARNING. $line[1] has no reference allele in $freq_file.\n";}
		elsif (($major_data{$line[1]} ne $major_ref{$line[1]}) && ($major_data{$line[1]} ne $minor_ref{$line[1]}) && ($major_ref{$line[1]} ne "0") && ($minor_ref{$line[1]} ne "0")) 
			{print "  ERROR.   $line[1] major allele ($major_data{$line[1]}) is not present in $freq_file.\n";$flag_error=1;}
		elsif ($minor_data{$line[1]} eq "0")     {}	
		elsif ($minor_ref{$line[1]}  eq "0")     {}
		elsif (($minor_data{$line[1]} ne $major_ref{$line[1]}) && ($minor_data{$line[1]} ne $minor_ref{$line[1]}) && ($major_ref{$line[1]} ne "0") && ($minor_ref{$line[1]} ne "0")) 
			{print "  ERROR.   $line[1] minor allele ($minor_data{$line[1]}) is not present in $freq_file.\n";$flag_error=1;}
	}
	close IN;
	if ($flag_error==1) {system "rm -rf $tempfolder"; die "\n";}
	#1-b stock rs info
	if ($typefile eq "file") {
		open(IN,$map_file) or die "\nERROR! Cannot open $map_file.\n";
	} else {
		open(IN,"$bfile.bim") or die "\nERROR! Cannot open $bfile.bim.\n";
	}
	while (<IN>) {
		chomp $_; @line=split;
		$chr{$line[1]}=$line[0];
		$pos_cM{$line[1]}=$line[2];
		$pos_bp{$line[1]}=$line[3];
	}
	close IN;
	
	
	#2- run FEstim in a temporary file
	print "\nCalculating FLOD with FEstim on submap:\n";
	chdir $tempfolder;	
	for ($nb=1; $nb<=$n_subs ; $nb++) {
		if (($nb == 1) || ($nb % 5 == 0)) { print "$nb"} else {print "."} 
		#extract data
		if (defined($subfile)) {
			$e=myfolder("$subfile");
		} else {
			$e=myfolder("$folder/submap.$nb");
		}
		system "$myplink --bfile temp --extract $e --recode12 --nonfounders --output-missing-phenotype 0 --out temp > temp.logPLINK";
		#stock the good order of the individuals for FEstim FnA file 
		if ($nb==1) {
			@list_fid=(); @list_iid=();
			open(IN,"temp.fam") or die "\nERROR! Cannot open $tempfolder/temp.fam.\n";
			while (<IN>) {
				chomp $_; @line=split;
				push(@list_fid,$line[0]); push(@list_iid,$line[1]);
				$status{$line[0]}{$line[1]}=$line[5];
			}
			close IN;
		}
		
		#create temp2.frq file and temp2.map
		open(IN,"temp.map") or die "\nERROR! Cannot open temp.map.\n";
		open(OUTMAP,">temp2.map") or die "\nERROR! Cannot create temp2.map. \n";
		open(OUTFRQ,">temp2.frq") or die "\nERROR! Cannot create temp2.frq. \n";
		while (<IN>) {
			chomp $_; @line=split;
			printf OUTMAP "$line[0]	$line[1]	$pos_cM{$line[1]}	$line[3]\n"; 
			if ($major_data{$line[1]} eq $major_ref{$line[1]}) { printf OUTFRQ "$line[0]	$line[1]	1	2	$freq{$line[1]}	9999\n";}
			else                                               { printf OUTFRQ "$line[0]	$line[1]	2	1	$freq{$line[1]}	9999\n";}
		}
		close IN; close OUTMAP;	close OUTFRQ;	 
		
		#create FnA file for FEstim
		open(OUT_FnA,">temp.FnA.txt") or die "\nERROR! Cannot create temp.FnA.txt. \n";
		for ($nb2=0; $nb2<$nbinbred ; $nb2++) { 
			$i="$list_fid[$nb2]_$list_iid[$nb2]";
			if (!defined($f{$nb}{$i} )){ die "\nERROR! f estimation of $i is missing in estim file for submap $nb.\n" }
			if (!defined($a{$nb}{$i} )){ die "\nERROR! a estimation of $i is missing in estim file for submap $nb.\n" }
			printf OUT_FnA "$list_fid[$nb2]	$list_iid[$nb2]	$f{$nb}{$i}	$a{$nb}{$i}\n"; 
			if (($nb==1) && ($f{$nb}{$i} ne "NA")){
				push(@list_fid_geno,$list_fid[$nb2]);
				push(@list_iid_geno,$list_iid[$nb2]);
				$nbinbred_geno++;
			}
		}
		close OUT_FnA;
		
		#run FEstim
		if (!defined($familywise)) {
			system "$RealBin/bin/$myFEstim --mplink temp2 --ped temp.ped --FnA temp.FnA.txt --msmark 50 --fD $allfreq > temp.logFEstim";	    
		} elsif (($nbfam+$nbiso)==0) {
			system "$RealBin/bin/$myFEstim --mplink temp2 --ped temp.ped --FnA temp.FnA.txt --msmark 50 --fD $allfreq > temp.logFEstim";	    
		} else {
			if ($nb==1) {
				open(OUT1,">LODnoInbreeding.txt") or die "\nERROR! Cannot create LODnoInbreeding.txt. \n";
				open(OUT2,">temp.merlin.list") or die "\nERROR! Cannot create temp.merlin.list. \n";
				for ($nb2=0; $nb2<=$#listfam_in ; $nb2++) { 
					if ( $fam{$listfam_in[$nb2]}{"nb"}==1)   {printf OUT1 "$listfam_in[$nb2]	ISO\n" } 
					elsif ($fam{$listfam_in[$nb2]}{"nb"}==3) {printf OUT1 "$listfam_in[$nb2]	SINGLE_OFFSPRING\n" }
					else {
						printf OUT1 "$listfam_in[$nb2]	$listfam_in[$nb2].lod\n";
						for ($nb3=1; $nb3<=$fam{$listfam_in[$nb2]}{"nb"} ; $nb3++) { 						
							printf OUT2 "$listfam_in[$nb2]	$fam{$listfam_in[$nb2]}{$nb3}\n";
						}
					}
				}
				close OUT1; close OUT2;
			}
			if ($nbfam>0){
				#prepare file for merlin
				#model
				#system "echo 'DISEASE $allfreq 0.000,0.000,1.000 Recessif_Model' > temp.merlin.model";
				open(OUT,">temp.merlin.model") or die "\nERROR! Cannot create temp.merlin.model. \n";
				printf OUT "DISEASE $allfreq 0.000,0.000,1.000 Recessif_Model\n";
				close OUT;
				#ped
				system "$myplink --file temp --keep temp.merlin.list --output-missing-phenotype 0 --recode --out temp.merlin > temp.logPLINK";
				#map and dat
				#system "awk '{print \$1,\$2,\$3}' temp2.map > temp.merlin.map ";
				#system "echo 'A DISEASE' > temp.merlin.dat";
				#system "awk '{print \"M\",\$2}'  temp2.map >> temp.merlin.dat";				
				open(IN,"temp2.map") or die "\nERROR! Cannot open temp2.map.\n";
				open(OUT1,">temp.merlin.map") or die "\nERROR! Cannot create temp.merlin.map. \n";
				open(OUT2,">temp.merlin.dat") or die "\nERROR! Cannot create temp.merlin.dat. \n";
				printf OUT2 "A	DISEASE\n";
				while (<IN>) {
					chomp $_; @line=split;
					printf OUT1 "$line[0]	$line[1]	$line[2]\n";
					printf OUT2 "M	$line[1]\n";
				}
				close OUT1; close OUT2; close IN;
				#freq
				open(OUT,">temp.merlin.frq") or die "\nERROR! Cannot create temp.merlin.frq. \n";
				open(IN,"temp2.frq") or die "\nERROR! Cannot open $tempfolder/temp.logFEstim.\n";
				while (<IN>) {
					chomp $_; @line=split;
					printf OUT "M	$line[1]\n";
					$nb2=1-$line[4];
					if($line[2]==1) { printf OUT "F	$line[4]	$nb2\n"; }
					else { printf OUT "F	$nb2	$line[4]\n"; } 
				}
				close OUT; close IN;
				#merlin
				system "$myMerlin -d temp.merlin.dat -p temp.merlin.ped -m temp.merlin.map -f temp.merlin.frq --model temp.merlin.model  --perFamily --tabulate --markerNames --prefix temp.merlin > temp.merlin.log";
				#convert merlin outputs for FEstim
				for ($nb2=0; $nb2<=$#listfam_in ; $nb2++) { 
					if ( $fam{$listfam_in[$nb2]}{"nb"}>=4)   {
						open(OUT,">$listfam_in[$nb2].lod") or die "\nERROR! Cannot create $listfam_in[$nb2].lod. \n";
						open(IN,"temp.merlin.par") or die "\nERROR! Cannot open $tempfolder/temp.merlin.par.\n";
						while (<IN>) {
							chomp $_; @line=split;
							if ($listfam_in[$nb2] eq $line[1]) {printf OUT "$line[2]	$chr{$line[2]}	$pos_cM{$line[2]}	$line[3]\n";}
						}
						close IN; close OUT;
					}
				}
			}
			#FEstim
			system "$RealBin/bin/$myFEstim --mplink temp2 --ped temp.ped --FnA temp.FnA.txt --msmark 50 --fD $allfreq --familywise LODnoInbreeding.txt > temp.logFEstim";
			
		}
		
		#stock FEstim version
		if ($nb==1) {
			open(IN,"temp.logFEstim") or die "\nERROR! Cannot open $tempfolder/temp.logFEstim.\n";
			while (<IN>) {
				if (!defined($version)) {
					chomp $_; @line=split;
					if ($line[0] eq "**"){
						if ($line[1] eq "FEstim"){ $version= substr($line[3],0,length($line[3])-1); }
					}
				}
			}
			close IN;
		}
		
		#keeping files
		open (IN, "locusIBD.out") || die "\nERROR! Cannot open locusIBD.out.\n";
		while (<IN>) {
			chomp $_; @line=split;
			if ($line[6] ne "FLOD") {
				$key=$line[0].$line[1];
				if (!defined($HBD{$key})) {
					$HBD{$key}  = $line[5];
					if (!defined($familywise)) {$FLOD{$key} = $line[6];}
					$nbmap{$key} = 1;
				} else {
					$HBD{$key}  = $HBD{$key}  + $line[5]; 
					if (!defined($familywise)) {$FLOD{$key} = $FLOD{$key} + $line[6];} 
					$nbmap{$key}++; 
				}
			}
		}
		close IN;
		if (defined($keepIBD)){
			if(-d $Ffolder) {system "cp locusIBD.out $Ffolder/locusIBD.$nb.out";	}
			else {system "cp locusIBD.out ../$Ffolder/locusIBD.$nb.out";	}
		}
		
		if (defined($familywise)) {
			open (IN, "family_lodscore.out") || die "\nERROR! Cannot open family_lodscore.out.\n";
			while (<IN>) {
				chomp $_; @line=split;
				if ($line[4] ne "FLOD") {
					$key=$line[0].$line[1];
					if (!defined($FLOD{$key})) {
						$FLOD{$key} = $line[4];
						$nbmap{$key} = 1;
					} else {
						$FLOD{$key} = $FLOD{$key} + $line[4]; 
						$nbmap{$key}++; 
					}
				}
			}
			close IN;
		}
		
	}
	print "\nCalculation were performed with FEstim version $version.\n\n";
	system "rm temp*"; 
	system " rm locusIBD.out ";	system " rm family_lodscore.out ";system " rm gemini.* "; system " rm inbreedings.out "; system " rm lodscore.out ";
	chdir "..";
	system "rm -rf $tempfolder"; 
	
	#3- create FLOD.txt and HBD.txt
	print "Creating FLOD.txt and HBD.txt files in $Ffolder folder.\n";
	#3-a create the files with header
	open(OUTF,">$Ffolder/FLOD.txt") or die "\nERROR! Cannot create $Ffolder/FLOD.txt.\n";
	printf OUTF "CHR	RS	POS_cM	POS_bp"; 
	if (!defined($familywise)) {
		for ($nb=0; $nb<$nbinbred_geno ; $nb++) { printf OUTF "	$list_fid_geno[$nb]_$list_iid_geno[$nb]"; }
	} else {
		for ($nb=0; $nb<=$#listfam_in ; $nb++) { printf OUTF "	$listfam_in[$nb]"}
	}
	printf OUTF "\n";
	open(OUTH,">$Ffolder/HBD.txt")  or die "\nERROR! Cannot create $Ffolder/HBD.txt.\n";
	printf OUTH "CHR	RS	POS_cM	POS_bp"; 
	for ($nb=0; $nb<$nbinbred_geno ; $nb++) { printf OUTH "	$list_fid_geno[$nb]_$list_iid_geno[$nb]"; }
	printf OUTH "\n";
	#3-b file the files
	my(@myrs);
		if ($typefile eq "file") {
		open(IN,$map_file) or die "\nERROR! Cannot open $map_file.\n";
	} else {
		open(IN,"$bfile.bim") or die "\nERROR! Cannot open $bfile.bim.\n";
	}
	while (<IN>) {
		chomp $_; @line=split;
		if (defined($HBD{"$list_fid_geno[0]_$list_iid_geno[0]".$line[1]})){
			printf OUTF	"$line[0]	$line[1]	$line[2]	$line[3]";	
			printf OUTH	"$line[0]	$line[1]	$line[2]	$line[3]";
			for ($nb=0; $nb<$nbinbred_geno ; $nb++) { 
				if (!defined($familywise)) {
					printf OUTF "\t%0.3f",$FLOD{"$list_fid_geno[$nb]_$list_iid_geno[$nb]".$line[1]}/$nbmap{"$list_fid_geno[$nb]_$list_iid_geno[$nb]".$line[1]}; 
				} 
				printf OUTH "\t%0.4f",$HBD{"$list_fid_geno[$nb]_$list_iid_geno[$nb]".$line[1]}/$nbmap{"$list_fid_geno[$nb]_$list_iid_geno[$nb]".$line[1]}; 
			}
			if (defined($familywise)) {
				for ($nb=0; $nb<=$#listfam_in ; $nb++) { 
					printf OUTF "\t%0.3f",$FLOD{"$listfam_in[$nb]".$line[1]}/$nbmap{"$listfam_in[$nb]".$line[1]}; 
				}
			}
			printf OUTF "\n";
			printf OUTH "\n";
			push (@myrs,$line[1]);
		}
	}
	close IN;
	close OUTF; close OUTH;
	#3-c detect HBD segments
	print "Creating HBD.segments.txt file in $Ffolder folder.\n\n";
	open(OUT,">$Ffolder/HBD.segments.txt") or die "\nERROR! Cannot create $Ffolder/segments.txt.\n\n";
	printf OUT "FID	IID STATUS	CHR	DEB_rs	FIN_rs	DEB_cM	FIN_cM	DEB_bp	FIN_bp	NMARKERS\n";
	my($HBD_prec); my($max); my($nbin); my($myhbd); my($deb); my($fin);
	for ($nb=0; $nb<$nbinbred_geno ; $nb++) { 
		$HBD_prec=0;
		for ($i=0; $i<$#myrs ; $i++) { 
			$myhbd=$HBD{"$list_fid_geno[$nb]_$list_iid_geno[$nb]".$myrs[$i]}/$nbmap{"$list_fid_geno[$nb]_$list_iid_geno[$nb]".$myrs[$i]};
			if    ($myhbd >= $val && $HBD_prec eq 0) { 
				$deb=$myrs[$i]; $HBD_prec=1; $fin=$myrs[$i]; $max=$myhbd; $nbin=1;
			} elsif ($myhbd <  $val && $HBD_prec eq 1) { 
				if (($max>=$maxi) && ($nbin>$consec)) {printf OUT "$list_fid_geno[$nb]	$list_iid_geno[$nb] $status{$list_fid_geno[$nb]}{$list_iid_geno[$nb]}	$chr{$deb}	$deb	$fin	$pos_cM{$deb}	$pos_cM{$fin}	$pos_bp{$deb}	$pos_bp{$fin}	$nbin\n";}
				$HBD_prec=0;
			} elsif ($myhbd >= $val && $HBD_prec eq 1) {
				if (($i>0) & ($chr{$myrs[$i]}==$chr{$myrs[$i-1]})){
					$nbin++; $fin=$myrs[$i]; if ($myhbd>$max) {$max=$myhbd;}
				} else {
					if (($max>=$maxi) && ($nbin>$consec)) {printf OUT "$list_fid_geno[$nb]	$list_iid_geno[$nb]	$status{$list_fid_geno[$nb]}{$list_iid_geno[$nb]} $chr{$deb}	$deb	$fin	$pos_cM{$deb}	$pos_cM{$fin}	$pos_bp{$deb}	$pos_bp{$fin}	$nbin\n";}
					$deb=$myrs[$i]; $HBD_prec=1; $fin=$myrs[$i]; $max=$myhbd; $nbin=1;
				}
			}
		}
		if (($HBD_prec eq 1) && ($max>=$maxi) && ($nbin>$consec)) { printf OUT "$list_fid_geno[$nb]	$list_iid_geno[$nb]	$status{$list_fid_geno[$nb]}{$list_iid_geno[$nb]} $chr{$deb}	$deb	$fin	$pos_cM{$deb}	$pos_cM{$fin}	$pos_bp{$deb}	$pos_bp{$fin}	$nbin\n";}
	}
	close OUT;
	
}

sub HFLOD
{
	my($HFfolder)="HFLOD"; my($Ffile)="FLOD/FLOD.txt"; my($step)=0.01; my($MAn)=50; my($distance); my($nbind);
	my($regions)="empty";
	
	my(@alpha); my(@line); my(@HFLOD); my(@temp); my(@HFLODinit)=();
	my($nb); my($nb2); my($maxH); my($maxA); my($FLOD); my($chr_prec)=1;
	
	#0-read and check options
	GetOptions ("HFLOD", 
		"HFLOD-folder=s" => \$HFfolder, 
		"FLOD-file=s" => \$Ffile,
		"step=f" => \$step,
		"MA-n=i" => \$MAn,
		"bases" => \$distance,
		"regions=s" => \$regions);
	if (defined ($ARGV[0])) {die "ERROR with option $ARGV[0]!\n";}
	#check uncompatible options
	if (($step<=0) || ($step>=1)) {die "\nERROR! Value for --step option should be between 0 and 1.\n"}
	#check FLOD file and HFLOD floder
	print "    Output HFLOD folder = $HFfolder\n";
	if(-d $HFfolder) { die "\nERROR! There is already an existing $HFfolder folder. \nPlease rename it or use --HFLOD-folder option.\n" } else {system "mkdir $HFfolder";}		
	if(!(-e $Ffile)){die "\nERROR! Cannot open $Ffile.\n";}
	print "Running Fsuite, with --HFLOD option.\nOther parameters are:\n";
	print "        Input FLOD file = $Ffile\n";
	#calculate the number of individuals
	open(IN,$Ffile) or die "\nERROR! Cannot open $Ffile.\n";
	$_=<IN>; chomp $_; @line=split;
	$nbind=$#line-3; if ($nbind<=0) {die "\nERROR! No FLOD in $Ffile.\n"}
	close IN;
	print "                          $nbind individuals/families\n";
	#others
	if (($step<=0) || ($step>=1)) {die "\nERROR! Value for --step option should be between 0 and 1.\n"}
	print "         step for alpha = $step\n";
	print "      SNPs for MA_HFLOD = $MAn\n";
	if (defined($distance)){$distance="bases"} else {$distance="cM"}
	print "      distance (graphs) = $distance\n";
	#regions
	if  ($regions ne "empty") {print "           regions file = $regions\n";}
	if (($regions ne "empty") && (!(-e $regions))) {die "\nERROR! Cannot open $regions.\n";}
	print "\n";
	
	#create alpha
	$nb=0;
	while ($nb*$step<1) {
		push(@alpha,$nb*$step);
		$nb++;
		push(@HFLODinit,0);
	}
	push(@alpha,1); push(@HFLODinit,0);
	
	#create output header
	open(OUT,">$HFfolder/HFLOD.temp.txt") or die "\nERROR! Cannot open $HFfolder/HFLOD.temp.txt.\n";
	printf OUT "CHR	RS	POS_cM	POS_bp	HFLOD ALPHA\n"; 
	
	#read FLOD file
	print "Calculating HFLOD on:\n";
	print "  chromosome 1\n";
	open(IN,$Ffile) or die "\nERROR! Cannot open $Ffile.\n$!\n";
	while (<IN>) {
		chomp $_; @line=split;
		if (($line[0] ne "CHR") &&($line[0]>=1) && ($line[0]<=$nbchr)) {
			if ($line[0]!=$chr_prec) {$chr_prec=$line[0]; print "  chromosome $line[0]\n";}
			#init HFLOD
			@HFLOD=@HFLODinit;
			#calculate HFLOD score
			for ($nb=4; $nb<=$#line ; $nb++) {
				$FLOD=$line[$nb];
				#@temp=map log( $_ * (exp($FLOD*log(10))-1) + 1)/log(10), @alpha;
				@temp=map  $_ * (exp($FLOD*log(10))-1) + 1, @alpha;
				@temp=map max( $_ ,0.0001), @temp;
				@temp=map log($_)/log(10), @temp;
				for ($nb2=0; $nb2<=$#alpha; $nb2++) { $HFLOD[$nb2]=$HFLOD[$nb2]+$temp[$nb2] }
				#@HFLOD = pairwise { our $a + our $b } @HFLOD, @temp;
			}
			$maxH=-9999; 
			for ($nb=0; $nb<=$#alpha; $nb++) {
				if ($HFLOD[$nb]>$maxH) {
					$maxH=$HFLOD[$nb]; 
					if($nb*$step<=1) {$maxA=$nb*$step} else {$maxA=1}
				}
			}
			$maxH=sprintf ("%0.3f",$maxH);			
			printf OUT "$line[0]	$line[1]	$line[2]	$line[3]	$maxH $maxA\n";
		}
	}
	close IN;
	close OUT;

	print "\nCreating HFLOD.txt file and HFLOD graphs in $HFfolder folder.\n";
	system "R --vanilla --slave --args $HFfolder $distance $nbchr $MAn $regions< $RealBin/bin/HFLOD_graphs.r   > temp.R.txt ";
	system "rm temp.R.txt";
	system "rm $HFfolder/HFLOD.temp.txt";
	print "\n";
	
}

sub plotHBD
{
	my($seg_file)="FLOD/HBD.segments.txt"; my($fid)=""; my($iid)=""; my($chr)=""; my($distance); my($circos);
	my($out)="empty"; my($listid)="empty"; my($regions)="empty";
	
	#0-read and check options
	GetOptions ("plot-HBD", "seg-file=s" => \$seg_file, "fid=s" => \$fid, "iid=s" => \$iid, "chr=i" => \$chr, "circos" => \$circos, 
	"cM" => \$distance,  "out=s" => \$out, "list-id=s" => \$listid, "regions=s" => \$regions);
	if (defined ($ARGV[0])) {die "ERROR with option $ARGV[0]!\n";}
	if(!(-e $seg_file)) {die "\nERROR! Cannot open $seg_file.\n";}
	if ((($fid eq "") && ($iid ne "")) || (($fid ne "") && ($iid eq ""))) {die "\nERROR! --fid and --iid options should be used together.\n"}
	if (($fid eq "") && ($chr eq "") && !defined($circos)) {die "\nERROR! You should at least select one of the following options:\n   --fid and --iid,\n   --chr,\n   --circos.\n"}
	if (($fid ne "") && ($chr ne "")) {die "\nERROR! --fid --iid and --chr options cannot be used together.\n"}
	if (($fid ne "") && defined($circos)) {die "\nERROR! --fid --iid and --circos options cannot be used together.\n"}
	if (($chr ne "") && defined($circos)) {die "\nERROR! --chr and --circos options cannot be used together.\n"}
	if (defined($distance) && defined($circos)) {die "\nERROR! --circos and --cM options cannot be used together.\n"}
	if ($listid  ne "empty") {
		if(!(-e $listid )) {die "\nERROR! Cannot open $listid.\n";}
		if ($fid ne "") {die "\nERROR! --list-id is not compatible with --fid --iid options.\n";}
	}
	if (($regions ne "empty") && (!(-e $regions))) {die "\nERROR! Cannot open $regions.\n";}
	if (defined($distance)){$distance="cM"} else {$distance="bases"}
	
	print "Running Fsuite, with --plot-HBD option.\nOther parameters are:\n";
	print " HBD segment file = $seg_file\n";
	print "         distance = $distance\n";
	if ($listid  ne "empty") {print "     list-id file = $listid\n";}
	if ($regions ne "empty") {print "     regions file = $regions\n";}
	
	#1- options fid iid
	if (($fid ne "") && ($iid ne "")) { 
		print "\nPlotting HBD segments for ${fid}_$iid.\n\n";
		system "R --vanilla --slave --args $seg_file $fid $iid $out $regions $distance < $RealBin/bin/HBD_plot_id.r   > temp.R.txt ";
		system "rm temp.R.txt";
	}

	#2- options chr
	if ($chr ne "") { 
		print "\nPlotting HBD segments on chromosome $chr.\n\n";
		system "R --vanilla --slave --args $seg_file $chr $out $listid $regions $distance < $RealBin/bin/HBD_plot_chr.r   > temp.R.txt ";
		system "rm temp.R.txt";
	}
	
	#3- options circos
	if (defined($circos)) { 
		print "\nPlotting a circos plot.\n\n";
		system "perl $RealBin/bin/Circos_v1.pl $seg_file HBD $RealBin/bin/conf $out $listid $mycircos ";
	}
	
}

sub ROH
{
	my($hom_file)=""; my($fid)=""; my($iid)=""; my($chr)=""; my($mapERSA)=""; my($distance)="bases"; my($circos);
	my($map)=""; my($out)="empty"; my($listid)="empty"; my($regions)="empty"; my($controls);
	
	#0-read and check options
	GetOptions ("ROH=s" => \$hom_file, "fid=s" => \$fid, "iid=s" => \$iid, "chr=i" => \$chr, "circos" => \$circos, "ERSA=s" => \$mapERSA,  
	"cM=s" => \$map,  "out=s" => \$out, "list-id=s" => \$listid, "regions=s" => \$regions, "controls" => \$controls);
	if (defined ($ARGV[0])) {die "ERROR with option $ARGV[0]!\n";}
	if(!(-e $hom_file)) {die "\nERROR! Cannot open $hom_file.\n";}
	if ((($fid eq "") && ($iid ne "")) || (($fid ne "") && ($iid eq ""))) {die "\nERROR! --fid and --iid options should be used together.\n"}
	if (($fid eq "") && ($chr eq "") && !defined($circos)) {die "\nERROR! You should at least select one of the following options:\n   --fid and --iid,\n   --chr,\n   --circos.\n"}
	if (($fid ne "") && ($chr     ne "")) {die "\nERROR! --fid --iid and --chr options cannot be used together.\n"}
	if (($fid ne "") && defined($circos)) {die "\nERROR! --fid --iid and --circos options cannot be used together.\n"}
	if (($chr ne "") && defined($circos)) {die "\nERROR! --chr and --circos options cannot be used together.\n"}
	if (($distance eq "cM") && defined($circos)) {die "\nERROR! --circos and --cM options cannot be used together.\n"}
	#if (($fid ne "") && ($mapERSA ne "")) {die "\nERROR! --fid --iid and --ERSA options cannot be used together.\n"}
	#if (($chr ne "") && ($mapERSA ne "")) {die "\nERROR! --chr and --ERSA options cannot be used together.\n"}
	#if (($mapERSA eq "") && defined($controls)) {die "\nERROR! --controls can only be used with --ERSA option.\n"}
	if ($map ne "") {$distance="cM"; if(!(-e $map)) {die "\nERROR! Cannot open $map.\n";}}
	if ($listid  ne "empty") {
		if(!(-e $listid )) {die "\nERROR! Cannot open $listid.\n";}
		if ($fid ne "") {die "\nERROR! --list-id is not compatible with --fid --iid options.\n";}
	}
	if ($regions ne "empty") {
		if(!(-e $regions)) {die "\nERROR! Cannot open $regions.\n";}
		#if ($mapERSA ne "") {die "\nERROR! --regions is not compatible with --ERSA option.\n";}
	}

	print "Running Fsuite, with --ROH option.\nOther parameters are:\n";
	print "         ROH file = $hom_file\n";
	print "         distance = $distance\n";
	if ($listid  ne "empty") {print "     list-id file = $listid\n";}
	if ($regions ne "empty") {print "     regions file = $regions\n";}
	
	#1- options fid iid
	if (($fid ne "") && ($iid ne "")) { 
		print "\nPlotting ROH for ${fid}_$iid.\n\n";
		system "R --vanilla --slave --args $hom_file $fid $iid $out $regions $distance $map < $RealBin/bin/ROH_plot_id.r   > temp.R.txt ";
		system "rm temp.R.txt";
	}

	#2- options chr
	if ($chr ne "") { 
		print "\nPlotting ROH on chromosome $chr.\n\n";
		system "R --vanilla --slave --args $hom_file $chr $out $listid $regions $distance $map < $RealBin/bin/ROH_plot_chr.r   > temp.R.txt ";
		system "rm temp.R.txt";
	}
	
	#3- options circos
	if (defined($circos)) { 
		print "\nPlotting a circos plot.\n\n";
		system "perl $RealBin/bin/Circos_v1.pl $hom_file ROH $RealBin/bin/conf $out $listid $mycircos ";
	}
	
	# #4- options ERSA ### A VERIFIER
	# if ($mapERSA ne "") { 
		# if(!(-e $mapERSA )) {die "\nERROR! Cannot open $mapERSA.\n";}
		# if (defined($controls)) { $controls="yes"} else {$controls="no"}
		# system "R --vanilla --slave --args $hom_file $mapERSA $listid $controls< $RealBin/bin/ROH_ERSA.r ";
	# }
	
}

sub print_help
{
	print "Here are the first options of this pipeline,\n"; 
	print "and their specific options:\n\n";
	print "  --estimate-frequencies\n";
	print "      inputs:  --file or --bfile or --ped and --map \n";
	print "               --list-id \n";
	print "      output:  --out \n";
	print "      others:  --freq-controls[dft] or --freq-all \n";
	print "  --create-submaps\n";
	print "      input:   --map \n";
	print "      output:  --sub-folder[dft=submaps] \n";
	print "      others:  --n-submaps[dft=100]\n";
	print "               --cM[dft=0.5], --kb or --hotspots\n";
	print "               --hotspots-intensity[dft=10]\n";
	print "               --coverage\n";
	print "  --FEstim\n";
	print "      inputs:  --file or --bfile and --freq or --ped, --map and --freq \n";
	print "               --sub-folder[dft=submaps] or --sub-file \n";
	print "               --list-id \n";
	print "      outputs: --out \n";
	print "               --mating-type or --noLRT\n";
	print "               --keep-locusIBD \n";
	print "      others:  --f-outbred[f=0.001] and --a-outbred[a=0.001] \n";
	print "               --n-submaps\n";
	print "  --FLOD\n";
	print "      inputs:  --file or --bfile and --freq or --ped, --map and --freq \n";
	print "               --inbred or --list-id \n";
	print "               --sub-folder[dft=submaps] or --sub-file \n";
	print "      outputs: --FLOD-folder[dft=FLOD] \n";
	print "               --keep-locusIBD \n";
	print "      others:  --familywise \n";
	print "               --quality[dft=95] \n";
	print "               --n-submaps\n";
	print "               -q[dft=0.0001]\n";
	print "               --seg-n[dft=5], seg-min[dft=0.5], seg-max[dft=0.5]\n";
	print "  --HFLOD\n";
	print "      input:   --FLOD-file[dft=FLOD/FLOD.txt]\n";
	print "      output:  --HFLOD-folder[dft=HFLOD] \n";
	print "      others:  --step[dft=0.01], --MA-n[dft=50] \n";
	print "               --bases\n";
	print "               --regions\n";
	print "  --plot-HBD\n";
	print "      inputs:  --chr or --fid and --iid \n";
	print "               --seg-file[dft=FLOD/HBD.segments.txt] \n";
	print "               --list-id \n";
	print "               --regions \n";
	print "      output:  --out \n";
	print "      other:   --cM \n";
	print "  --ROH\n";
	print "      inputs:  --chr, --fid and --iid\n";
	#print "               --ERSA [not implemented] \n";
	print "               --list-id \n";
	print "               --regions \n";
	print "               --cM \n";
	print "      output:  --out \n\n";
}

MAIN:
{
	print_header();
	if    ($#ARGV < 0)                           { print_help() }
	elsif ($ARGV[0] eq "--estimate-frequencies") { freq() }
	elsif ($ARGV[0] eq "--create-submaps")       { create_submaps() }
	elsif ($ARGV[0] eq "--FEstim")               { FEstim() }
	elsif ($ARGV[0] eq "--FLOD")                 { FLOD() }
	elsif ($ARGV[0] eq "--HFLOD")                { HFLOD() }
	elsif ($ARGV[0] eq "--plot-HBD")             { plotHBD() }
	elsif ($ARGV[0] eq "--ROH")                  { ROH() }
	elsif ($ARGV[0] eq "--help")                 { print_help() }
	else  {
		print "ERROR! $ARGV[0] is not a valid option.\n"; 
		print "First option should be: \n";
		print "  --estimate-frequencies\n";
		print "  --create-submaps\n";
		print "  --FEstim\n";
		print "  --FLOD\n";
		print "  --HFLOD\n";
		print "  --plot-HBD\n";
		print "  --ROH\n";
		exit (1)
	}

	exit( 0 );
}
