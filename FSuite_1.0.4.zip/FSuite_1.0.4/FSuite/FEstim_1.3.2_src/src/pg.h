/*****************************************************************************/
/* Name: pg.h                                                                */
/* Author: AL Leutenegger                                                    */
/* Description: all constants, variable and functions for FEstim_main.c      */
/* Date: 03 May 2002, Feb 2006, July 2006                                    */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
 
#define TOT_NUM_GENE 2 /* Nb of homologous chr considered in IBD process */
#define TOT_IBD_STATE 2  /* Nb of possible IBD states */
/* Note: 2 genes => 2 states, 4 genes => 9 states */

#define SCALE 10E30

#define mINF -9999.    /* value used for -infinity in the computation */ 

#define MAXiterated 20 /* for gemini.c */

#define Eprintf(s...) fprintf(stderr, s)

typedef struct _markmap {
  int chr;
  char *name;
  double dist;
  int num_allele;
  int *allele_name;
  double *freq;
} markmap;

typedef struct _indiv {
  char *id;
  char *famid;
  char *dadid;
  char *momid;
  int sex;
  int trait;
  int **markdat;
} indiv;

typedef double real;
typedef real vector[MAXiterated];
typedef vector matrix[MAXiterated];

extern real EPSILON;
extern real TOL_ALLELE_FREQ;
extern real tol ;
extern int NUM_ITER_MC;
extern int MAX_NAME_MARKER;
extern int MAX_LENGTH_ID;
extern int MAX_LENGTH_FAMID;
extern int MAX_NUM_SIB_FAM;
extern real fD ;
extern int REP ;
extern int MAX_LENGTH_LINE;
extern int cM;


typedef int tmaxn[MAXiterated];

/* global variable */
extern int TOT_NUM_LOCUS;
extern int TOT_NUM_INDIV;
extern int TOT_NUM_FAM;
extern int TOT_NUM_ISO;
extern int NUM_SCALE;
extern markmap *MAP;
extern indiv *DATA;
extern markmap *CMAP;
extern indiv *CDATA;
extern int nIndiv;
extern int *DATAisZERO;
extern int CSOME_NUM_LOCUS;
extern int FIRST_PRINT_CPROBA;
extern int HET;
/* for gemini.c */
extern vector xall;
extern tmaxn itp;
extern int COMPUT_CSOME;
extern FILE *outfile, *detfile;

/* input_data.c */
char *my_strchr(char *string_ptr, char find);
int Init_marker(char *filename, int *nmarker);
int Get_marker_information(char *filename, markmap *map);
int Init_marker_plinkformat(char *filename, int *tot_num_locus);
int Get_marker_information_plinkformat(char *filename, markmap *map);
int Print_marker_information(char *filename, markmap *map); 
int Free_marker(markmap *map, int nmarker);
int Init_data(char *filename, int *nindiv);
int Get_data_information(markmap *map, char *filename, 
			 int *data0, char *sample, indiv *data);
int Print_data_information(char *filename, indiv *data);
int Free_data(indiv *data, int nmarker);
int Get_input_genome(char *mapfile, char *datafile, char *sample);
int Get_input_genome_plinkOK(char *inputopt, char *mapfile, char *datafile, 
			     char *sample);
int Get_lodnuclear_noinbreed(int nmarker, markmap *map, char *filename, 
			     real *lod_noinbreed);
int Get_list_lodnuclear_noinbreed(int nmarker, markmap *map, char *filename, 
				  real **fam_lod_noinbreed);
int Get_FnA(char *filename, real *inball, real *aall);
int Get_input_HET(char *filename, markmap *map);

/* output_results.c */
int Print_inbreeding(char *filename, char *std_error, int nindiv, 
		     real inb, real a, real *se);
int Print_inbreeding_nuclear(char *filename, int *indiv_aff, 
			     real *inb_med, real *a_med);
int Print_lodscore(char *filename, real *lod);
int SumNprint_family_lod(char *filename, real **fam_lod_noinbreed, 
			 int add, int first_print, int fam, int nindiv, 
			 real *lodn);
int SumNprint_family_lod_independent(char *filename, real *lodn, 
				     int nindiv, real *lod);
int Print_conditional_proba(char *filename, int first_print, int nindiv, 
			    real inb, real a, real **q, real *lodn);
int Print_conditional_proba_v2(char *filename, int first_print, int nindiv, 
			       real **q, real *lodn, int *BI);
int Print_bestibd(char *filename, int first_print, int nindiv, 
		  real inb, real a, int *BI);

/* baum_cond.c */
int Likfast(real inb, real aa, markmap *map, int **y, int nmarker, 
	    real *proba_data);
int Forward(real inb, real aa, markmap *map, int **y, int nmarker, 
	    real **RStar);
int Conditional_proba(real inb, real aa, markmap *map, int **y, int nmarker, 
		      real **q, real ***qq);
int Conditional_proba_csomebycsome(real *inb, real *aa, markmap *map, int **y, 
				   int nmarker, real **q, real ***qq);
int Sample_from_posterior1(real **q, real ***qq, 
			   int nmarker, int *ibd_sample);
  /* Sample from X from P(X|Y) using Q & QQ */
int get_prior(int s, real inb, real *prior);
int get_trans(int s1, int s2, real inb, real aa, double x, real *trans);
int get_proba(int *yl, int s, double *freq, real *proba);
/*end baum_cond.c*/

/* gchomapp.c */
int GClogLikRatio(real inb, real **q, real *logTkn);
int compare( real *f1, real *f2 );
real getmedian( real *data, int   n );
int get_FnA_forLODnuclear(real *inball, real *aall, 
			  int nindiv, real *medF, real *medA);
int GClogLikRatio_nuclear_sample (real *inb, real *a, real *lod_noinbreed, 
				  int *list_affected_indiv, real *medF, 
				  real *medA, real *logTk_nuclear);
int GClogLikRatio_nuclear_family (real *inb, real *a, real **fam_lod_noinbreed, 
				  int *list_affected_indiv, real *medF, 
				  real *medA, real *lTk);
/* end gchomapp.c */

/* viterbi.c */
int Viterbi(real inb, real aa, markmap *map, int **y, int *best_ibd);
int Viterbi2(real inb, real aa, markmap *map, int **y, int *best_ibd);
/* end viterbi.c */

/* gemini.c */
void outcontrol(vector z,int nn);
void outgemini();
void step();
void firststep();
void decreaset();
void increaset();
void step();
void update();
void prep();
void sr1update();
void sr2update();
void getwzs();
void recur();
void gemini();
void bldlt(matrix b);
void inib();
void initialize();
void gforward();
void gcentral();
void getp();
void getytp();
void chkbnd();
void iterate();
int precision();
void initgemini(FILE *out, FILE *det, int nbiterated, real *iterated[]);
/* end gemini.c */

/* funk.c */
real fun(vector vect);
int D_fun_i(vector vect, int *ibd, real dfun[2]);
int D2_fun_i(vector vect, int *ibd, real d2fun[2][2]);
int Information_matrix3(real *iterated[], real **q, real ***qq, 
			real matrix[2][2]);
/* end funk.c */

/* tab3D_dyn.c */
int ** Alloc2Dint(int h, int w);
/*  Alloue memoire dynamiquement pour un tab2D (h x w) d'integers */
int *** Alloc3Dint(int h, int w, int d);
/*  Alloue memoire dynamiquement pour un tab3D (h x w x d) d'integers */
int ** Init2Dint(int h, int w, int n);
/*  Remplit le tab. avec n */
void Free2Dint(int **tab);
/*  Libere la memoire allouee par taballocint() */
void Free3Dint(int ***tab, int h);
/*  Libere la memoire allouee par Alloc3Dint() */
real ** Alloc2Ddouble(int h, int w);
/*  Alloue memoire dynamiquement pour un tab2D (h x w) de reals */
real *** Alloc3Ddouble(int h, int w, int d);
/*  Alloue memoire dynamiquement pour un tab3D (h x w x d) de reals */
real ** Init2Ddouble(int h, int w, real n);
/*  Remplit le tab. avec n */
real *** Init3Ddouble(int h, int w, int d, real n);
/*  Remplit le tab3D (h x w x d) avec n */
void Free2Ddouble(real **tab);
/*  Libere la memoire allouee par taballocdouble() */
void Free3Ddouble(real ***tab, int h);
/*  Libere la memoire allouee par Alloc3Ddouble() */
/* end tab3D_dyn.c */
